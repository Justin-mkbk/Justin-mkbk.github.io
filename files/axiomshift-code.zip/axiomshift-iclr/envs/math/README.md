# Mathematics inference environments

The GUI, dataset generation, and saved-result analysis need only the base package. GPU inference needs a separate environment on a Linux compute node.

| File | Purpose |
|---|---|
| `hf-environment.yml` | Conda configuration for the Hugging Face inference environment |
| `requirements-vllm.txt` | vLLM runtime for the eight-H200 Kimi K2 Thinking and Qwen3.5 jobs |

## Hugging Face / Qwen2.5-Math-72B

The Conda export records Python 3.12.13, PyTorch 2.11.0+cu130, Transformers 4.57.6, and Accelerate 1.14.0. These inference-library versions also appear in the Qwen72B job output. The export records the environment's current state; it does not establish every package version used in an earlier run. Only its environment name and machine-specific prefix were normalized; dependency versions and builds are unchanged.

The environment also contains CUDA-specific wheels and a development vLLM build. Restoring the complete export requires the corresponding wheel sources; it is not a portable lock file or the environment for the separate vLLM profiles. Reuse a compatible environment on your cluster, or install the HF extra in a fresh CUDA-capable environment:

```bash
cd /scratch/$USER/prior-leakage
export AXIOMSHIFT_PYTHON=/scratch/$USER/conda_envs/qwen35_eval/bin/python
bash scripts/math/setup_cluster.sh hf
```

For a fresh environment, create it with your cluster's supported Python/CUDA installation and point `AXIOMSHIFT_PYTHON` at its Python. The HF extra installs PyTorch, Transformers, Accelerate, and SentencePiece. Check CUDA availability before submitting a full run.

## vLLM / Kimi K2 Thinking and Qwen3.5

Use a separate environment so the serving runtime can install its own dependencies:

```bash
python3 -m venv .venv-vllm
export AXIOMSHIFT_PYTHON="$PWD/.venv-vllm/bin/python"
bash scripts/math/setup_cluster.sh vllm
```

`requirements-vllm.txt` pins vLLM 0.23.0 from the original model launch recipe. Its model compatibility must be checked with a short run on your allocation. Model weights are not downloaded by setup.

## Record the environment for a new run

```bash
bash scripts/math/capture_environment.sh outputs/environment
```

This records pip packages, Python/platform, and GPU driver information. It also exports Conda configuration when the selected Python belongs to a Conda environment and `conda` is available. Keep the record with your dataset, model revision, and responses. Historical job logs are not required to install or use this repository.
