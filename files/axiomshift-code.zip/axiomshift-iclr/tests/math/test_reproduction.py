"""Check exact dataset reconstruction and manuscript dependencies."""
import contextlib
import hashlib
import io
import json
import re
import tempfile
import unittest
from collections import Counter
from pathlib import Path
from prior_leakage.math.axiomshift.dataset.io import ROOT,DEFAULT_DATA,load_questions
from prior_leakage.math.axiomshift.dataset.generation import generate
from prior_leakage.math.analysis.figures import stage_submission
from prior_leakage.math.axiomshift.dataset.verify_answers import verify_answers

class ReproductionTests(unittest.TestCase):
    def test_independent_prompt_verifier_rejects_changed_gold(self):
        """Catch incorrect numeric labels independently of the generating calculator."""
        rows = [dict(row) for row in load_questions()
                if row['question_set'] in ('polygon_three_worlds', 'upward_demand_market')]
        verify_answers(rows)
        row = next(row for row in rows if row['question_family'] == 'clearing_price')
        row['expected_answer'] = '999999'
        with self.assertRaisesRegex(ValueError, 'verification failed'):
            verify_answers(rows)
        # A prior failed invocation must not contaminate a subsequent valid check.
        verify_answers([r for r in load_questions()
                        if r['question_set'] in ('polygon_three_worlds', 'upward_demand_market')])

    def test_seven_generators_and_exact_id_prefixes(self):
        """Verify exactly seven active generators and the published corrected question-ID composition."""
        generators=list((ROOT/'generators').glob('*generator*.py'))
        self.assertEqual(len(generators),7)
        self.assertFalse(any('congruence_generator' in p.name or 'tropical' in p.name for p in generators))
        prefixes=Counter(q['question_id'].split('_')[0] for q in load_questions())
        self.assertEqual(dict(prefixes),dict(mass=100,ord=100,sas=100,codon=100,chem=100,poly2=90,poly3=10,mkt2=67,mkt3=33))

    def test_seeded_pipeline_regenerates_canonical_bytes(self):
        """Rebuild the entire benchmark and compare exact CSV bytes, detecting accidental changes to questions or gold answers."""
        with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
            report=generate(tmp)
            self.assertTrue(report['byte_identical'])
            self.assertEqual(report['differences'],[])
            self.assertEqual([p.name for p in Path(tmp).rglob('*.csv')], ['seven_worlds.csv'])

    def test_both_submission_dependency_sets(self):
        """Check the figures, inputs, and bibliography entries needed by both manuscripts."""
        for submission in ('mathai','aiscik'):
            with tempfile.TemporaryDirectory() as tmp,contextlib.redirect_stdout(io.StringIO()):
                stage_submission(submission,tmp)
                folder=Path(tmp)
                main=(folder/'main.tex').read_text(encoding='utf-8')
                for filename in re.findall(r'\\input\{([^}]+)\}',main):
                    self.assertTrue((folder/(filename+'.tex')).is_file(),filename)
                for filename in re.findall(r'\\figorbox\{[^}]+\}\{([^}]+)\}',main):
                    self.assertTrue((folder/(filename+'.pdf')).is_file(),filename)
                texts=main+'\n'+(folder/'appendix_examples.tex').read_text(encoding='utf-8')
                cites=set(k.strip() for group in re.findall(r'\\cite\w*\*?(?:\[[^\]]*\])*\{([^}]+)\}',texts) for k in group.split(','))
                bib=(folder/'references.bib').read_text(encoding='utf-8')
                keys=set(re.findall(r'@\w+\s*\{\s*([^,\s]+)',bib))
                self.assertFalse(cites-keys,'Missing bibliography keys: '+str(cites-keys))

if __name__=='__main__':unittest.main()
