"""Test vLLM job wiring and server cleanup without GPUs or model weights."""
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import socket
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from prior_leakage.math.axiomshift.dataset.io import load_questions, read_csv
from prior_leakage.math.axiomshift.models import vllm
from prior_leakage.math.axiomshift.models.backends import response_record


def arguments(folder):
    model = Path(folder)/'weights'
    model.mkdir()
    (model/'config.json').write_text('{}')
    return argparse.Namespace(model='fixture-vllm', model_path=model, output=Path(folder)/'run',
        data=vllm.DEFAULT_DATA, tensor_parallel_size=8, max_model_len=24576,
        max_output_tokens=4096, gpu_memory_utilization=.90, limit=2,
        startup_timeout=5, port=None, language_model_only=True, reasoning_parser='qwen3',
        trust_remote_code=True, resume=False)


class VllmTests(unittest.TestCase):
    def test_reasoning_is_retained_but_not_substituted_for_an_answer(self):
        response = response_record({'choices':[{'message':{'content':None,
            'reasoning_content':'Intermediate calculation: 42'},'finish_reason':'length'}]},'chat')
        self.assertEqual(response['raw_response_text'],'')
        self.assertEqual(response['raw_reasoning_text'],'Intermediate calculation: 42')

    def test_command_matches_supplied_qwen_settings(self):
        with tempfile.TemporaryDirectory() as folder:
            command = vllm.server_command(arguments(folder), 24000)
        for key, value in [('--tensor-parallel-size','8'),('--max-model-len','24576'),
                           ('--reasoning-parser','qwen3'),('--host','127.0.0.1')]:
            self.assertEqual(command[command.index(key)+1], value)
        self.assertIn('--language-model-only', command)
        self.assertIn('--trust-remote-code', command)

    def test_startup_failure_stops_server(self):
        with tempfile.TemporaryDirectory() as folder:
            args = arguments(folder)
            process = Mock()
            with patch.object(vllm,'server_command',return_value=[sys.executable]), \
                 patch.object(vllm.subprocess,'Popen',return_value=process), \
                 patch.object(vllm,'wait_for_server',side_effect=RuntimeError('startup failed')), \
                 patch.object(vllm,'stop_server') as stop:
                with self.assertRaisesRegex(RuntimeError,'startup failed'):
                    vllm.evaluate(args)
                stop.assert_called_once_with(process)

    def test_server_to_shared_evaluator_and_resume(self):
        questions = {q['question_text']:q['expected_answer'] for q in load_questions()}
        requests = []
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def send(self,value):
                data=json.dumps(value).encode()
                self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
            def do_GET(self): self.send({'data':[{'id':'fixture-vllm'}]})
            def do_POST(self):
                body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                requests.append(body)
                answer=questions[body['messages'][-1]['content']]
                self.send({'choices':[{'message':{'content':'FINAL_ANSWER: '+answer},'finish_reason':'stop'}]})
        with tempfile.TemporaryDirectory() as folder:
            args=arguments(folder)
            with socket.socket() as sock:
                sock.bind(('127.0.0.1',0));args.port=sock.getsockname()[1]
            servers=[]
            def start(*a,**kw):
                server=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
                threading.Thread(target=server.serve_forever,daemon=True).start()
                servers.append(server)
                return Mock(poll=Mock(return_value=None))
            def stop(process):
                server=servers.pop();server.shutdown();server.server_close()
            try:
                with patch.object(vllm,'server_command',return_value=[sys.executable]), \
                     patch.object(vllm.subprocess,'Popen',side_effect=start), \
                     patch.object(vllm,'stop_server',side_effect=stop):
                    vllm.evaluate(args)
                    args.resume=True
                    vllm.evaluate(args)
                self.assertEqual(len(requests),2)
                self.assertTrue(all(r['seed']==42 and r['top_p']==1 and r['temperature']==0 for r in requests))
                self.assertTrue(all(r['is_correct']=='True' for r in read_csv(args.output/'answers.csv')))
                report=read_csv(args.output/'analysis/models.csv')[0]
                self.assertEqual(report['n_complete'],'2')
                self.assertEqual(report['n_missing'],'698')
                self.assertTrue(list((args.output/'server-logs').glob('*.json')))
                self.assertFalse(servers)
            finally:
                for server in servers:server.shutdown();server.server_close()

    def test_dead_server_fails_without_waiting_for_timeout(self):
        with self.assertRaisesRegex(RuntimeError,'exited'):
            vllm.wait_for_server(Mock(poll=Mock(return_value=1)), 'http://127.0.0.1:1/v1','model',1)
