"""Regression tests for geometry validation and Slurm job preparation."""
import contextlib
import importlib.util
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from prior_leakage.math.axiomshift.dataset.io import ROOT
from prior_leakage.math.axiomshift.slurm import main


class GeometryAndSlurmTests(unittest.TestCase):
    def test_unknown_polygon_geometry_is_rejected(self):
        """Reject misspelled geometry names instead of silently using hyperbolic formulas."""
        spec=importlib.util.spec_from_file_location('tested_polygon',ROOT/'generators/polygon_three_worlds_generator_100questions.py')
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
        for world in ('euclidean','spherical','hyperbolic'):
            self.assertGreater(module.polar_distance(world,.2,0,.3,.4,1),0)
        for function,args in [(module.polar_distance,(.2,0,.3,.4,1)),(module.triangle_area,(.2,.3,.4,1)),(module.curvature_for_world,(1,))]:
            with self.assertRaises(ValueError):function('sperical',*args)

    def test_slurm_preparation_preserves_resources_without_submitting(self):
        """Prepare the recorded H200 resource profile and shared-runner command without invoking sbatch."""
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()), patch('subprocess.run') as submit:
            main(['--output',tmp,'--work-dir','/scratch/test/prior-leakage','--python','/scratch/test/env/bin/python',
                  '--model-path','/scratch/test/Qwen2.5-32B-Instruct'])
            submit.assert_not_called()
            script=(Path(tmp)/'evaluate.slurm').read_text()
            for expected in ['--partition=h200','--gres=gpu:h200:1','--mem=80G','--cpus-per-task=16',
                             'prior_leakage.math.axiomshift run','--limit 5','--max-output-tokens 4096','--cpu-memory 64GiB']:
                self.assertIn(expected,script)
            self.assertNotIn('--mem=0',script)
            self.assertNotIn('--nodelist',script)
            self.assertEqual(json.loads((Path(tmp)/'job.json').read_text())['limit'],5)
            with self.assertRaises(SystemExit):main(['--output',tmp])

    def test_slurm_node_is_optional_and_validated(self):
        """Accept an explicit node without allowing extra scheduler directives."""
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()), patch('subprocess.run') as submit:
            main(['--output', str(Path(tmp)/'valid'), '--node', 'compute01'])
            self.assertIn('--nodelist=compute01', (Path(tmp)/'valid/evaluate.slurm').read_text())
            with self.assertRaises(SystemExit):
                main(['--output', str(Path(tmp)/'invalid'), '--node', 'compute01\n#SBATCH --exclusive'])
            submit.assert_not_called()
