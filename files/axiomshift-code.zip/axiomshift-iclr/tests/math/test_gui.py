"""Exercise browser HTTP -> shared CLI -> local model HTTP -> scoring -> reports."""
import json
import os
import re
import shutil
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch

from prior_leakage.math.axiomshift.dataset.io import DEFAULT_DATA, ROOT, load_questions, read_csv
from prior_leakage.math.axiomshift.gui import Jobs, local_url, make_server


class GuiTests(unittest.TestCase):
    def test_restrict_endpoint_to_loopback(self):
        """Keep the GUI model connection restricted to local endpoints and reject embedded URL credentials."""
        for url in ['http://localhost:1234/v1','http://127.0.0.1:1234/v1','http://[::1]:1234/v1']:
            self.assertEqual(local_url(url),url)
        for url in ['https://api.openai.com/v1','file:///etc/passwd','http://user:pass@localhost/v1','http://localhost/v1?q=secret']:
            with self.assertRaises(ValueError):local_url(url)

    def test_http_evaluation_pause_resume_reports_and_request_guards(self):
        """Run the GUI-to-model HTTP workflow with a mock server, including pause/resume, reports, generation, and request guards."""
        questions = {q['question_text']:q['expected_answer'] for q in load_questions()}
        calls = []
        first_request = threading.Event()
        release_first = threading.Event()

        class Model(BaseHTTPRequestHandler):
            def log_message(self,*_):pass
            def reply(self,value):
                blob=json.dumps(value).encode()
                self.send_response(200);self.send_header('Content-Type','application/json')
                self.send_header('Content-Length',str(len(blob)));self.end_headers();self.wfile.write(blob)
            def do_GET(self):self.reply({'data':[{'id':'fixture-local-model'}]})
            def do_POST(self):
                request=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
                calls.append((self.path,request))
                if len(calls)==1:
                    first_request.set();release_first.wait(15)
                prompt=request['messages'][-1]['content']
                self.reply({'choices':[{'message':{'content':'FINAL_ANSWER: '+questions[prompt]},'finish_reason':'stop'}],
                            'usage':{'prompt_tokens':100,'completion_tokens':10}})

        model=ThreadingHTTPServer(('127.0.0.1',0),Model)
        threading.Thread(target=model.serve_forever,daemon=True).start()
        try:
            with tempfile.TemporaryDirectory() as tmp, patch.dict(os.environ,{'PYTHONPATH':str(ROOT.parents[1])}):
                root=Path(tmp);(root/'data').mkdir();shutil.copyfile(DEFAULT_DATA,root/'data/seven_worlds.csv')
                jobs=Jobs(root);gui=make_server(0,jobs)
                threading.Thread(target=gui.serve_forever,daemon=True).start()
                url=f'http://127.0.0.1:{gui.server_port}'
                try:
                    with urllib.request.urlopen(url) as response:html=response.read().decode()
                    token=re.search(r"const token='([^']+)'",html).group(1)
                    def request(path,body=None,headers=None):
                        h={'X-AxiomShift-Token':token,'Content-Type':'application/json',**(headers or {})}
                        req=urllib.request.Request(url+path,json.dumps(body).encode() if body is not None else None,h)
                        with urllib.request.urlopen(req,timeout=5) as response:return json.load(response)
                    def finished():
                        end=time.monotonic()+20
                        while time.monotonic()<end:
                            job=request('/api/state')['job']
                            if job['status']!='running':return job
                            time.sleep(.05)
                        self.fail('GUI job did not finish')
                    base=f'http://127.0.0.1:{model.server_port}/v1'
                    self.assertEqual(request('/api/models?url='+base)['models'],['fixture-local-model'])
                    for headers in [{'Origin':'https://untrusted.example'},{'Host':'untrusted.example'},{'X-AxiomShift-Token':'wrong'}]:
                        with self.assertRaises(urllib.error.HTTPError):request('/api/start',{'action':'reference'},headers)
                    with self.assertRaises(urllib.error.HTTPError):request('/api/start',{'action':'generate','name':'../outside'})
                    values={'action':'run','name':'smoke','model':'fixture-local-model','base_url':base,'limit':5,'tokens':800}
                    request('/api/start',values)
                    self.assertTrue(first_request.wait(10))
                    with self.assertRaises(urllib.error.HTTPError):request('/api/start',values)
                    request('/api/pause',{});release_first.set()
                    self.assertEqual(finished()['status'],'paused')
                    self.assertEqual(len(calls),1)
                    request('/api/start',{**values,'resume':True})
                    job=finished()
                    self.assertEqual(job['status'],'finished',job['tail'])
                    self.assertEqual(len(calls),5)
                    self.assertEqual(job['attempted'],5)
                    self.assertTrue(all(route=='/v1/chat/completions' for route,_ in calls))
                    self.assertTrue(all(body['model']=='fixture-local-model' and body['temperature']==0 for _,body in calls))
                    rows=read_csv(root/'outputs/gui-runs/smoke/answers.csv')
                    self.assertEqual(len(rows),5)
                    self.assertTrue(all(r['is_correct']=='True' for r in rows))
                    report=read_csv(root/'outputs/gui-runs/smoke/analysis/models.csv')[0]
                    self.assertEqual(report['n_complete'],'5');self.assertEqual(report['n_missing'],'695')
                    self.assertEqual(float(report['accuracy_pct']),100)
                    self.assertFalse((root/'outputs/gui-runs/smoke/.running').exists())
                    with self.assertRaises(urllib.error.HTTPError):request('/file?path=../../README.md')
                    # Generation is also launched through the public GUI endpoint.
                    request('/api/start',{'action':'generate','seed':42,'name':'seed42'})
                    self.assertEqual(finished()['status'],'finished')
                    self.assertIn('outputs/datasets/seed42/seven_worlds.csv',request('/api/state')['datasets'])
                finally:
                    release_first.set()
                    if jobs.process:jobs.process.wait(timeout=20)
                    gui.shutdown();gui.server_close()
        finally:
            release_first.set();model.shutdown();model.server_close()


if __name__=='__main__':unittest.main()
