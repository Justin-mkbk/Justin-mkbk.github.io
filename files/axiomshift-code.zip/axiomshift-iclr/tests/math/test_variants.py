import contextlib
import io
import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path

from prior_leakage.math.axiomshift.dataset.io import DEFAULT_DATA, ROOT, load_questions, sha256
from prior_leakage.math.axiomshift.dataset.generation import generate


class VariantTests(unittest.TestCase):
    def test_seeds_regenerate_numbers_preserve_balance_and_isolate_ids(self):
        """Check repeatability, changed parameters, balanced families, and separate IDs for user-generated variants."""
        with tempfile.TemporaryDirectory() as tmp, contextlib.redirect_stdout(io.StringIO()):
            paths = [Path(tmp)/str(i) for i in range(3)]
            reports = [generate(path, seed=seed) for path,seed in zip(paths,[42,42,43])]
            self.assertEqual(reports[0]['sha256'],reports[1]['sha256'])
            self.assertNotEqual(reports[0]['sha256'],reports[2]['sha256'])
            gold = load_questions()
            balance = lambda rows: Counter((r['question_set'],r['question_family'],r['abstain_type']) for r in rows)
            gold_ids = {r['question_id'] for r in gold}
            for path in paths:
                rows = load_questions(path/'seven_worlds.csv')
                self.assertEqual(balance(rows),balance(gold))
                self.assertFalse(gold_ids & {r['question_id'] for r in rows})
                # Compare content independently of ID and ordering changes, for every world.
                for world in {r['question_set'] for r in gold}:
                    params = lambda items: {r['parameter_summary'] for r in items if r['question_set']==world}
                    self.assertNotEqual(params(rows),params(gold), world)
            self.assertEqual(sha256(DEFAULT_DATA),reports[0]['canonical_sha256'])
            with self.assertRaisesRegex(ValueError,'empty directory'):
                generate(paths[0],seed=44)


if __name__ == '__main__': unittest.main()
