"""Check dataset validity, historical scores, parsing, and resumable inference before running models."""
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from prior_leakage.math.axiomshift.evaluation.analysis import COMPLETE, analyse, audit_rows, deduplicate, summarize
from prior_leakage.math.axiomshift.models.backends import APIBackend, request_body, response_record
from prior_leakage.math.axiomshift.dataset.io import DEFAULT_DATA, ROOT, load_questions, read_csv, select_questions, write_csv
from prior_leakage.math.axiomshift.models.runner import run, score
from prior_leakage.math.axiomshift.evaluation.scoring import grade_response, parse_model_output


class DatasetTests(unittest.TestCase):
    def test_canonical_balance_and_prior_pool(self):
        """Confirm the supplied benchmark has its published size, abstention balance, and leakage-eligible question count."""
        rows = load_questions(canonical=True)
        self.assertEqual(len(rows), 700)
        self.assertEqual(sum(r['expected_answer'] == 'ABSTAIN' for r in rows), 210)
        self.assertEqual(sum(r['prior_distinguishes'].lower() == 'true' for r in rows), 644)

    def test_duplicate_and_bad_number_rejected(self):
        """Reject duplicate IDs and non-finite gold answers before a user spends time evaluating invalid data."""
        row = load_questions()[0]
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'questions.csv'
            write_csv(path, [row, row])
            with self.assertRaisesRegex(ValueError, 'duplicate'):
                load_questions(path)
            write_csv(path, [{**row, 'expected_answer': 'NaN'}])
            with self.assertRaisesRegex(ValueError, 'Non-finite'):
                load_questions(path)

    def test_export_is_deterministic_and_does_not_mutate_input(self):
        """Check that sampling repeats for the same seed and does not mutate the input."""
        rows = load_questions()
        ids = [r['question_id'] for r in rows]
        first = select_questions(rows, worlds=['two_mass_materials'], limit=10, seed=7)
        self.assertEqual(first, select_questions(rows, worlds=['two_mass_materials'], limit=10, seed=7))
        self.assertEqual(ids, [r['question_id'] for r in rows])


class ScoringTests(unittest.TestCase):
    def test_truncation_and_thinking(self):
        """Keep truncated reasoning from being mistaken for a final numeric answer; recognize explicit final answers."""
        self.assertEqual(parse_model_output('<think>42', True)[4], 'failed')
        self.assertEqual(parse_model_output('working 42', True)[4], 'failed')
        self.assertEqual(parse_model_output('FINAL_ANSWER: 42', True)[1], 42)
        self.assertEqual(parse_model_output('<think>999</think>\nFINAL_ANSWER: 2', False)[1], 2)

    def test_protocols_preserve_legacy_parser_choices(self):
        """Preserve each documented answer-extraction protocol so historical responses retain comparable scores."""
        text = r'Could ABSTAIN, but the answer is \boxed{2}'
        self.assertEqual(parse_model_output(text, False, 'openai')[0], 'ABSTAIN')
        self.assertEqual(parse_model_output(text, False, 'local')[1], 2)
        self.assertEqual(parse_model_output('2\nQuestion 17', False, 'openai', True)[1], 2)
        self.assertEqual(parse_model_output('FINAL_ANSWER: -2.5e-3', False)[1], -0.0025)

    def test_tolerance_and_failure_partition(self):
        """Check numeric tolerance boundaries and distinguish wrong numbers, prior leakage, and abstention failures."""
        self.assertEqual(grade_response(100., 9., False, 101., 'strict', False)[3], 'correct_numeric')
        self.assertEqual(grade_response(0., 9., False, .02, 'strict', False)[3], 'correct_numeric')
        self.assertEqual(grade_response(0., 9., False, .021, 'strict', False)[3], 'wrong_numeric')
        self.assertEqual(grade_response(100., 9., False, 9., 'strict', False)[3], 'wrong_numeric_prior_leak')
        self.assertEqual(grade_response('ABSTAIN', 9., False, 9., 'strict', False)[3], 'failure_to_abstain')
        self.assertEqual(grade_response('ABSTAIN', 9., True, None, 'strict', False)[3], 'correct_abstention')


class ReferenceTests(unittest.TestCase):
    def test_all_26_paper_table_values_and_stored_grades(self):
        """Recalculate all 26 published model-table rows and verify saved correctness/error labels against the shared scorer."""
        # Frozen independently from the published 'All models' table.
        expected = {
            'gpt-5.6-sol': (700,98.4,.5,.5), 'gpt-5.4-mini': (678,93.1,3.8,11.7),
            'gpt-5.4-nano': (665,91.9,5.8,16.7), 'qwen3-235b-a22b-thinking': (481,87.5,8.9,21.1),
            'qwen3-30b-a3b-thinking': (595,76.,14.,29.9), 'qwen3-4b-thinking': (693,65.5,16.4,36.4),
            'nemotron-nano-9b-v2': (677,58.9,19.2,30.1), 'qwen2.5-math-72b-instruct': (696,43.8,13.1,70.5),
            'qwen2.5-32b-instruct': (700,27.1,18.9,32.4), 'gpt-4.1': (700,25.6,18.,47.1),
            'qwen3-235b-a22b-instruct': (700,22.9,17.3,48.1), 'qwen3-4b-instruct': (682,22.7,14.8,63.7),
            'qwen2.5-math-7b-base': (628,22.,17.7,78.), 'qwen2.5-math-7b-instruct': (670,19.6,23.8,81.1),
            'qwen2.5-math-72b-base': (634,18.5,22.8,53.), 'qwen2.5-14b-instruct': (700,15.7,14.6,67.6),
            'qwen2.5-72b-instruct': (700,13.9,17.,73.8), 'llama-3.1-70b-instruct': (700,12.7,15.7,79.5),
            'qwen2.5-7b-instruct': (700,12.4,12.3,72.4), 'qwen3-30b-a3b-instruct': (700,11.3,23.1,83.3),
            'gpt-3.5-turbo': (700,10.1,12.7,81.9), 'qwen2.5-coder-7b-instruct': (700,8.1,10.8,85.7),
            'gemma-3-4b-it': (700,5.9,4.7,91.4), 'qwen2.5-7b-base': (698,5.2,7.5,100.),
            'llama-3.1-8b-instruct': (700,4.6,8.7,100.), 'davinci-002': (699,3.9,6.2,100.)}
        questions = {r['question_id']: r for r in load_questions()}
        found = set()
        for path in (ROOT / 'results/reference').glob('*.csv'):
            rows = deduplicate(read_csv(path))
            name = rows[0]['model_nickname']
            found.add(name)
            with self.subTest(model=name):
                self.assertEqual(audit_rows(rows, questions), [])
                stats = summarize(rows, questions)
                actual = (stats['n_complete'], round(stats['accuracy_pct'], 1),
                          round(stats['leak_pct_committed_prior'], 1), round(stats['failure_to_abstain_pct'], 1))
                self.assertEqual(actual, expected[name])
                self.assertEqual(sum(stats[k] for k in ('A_wrong_number','B_failure_to_abstain','C_prior_leakage','D_false_abstention')),
                                 stats['n_complete'] - stats['n_correct'])
        self.assertEqual(found, set(expected))

    def test_offline_report_and_metadata_mismatch(self):
        """Create offline reports and reject responses paired with incompatible question metadata."""
        path = next((ROOT / 'results/reference').glob('*gpt-5.6-sol*.csv'))
        with tempfile.TemporaryDirectory() as folder:
            report = analyse([path], DEFAULT_DATA, folder)
            self.assertEqual(report[0]['n_complete'], 700)
            self.assertTrue((Path(folder) / 'by_world.csv').exists())
        rows = read_csv(path)
        rows[0]['question_set'] = 'wrong-world'
        with self.assertRaisesRegex(ValueError, 'disagrees'):
            audit_rows(rows, {r['question_id']: r for r in load_questions()})


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.questions = load_questions()[:2]
        self.prompts = json.loads((ROOT / 'configs/prompts.json').read_text())
        self.spec = {'backend': 'api', 'model_id': 'fake', 'api_style': 'chat', 'max_output_tokens': 60,
                     'temperature': 0., 'prompt': 'local', 'parser': 'local', 'base_url': 'http://localhost:1234/v1'}

    def test_resume_skips_complete_retries_failure_and_guards_settings(self):
        """Resume interrupted inference without repeating completed answers or mixing changed run settings."""
        class Backend:
            def __init__(self):
                self.calls = 0
            def generate(self, text):
                self.calls += 1
                if self.calls == 2:
                    raise RuntimeError('temporary server failure')
                return {'raw_response_text': 'FINAL_ANSWER: 1.12', 'finish_reason': 'stop'}
        backend = Backend()
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()):
            def go(**kwargs):
                return run('fake', self.spec, self.questions, DEFAULT_DATA, folder, self.prompts, backend=backend, **kwargs)
            with self.assertRaisesRegex(RuntimeError, 'server failure'):
                go()
            self.assertEqual(len(read_csv(Path(folder)/'answers.csv')), 2)
            go(resume=True)
            self.assertEqual(backend.calls, 3)
            self.assertEqual(len(read_csv(Path(folder)/'answers.csv')), 2)
            go(resume=True)
            self.assertEqual(backend.calls, 3)
            self.spec['max_output_tokens'] = 61
            with self.assertRaisesRegex(ValueError, 'Resume refused'):
                go(resume=True)

    def test_dry_run_creates_nothing(self):
        """Let users inspect settings without creating outputs or contacting a model."""
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()):
            target = Path(folder)/'run'
            run('fake', self.spec, self.questions, DEFAULT_DATA, target, self.prompts, dry_run=True)
            self.assertFalse(target.exists())

    def test_request_shapes_and_response_parsing(self):
        """Check supported API request formats and extract response text/token metadata consistently."""
        for style in ('chat', 'completion', 'responses_plain', 'responses_reasoning'):
            spec = {**self.spec, 'api_style': style}
            body = request_body(spec, 'QUESTION', self.prompts)
            self.assertNotIn('expected_answer', body)
            if style == 'responses_reasoning':
                self.assertNotIn('temperature', body)
                self.assertIn('reasoning', body)
        record = response_record({'status':'incomplete', 'incomplete_details': {'reason':'max_output_tokens'},
            'output':[{'type':'reasoning'}, {'type':'message','content':[{'type':'output_text','text':'FINAL_ANSWER: 7'}]}]}, 'responses_reasoning')
        self.assertEqual(record['finish_reason'], 'max_output_tokens')
        self.assertEqual(record['raw_response_text'], 'FINAL_ANSWER: 7')

    def test_api_adapter_without_external_requests(self):
        """Exercise the API adapter with a controlled response so no account, network provider, or model is needed."""
        response = {'choices':[{'message':{'content':'FINAL_ANSWER: 1.12'},'finish_reason':'stop'}], 'usage': {}}
        with patch('urllib.request.urlopen', return_value=io.BytesIO(json.dumps(response).encode())) as request:
            result = APIBackend(self.spec, self.prompts).generate(self.questions[0]['question_text'])
            self.assertTrue(score(self.questions[0], result, self.spec)['is_correct'])
            payload = json.loads(request.call_args.args[0].data)
            self.assertEqual(payload['messages'][1]['content'], self.questions[0]['question_text'])
            self.assertNotIn('expected_answer', payload)

    def test_local_endpoint_never_receives_openai_key(self):
        """Verify that a custom local endpoint does not receive an unrelated cloud API credential."""
        with patch.dict('os.environ', {'OPENAI_API_KEY':'test-only-key'}):
            self.assertEqual(APIBackend(self.spec, self.prompts).key, '')


if __name__ == '__main__':
    unittest.main()
