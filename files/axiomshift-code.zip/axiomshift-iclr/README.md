# AxiomShift supplementary code and data

This package contains the 700-question, seven-world benchmark, dataset generators, shared model evaluator, local browser interface, saved model responses, and analysis scripts.

## Install and run

Use Python 3.10 or newer. Extract the ZIP and open the folder containing `pyproject.toml`.

```bash
python -m venv .venv
# Activate it: source .venv/bin/activate (Linux/macOS)
# Windows PowerShell: .\.venv\Scripts\Activate.ps1
python -m pip install -e .
python -m prior_leakage.math.axiomshift gui
```

The browser interface runs at `http://127.0.0.1:8765`. For model evaluation, load a model in LM Studio and start its local server at `http://localhost:1234/v1`. Dataset generation and analysis of saved results work without a model.

## Reproduce the questions and scores

```bash
python -m prior_leakage.math.axiomshift validate --canonical
python -m prior_leakage.math.axiomshift generate --output outputs/published
python -m prior_leakage.math.axiomshift analyse --output outputs/reference
python -m unittest discover -s tests/math -v
```

Generation without a seed reproduces the canonical CSV exactly. To sample new numerical values with the same world and family balance:

```bash
python -m prior_leakage.math.axiomshift generate --seed 42 --output outputs/seed42
```

Install `".[hf]"` for direct Hugging Face inference or `".[plots]"` for publication figures. Fresh model outputs can differ from saved responses because of model revisions, quantization, and runtime settings.

## Contents

- [Benchmark and evaluation guide](src/prior_leakage/math/README.md)
- [Local testing and GUI](src/prior_leakage/math/docs/local_testing.md)
- [Pipeline and extension points](src/prior_leakage/math/docs/pipeline.md)
- [Cluster jobs](scripts/math/slurm/README.md)
- [GPU environment configuration](envs/math/README.md)

The saved result files retain model outputs and scores. Machine-specific model paths have been replaced with `/models/` paths; those paths are descriptive metadata, not required installations. The package includes no Git history or unrelated research projects.
