#!/bin/bash
# Run from a checkout visible on the intended Slurm compute node.
# Example: cd /scratch/$USER/prior-leakage
# AXIOMSHIFT_PYTHON=/scratch/$USER/conda_envs/qwen35_eval/bin/python bash scripts/math/setup_cluster.sh
set -euo pipefail
REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
EVAL_PYTHON="${AXIOMSHIFT_PYTHON:-/scratch/${USER}/conda_envs/qwen35_eval/bin/python}"
ENGINE="${1:-hf}"
test -x "$EVAL_PYTHON" || { echo "Set AXIOMSHIFT_PYTHON to an existing CUDA-capable Python executable." >&2; exit 1; }
echo "Installing ${REPO_DIR} on $(hostname), using ${EVAL_PYTHON}"
echo "Environment setup and version records: envs/math/README.md"
case "$ENGINE" in
    hf) "$EVAL_PYTHON" -m pip install -e "${REPO_DIR}[hf]" ;;
    vllm)
        "$EVAL_PYTHON" -m pip install -r "$REPO_DIR/envs/math/requirements-vllm.txt"
        "$EVAL_PYTHON" -m pip install -e "$REPO_DIR"
        ;;
    *) echo "Usage: $0 [hf|vllm]" >&2; exit 2 ;;
esac
"$EVAL_PYTHON" -m prior_leakage.math.axiomshift validate --canonical
"$EVAL_PYTHON" -m prior_leakage.math.axiomshift.slurm --help
echo "Setup finished. Prepare a five-question job first; no job was submitted."
