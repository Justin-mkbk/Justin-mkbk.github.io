# Run the seven-world benchmark on Slurm

All jobs use the shared model evaluator and the canonical 700-question dataset. They default to five questions so you can check model loading and responses before a full run.

| Script | Model / engine | Allocation |
|---|---|---|
| `eval_qwen25_math72b.slurm` | Qwen2.5-Math-72B-Instruct / Transformers | 4 H200 GPUs |
| `eval_kimi_k2_thinking.slurm` | Kimi K2 Thinking / vLLM | 8 H200 GPUs |
| `eval_qwen35_397b.slurm` | Qwen3.5-397B-A17B / vLLM | 8 H200 GPUs |

Each script specifies partition `h200`, 16 CPUs, four hours, and `--mem=0` (all host memory on the allocated node). Set the partition and GPU type for your cluster. No specific node is selected; pass `sbatch --nodelist=NODE` if required. Resources and model paths follow the original Slurm job scripts; inference uses this repository's seven-world pipeline. These adapted jobs have not yet been executed on the cluster.

## 1. Set up the checkout, environment, and model

Place the checkout at `/scratch/$USER/prior-leakage`, or use its actual path:

```bash
cd /scratch/$USER/prior-leakage
export AXIOMSHIFT_REPO="$PWD"
export AXIOMSHIFT_PYTHON=/scratch/$USER/conda_envs/qwen35_eval/bin/python
bash scripts/math/setup_cluster.sh hf
```

The [environment guide](../../../envs/math/README.md) includes the Qwen Conda configuration and setup for a separate vLLM environment. For the eight-GPU profiles:

```bash
python3 -m venv .venv-vllm
export AXIOMSHIFT_PYTHON="$PWD/.venv-vllm/bin/python"
bash scripts/math/setup_cluster.sh vllm
```

Set `AXIOMSHIFT_PYTHON` to the environment for the chosen engine before submission. The HF script defaults to the existing `qwen35_eval` environment; the vLLM scripts default to `.venv-vllm/bin/python` in the checkout.

Model weights must already be present on the target node. The default paths are:

```text
/scratch/$USER/huggingface_qwen25_math72b/Qwen2.5-Math-72B-Instruct
/scratch/$USER/polygon_multimodel_eval/models/Kimi-K2-Thinking
/scratch/$USER/polygon_multimodel_eval/models/Qwen3.5-397B-A17B
```

Set `AXIOMSHIFT_MODEL_PATH` to override the path for your chosen job. Scratch storage is node-local: files on another node may not be visible on the allocated node. Setup installs the package; it does not download weights or submit jobs.

## 2. Run five questions

Choose one job and submit from the checkout root:

```bash
sbatch scripts/math/slurm/eval_qwen25_math72b.slurm
# Or, with the vLLM environment selected:
sbatch scripts/math/slurm/eval_kimi_k2_thinking.slurm
sbatch scripts/math/slurm/eval_qwen35_397b.slurm
```

The default output folders are `outputs/qwen72b-smoke`, `outputs/kimi-smoke`, and `outputs/qwen35-smoke`. Each contains `run.json`, `answers.jsonl`, and `answers.csv`. Check that responses contain model output and inspect incomplete/error counts. A low accuracy is a model result; missing responses or runtime errors need investigation before a longer run. Slurm writes `slurm-<job-name>-<job-id>.out` and `.err` in the submission directory for troubleshooting.

The vLLM launcher also writes analysis reports and stops its server on completion or error. For the HF job, generate the report with:

```bash
"$AXIOMSHIFT_PYTHON" -m prior_leakage.math.axiomshift analyse \
  --results outputs/qwen72b-smoke/answers.csv --output outputs/qwen72b-smoke/analysis
```

## 3. Run all 700 questions, or a seeded variant

Use a new output directory for the full run:

```bash
sbatch scripts/math/slurm/eval_qwen25_math72b.slurm --limit 700 --output outputs/qwen72b-full
sbatch scripts/math/slurm/eval_kimi_k2_thinking.slurm --limit 700 --output outputs/kimi-full
sbatch scripts/math/slurm/eval_qwen35_397b.slurm --limit 700 --output outputs/qwen35-full
```

To change the question parameters while keeping the seven-world/family balance:

```bash
"$AXIOMSHIFT_PYTHON" -m prior_leakage.math.axiomshift generate --seed 42 --output outputs/seed42
sbatch scripts/math/slurm/eval_qwen25_math72b.slurm \
  --data "$PWD/outputs/seed42/seven_worlds.csv" --limit 700 --output outputs/qwen72b-seed42
"$AXIOMSHIFT_PYTHON" -m prior_leakage.math.axiomshift analyse \
  --data outputs/seed42/seven_worlds.csv \
  --results outputs/qwen72b-seed42/answers.csv --output outputs/qwen72b-seed42/analysis
```

Run the analysis command after the scheduled job finishes. The same `--data` option works with the vLLM scripts. Resume an interrupted job with its identical arguments plus `--resume`. Changed model settings, dataset, selection, or code require a new output directory. Do not submit simultaneous writers to the same output folder.

## Inference settings and other allocations

Qwen72B uses bfloat16, automatic placement across the allocated GPUs, a 132GiB per-GPU loading ceiling, a 64GiB CPU offload ceiling, 16384 input tokens, 4096 output tokens, greedy decoding, and seed 42. Prompts and scoring follow the seven-world benchmark, rather than the original polygon-only experiment.

The vLLM profiles use tensor parallelism 8, context 24576, GPU utilization 0.90, output limit 4096, temperature 0, top-p 1, and seed 42. Qwen3.5 also uses `--language-model-only --reasoning-parser qwen3`. Both allow model-specific code through `--trust-remote-code`. The server binds to loopback; its port stays stable for resume. If occupied, pass `--port` and keep that value on subsequent resumes.

For another HF allocation, generate a script with `axiomshift-slurm`. Its default profile is Qwen2.5-32B on one H200, 16 CPUs, and 80G host memory:

```bash
"$AXIOMSHIFT_PYTHON" -m prior_leakage.math.axiomshift.slurm \
  --python "$AXIOMSHIFT_PYTHON" --work-dir "$PWD" \
  --model-path /scratch/$USER/huggingface_qwen25_32b/Qwen2.5-32B-Instruct \
  --name qwen32b-smoke --limit 5 --output outputs/qwen32b-job
cat outputs/qwen32b-job/evaluate.slurm
sbatch outputs/qwen32b-job/evaluate.slurm
```

Generation writes `evaluate.slurm` and `job.json`; only `sbatch` or the launcher's explicit `--submit` option submits it. Use `--help` for resource overrides. For custom vLLM models, see `python -m prior_leakage.math.axiomshift.models.vllm --help`.

Keep the exact dataset, model revision, settings, environment record, and response files for comparisons. Historical cluster logs are not distributed or needed to use the benchmark. The 26 saved response sets and nine run summaries remain available for offline reproduction of the reported scores.
