#!/usr/bin/env bash
# Usage: AXIOMSHIFT_PYTHON=/path/to/env/bin/python bash scripts/math/capture_environment.sh outputs/env-name
set -euo pipefail
EVAL_PYTHON="${AXIOMSHIFT_PYTHON:?Set AXIOMSHIFT_PYTHON to the evaluation Python}"
DEST="${1:?Pass a new environment-record directory}"
mkdir -p "$(dirname "$DEST")"
mkdir "$DEST"
"$EVAL_PYTHON" -m pip freeze > "$DEST/pip-freeze.txt"
"$EVAL_PYTHON" - <<'PY' > "$DEST/python.json"
import json, platform, sys
print(json.dumps({"python": sys.version, "executable": sys.executable, "prefix": sys.prefix,
                  "platform": platform.platform()}, indent=2))
PY
if command -v nvidia-smi >/dev/null 2>&1; then
    nvidia-smi > "$DEST/nvidia-smi.txt"
fi
ENV_PREFIX="$("$EVAL_PYTHON" -c 'import sys; print(sys.prefix)')"
if [[ -d "$ENV_PREFIX/conda-meta" ]] && command -v conda >/dev/null 2>&1; then
    conda env export --prefix "$ENV_PREFIX" > "$DEST/conda.yml"
    conda list --explicit --prefix "$ENV_PREFIX" > "$DEST/conda-explicit.txt"
fi
echo "Environment saved to $DEST"
