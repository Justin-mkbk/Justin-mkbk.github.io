# A sheet lists which of 65 rods are no longer than others.
# Chain those comparisons to count all relationships the sheet establishes.
# Reading only directly listed comparisons misses the required deductions.

from __future__ import annotations

import csv
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
#
# A set of segments ordered by "no longer than". Every answer is a
# count, which keeps the numeric grader usable and, more usefully,
# makes the characteristic failure measurable: a reader who only looks
# at the listed facts and never chains them together gets a smaller
# number, and that number is recorded as the prior-predicted answer.


RANDOM_SEED = 20260820

TOTAL_QUESTIONS = 100

# Tuned empirically: at 65 segments and this density the graph has
# comfortably more than enough nodes whose reachable set is both large
# and clearly bigger than their directly-listed set, which is what makes
# a chaining question worth asking.
NUM_SEGMENTS = 65
EDGE_PROBABILITY = 0.06

COUNT_ABOVE = 25
COUNT_BELOW = 20
COUNT_MAXIMAL = 25
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

SUBSET_SIZE = 10

# A question is only used when chaining actually matters, so the count
# must exceed the direct-only count by at least this much.
MIN_CHAINING_GAIN = 2

OUTPUT_CSV = Path("partial_order_counts_questions_100questions.csv")
OUTPUT_JSON = Path("partial_order_counts_metadata_100questions.json")

ABSTAIN_INSTRUCTION = (
    "If the facts are inconsistent, or do not pin down a single answer, or "
    "are not enough to work the answer out, reply ABSTAIN."
)

EXACT_FACTS_NOTE = (
    "The facts on the sheet are exact statements rather than rounded "
    "measurements, so a genuine clash between them is a real conflict."
)

GroundTruth = Union[int, str]



# Data structures


@dataclass(frozen=True)
class OrderQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# The world
#
# Edges only ever run from a lower-numbered segment to a higher one,
# which makes a cycle impossible by construction.


def label(index: int) -> str:
    return "s" + str(index + 1)


def build_edges(generator: random.Random) -> list[tuple]:
    edges: list[tuple] = []
    for lower in range(NUM_SEGMENTS):
        for higher in range(lower + 1, NUM_SEGMENTS):
            if generator.random() < EDGE_PROBABILITY:
                edges.append((lower, higher))
    return edges


def build_children(edges: list[tuple]) -> dict:
    children: dict = {index: [] for index in range(NUM_SEGMENTS)}
    for lower, higher in edges:
        children[lower].append(higher)
    return children


def reachable_above(start: int, children: dict) -> set:
    """Everything strictly above start, following the facts as far as
    they go."""
    seen: set = set()
    frontier = [start]
    while frontier:
        nxt: list[int] = []
        for node in frontier:
            for child in children.get(node, []):
                if child not in seen:
                    seen.add(child)
                    nxt.append(child)
        frontier = nxt
    return seen


def reachable_below(start: int, children: dict) -> set:
    parents: dict = {index: [] for index in range(NUM_SEGMENTS)}
    for node, kids in children.items():
        for kid in kids:
            parents[kid].append(node)

    seen: set = set()
    frontier = [start]
    while frontier:
        nxt: list[int] = []
        for node in frontier:
            for parent in parents.get(node, []):
                if parent not in seen:
                    seen.add(parent)
                    nxt.append(parent)
        frontier = nxt
    return seen


def direct_above(start: int, children: dict) -> set:
    return set(children.get(start, []))


def direct_below(start: int, children: dict) -> set:
    return {node for node, kids in children.items() if start in kids}



# Rules and framing


RULES_TEXT = (
    "There is a collection of segments, and a relation written s <= t, which "
    "the sheet reads as 's is no longer than t'. The only rules the sheet "
    "allows are these five:\n\n"
    "Rule 1: s <= s for every segment s.\n"
    "Rule 2: if s <= t and t <= s, then s and t are the same segment.\n"
    "Rule 3: if s <= t and t <= u, then s <= u.\n"
    "Rule 4: for some pairs of segments neither s <= t nor t <= s holds. "
    "Those two segments are called incomparable.\n"
    "Rule 5: different labels always name different segments.\n\n"
    "The list below is the complete set of facts recorded on the sheet."
)

INTRO_TEMPLATES = [
    "I'm sorting through a box of offcuts and the previous owner left a sheet "
    "comparing their lengths.",
    "I inherited a set of measuring rods with a sheet listing how they compare, "
    "and I'm trying to make sense of it.",
    "I'm cataloguing a set of segments for a workshop and working from the "
    "comparison sheet that came with them.",
    "A friend gave me a box of rods with a sheet showing which ones are no "
    "longer than which, and I'm working through it.",
]


def render_facts(edges: list[tuple], extra_lines: Optional[list[str]] = None) -> str:
    lines = [f"{label(lower)} <= {label(higher)}" for lower, higher in sorted(edges)]
    if extra_lines:
        lines.extend(extra_lines)
    return "\n".join(lines)


def build_prompt(
    generator: random.Random,
    facts_text: str,
    closing: str,
    extra_sentence: str = "",
) -> str:
    parts = [
        generator.choice(INTRO_TEMPLATES),
        "",
        RULES_TEXT,
        "",
        "The facts on the sheet:",
        facts_text,
    ]
    if extra_sentence:
        parts.extend(["", extra_sentence])
    parts.extend(["", closing])
    return "\n".join(parts)



# 5. ANSWERABLE - HOW MANY ARE ABOVE, HOW MANY BELOW


def make_count_questions(
    generator: random.Random,
    edges: list[tuple],
    children: dict,
    count: int,
    direction: str,
) -> list[OrderQuestion]:
    questions: list[OrderQuestion] = []
    facts_text = render_facts(edges)
    used: set = set()

    candidates = list(range(NUM_SEGMENTS))
    generator.shuffle(candidates)

    for node in candidates:
        if len(questions) >= count:
            break
        if node in used:
            continue

        if direction == "above":
            full = reachable_above(node, children)
            direct = direct_above(node, children)
            wording = (
                f"Working only from the sheet, how many of the other rods "
                f"does it establish are at least as long as {label(node)}?"
            )
        else:
            full = reachable_below(node, children)
            direct = direct_below(node, children)
            wording = (
                f"Working only from the sheet, how many of the other rods "
                f"does it establish are no longer than {label(node)}?"
            )

        if len(full) - len(direct) < MIN_CHAINING_GAIN:
            continue
        if len(full) < 3:
            continue

        used.add(node)
        index = len(questions) + 1
        question_text = build_prompt(
            generator, facts_text,
            wording + " Please give a whole number. " + ABSTAIN_INSTRUCTION,
        )

        questions.append(
            OrderQuestion(
                question_id=f"ord_{direction}_{index:03d}",
                latent_instance_id=f"ord_{direction}_{index:03d}",
                dataset_split="answerable",
                question_family=f"count_{direction}",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=len(full),
                prior_predicted_answer=float(len(direct)),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"node": node, "direction": direction}),
                question_text=question_text,
            )
        )

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} of {count} for {direction}.")
    return questions



# 6. ANSWERABLE - HOW MANY ARE TOPMOST IN A SHORTLIST


def make_maximal_questions(
    generator: random.Random,
    edges: list[tuple],
    children: dict,
    count: int,
) -> list[OrderQuestion]:
    questions: list[OrderQuestion] = []
    facts_text = render_facts(edges)

    while len(questions) < count:
        subset = generator.sample(range(NUM_SEGMENTS), SUBSET_SIZE)

        true_maximal = 0
        for node in subset:
            above = reachable_above(node, children)
            if not any(other in above for other in subset if other != node):
                true_maximal += 1

        direct_maximal = 0
        for node in subset:
            above = direct_above(node, children)
            if not any(other in above for other in subset if other != node):
                direct_maximal += 1

        if true_maximal == direct_maximal:
            continue
        if true_maximal in (0, SUBSET_SIZE):
            continue

        index = len(questions) + 1
        subset_labels = ", ".join(label(node) for node in subset)
        question_text = build_prompt(
            generator, facts_text,
            f"Look only at these rods: {subset_labels}. Among just those, "
            "how many have no other rod on that same shortlist that the sheet "
            "establishes is at least as long as them? Please give a whole "
            "number. " + ABSTAIN_INSTRUCTION,
        )

        questions.append(
            OrderQuestion(
                question_id=f"ord_maximal_{index:03d}",
                latent_instance_id=f"ord_maximal_{index:03d}",
                dataset_split="answerable",
                question_family="maximal_in_shortlist",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=true_maximal,
                prior_predicted_answer=float(direct_maximal),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"subset": subset}),
                question_text=question_text,
            )
        )

    return questions



# 7. ABSTAIN - INCONSISTENT CONDITIONS
#
# One extra fact runs the wrong way round a chain that already exists.
# Rules 2 and 3 then force two differently-labelled segments to be the
# same segment, which Rule 5 forbids.


def make_inconsistent_questions(
    generator: random.Random,
    edges: list[tuple],
    children: dict,
    count: int,
) -> list[OrderQuestion]:
    questions: list[OrderQuestion] = []

    pairs: list[tuple] = []
    for lower in range(NUM_SEGMENTS):
        above = reachable_above(lower, children)
        for higher in above:
            if higher not in direct_above(lower, children):
                pairs.append((lower, higher))
    generator.shuffle(pairs)

    for lower, higher in pairs:
        if len(questions) >= count:
            break

        poisoned = edges + [(higher, lower)]
        facts_text = render_facts(edges, [f"{label(higher)} <= {label(lower)}"])

        full = reachable_above(lower, children)
        index = len(questions) + 1
        question_text = build_prompt(
            generator, facts_text,
            f"Working from the sheet, how many of the other rods does it "
            f"establish are at least as long as {label(lower)}? Please give a "
            f"whole number. "
            + EXACT_FACTS_NOTE + " " + ABSTAIN_INSTRUCTION,
        )

        questions.append(
            OrderQuestion(
                question_id=f"ord_inconsistent_{index:03d}",
                latent_instance_id=f"ord_inconsistent_{index:03d}",
                dataset_split="abstain",
                question_family="order_cycle_forced",
                abstain_type="inconsistent",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=float(len(full)),
                prior_distinguishes=True,
                parameter_summary=json.dumps({
                    "node": lower, "poison_from": higher, "poison_to": lower,
                }),
                question_text=question_text,
            )
        )

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} inconsistent items.")
    return questions



# 8. ABSTAIN - GENUINELY NON-UNIQUE
#
# One line of the sheet records a comparison but does not say which way
# round it goes. Both readings keep the sheet consistent, and they give
# different counts.


def make_non_unique_questions(
    generator: random.Random,
    edges: list[tuple],
    children: dict,
    count: int,
) -> list[OrderQuestion]:
    questions: list[OrderQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 200000:
        attempts += 1

        first = generator.randrange(NUM_SEGMENTS)
        second = generator.randrange(NUM_SEGMENTS)
        if first == second:
            continue

        # Neither may already be reachable from the other, otherwise one
        # of the two readings would make the sheet contradict itself.
        if second in reachable_above(first, children):
            continue
        if first in reachable_above(second, children):
            continue

        node = generator.randrange(NUM_SEGMENTS)

        edges_one = edges + [(first, second)]
        edges_two = edges + [(second, first)]
        count_one = len(reachable_above(node, build_children(edges_one)))
        count_two = len(reachable_above(node, build_children(edges_two)))

        if count_one == count_two:
            continue

        facts_text = render_facts(edges)
        index = len(questions) + 1
        question_text = build_prompt(
            generator, facts_text,
            f"Working from the sheet, how many of the other rods does it "
            f"establish are at least as long as {label(node)}? Please give a "
            f"whole number. "
            + ABSTAIN_INSTRUCTION,
            extra_sentence=(
                f"There is one more line on the sheet recording a comparison "
                f"between {label(first)} and {label(second)}, but it has been "
                "written so badly that I cannot tell which of the two is on "
                "the left of the <= sign."
            ),
        )

        questions.append(
            OrderQuestion(
                question_id=f"ord_nonunique_{index:03d}",
                latent_instance_id=f"ord_nonunique_{index:03d}",
                dataset_split="abstain",
                question_family="order_ambiguous_fact",
                abstain_type="non_unique",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=float(len(reachable_above(node, children))),
                prior_distinguishes=True,
                parameter_summary=json.dumps({
                    "node": node, "first": first, "second": second,
                    "count_if_first_lower": count_one,
                    "count_if_second_lower": count_two,
                }),
                question_text=question_text,
            )
        )

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} non-unique items.")
    return questions



# 9. ABSTAIN - INSUFFICIENT INFORMATION
#
# One line reads "sX <= " with the right-hand label lost. Different
# fillings give different counts, so the answer is not pinned down.


def make_insufficient_questions(
    generator: random.Random,
    edges: list[tuple],
    children: dict,
    count: int,
) -> list[OrderQuestion]:
    questions: list[OrderQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 200000:
        attempts += 1

        source = generator.randrange(NUM_SEGMENTS)
        node = generator.randrange(NUM_SEGMENTS)

        # Work out what the count would be for each legal filling.
        outcomes: set = set()
        for target in range(NUM_SEGMENTS):
            if target == source:
                continue
            if source in reachable_above(target, children):
                continue  # this filling would make the sheet contradict itself
            trial = build_children(edges + [(source, target)])
            outcomes.add(len(reachable_above(node, trial)))
            if len(outcomes) > 1:
                break

        if len(outcomes) < 2:
            continue

        facts_text = render_facts(edges, [f"{label(source)} <= ????"])
        index = len(questions) + 1
        question_text = build_prompt(
            generator, facts_text,
            f"Working from the sheet, how many of the other rods does it "
            f"establish are at least as long as {label(node)}? Please give a "
            f"whole number. "
            + ABSTAIN_INSTRUCTION,
            extra_sentence=(
                f"On the last line the label to the right of the <= sign has "
                "been rubbed out, so I can only read which segment is on the "
                "left."
            ),
        )

        questions.append(
            OrderQuestion(
                question_id=f"ord_insufficient_{index:03d}",
                latent_instance_id=f"ord_insufficient_{index:03d}",
                dataset_split="abstain",
                question_family="order_missing_label",
                abstain_type="insufficient",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=float(len(reachable_above(node, children))),
                prior_distinguishes=True,
                parameter_summary=json.dumps({
                    "node": node, "source": source,
                    "distinct_outcomes": sorted(outcomes),
                }),
                question_text=question_text,
            )
        )

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} insufficient items.")
    return questions



# Independent verification


def verify_questions(questions: list[OrderQuestion], edges: list[tuple], children: dict) -> None:
    problems: list[str] = []

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family

        if family == "count_above":
            recomputed = len(reachable_above(parameters["node"], children))
        elif family == "count_below":
            recomputed = len(reachable_below(parameters["node"], children))
        elif family == "maximal_in_shortlist":
            subset = parameters["subset"]
            recomputed = 0
            for node in subset:
                above = reachable_above(node, children)
                if not any(other in above for other in subset if other != node):
                    recomputed += 1
        elif family == "order_cycle_forced":
            # The added fact must close a loop through at least one step.
            if parameters["poison_to"] not in reachable_below(parameters["poison_from"], children):
                problems.append(f"{question.question_id}: the extra fact does not close a loop")
            recomputed = "ABSTAIN"
        elif family == "order_ambiguous_fact":
            if parameters["count_if_first_lower"] == parameters["count_if_second_lower"]:
                problems.append(f"{question.question_id}: both readings give the same count")
            recomputed = "ABSTAIN"
        elif family == "order_missing_label":
            if len(parameters["distinct_outcomes"]) < 2:
                problems.append(f"{question.question_id}: the missing label does not change the count")
            recomputed = "ABSTAIN"
        else:
            problems.append(f"{question.question_id}: unrecognised family {family}")
            continue

        if recomputed != question.expected_answer:
            problems.append(
                f"{question.question_id}: recomputed {recomputed} vs stored {question.expected_answer}"
            )

        if (
            question.prior_predicted_answer is not None
            and question.expected_answer != "ABSTAIN"
            and float(question.expected_answer) == question.prior_predicted_answer
        ):
            problems.append(f"{question.question_id}: prior value equals the true answer")

    if problems:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(problems))

    counts: dict[str, int] = {}
    for question in questions:
        counts[question.abstain_type] = counts.get(question.abstain_type, 0) + 1
    print("Verification passed. Abstain-type counts:", counts)



# Output


OUTPUT_COLUMNS = [field.name for field in OrderQuestion.__dataclass_fields__.values()]


def write_csv(questions: list[OrderQuestion], output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list[OrderQuestion], edges: list[tuple], output_path: Path) -> None:
    family_counts: dict[str, int] = {}
    abstain_counts: dict[str, int] = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "segments": NUM_SEGMENTS,
        "listed_facts": len(edges),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "world": "segments ordered by 'no longer than', with a complete fact list",
        "prior_attacked": (
            "reading only the listed facts without chaining them, and treating "
            "an underivable relation as merely unknown rather than false"
        ),
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)



# Main


def main() -> None:
    generator = random.Random(RANDOM_SEED)

    edges = build_edges(generator)
    children = build_children(edges)
    print(f"Segments: {NUM_SEGMENTS}   listed facts: {len(edges)}")

    questions: list[OrderQuestion] = []
    questions.extend(make_count_questions(generator, edges, children, COUNT_ABOVE, "above"))
    questions.extend(make_count_questions(generator, edges, children, COUNT_BELOW, "below"))
    questions.extend(make_maximal_questions(generator, edges, children, COUNT_MAXIMAL))
    questions.extend(make_inconsistent_questions(generator, edges, children, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, edges, children, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, edges, children, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS} questions, built {len(questions)}.")

    verify_questions(questions, edges, children)
    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, edges, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    answerable = [q for q in questions if q.dataset_split == "answerable"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(questions) - len(answerable)}")
    print(f"Questions with a distinguishing prior value: "
          f"{len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
