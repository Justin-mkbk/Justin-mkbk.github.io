# A market has explicitly stated demand and supply formulas.
# Here shoppers demand more as price rises; solve the formulas as written.
# Replacing demand with a familiar downward-sloping rule gives a different result.

from __future__ import annotations

import csv
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
#
# The market is described by two exact formulas over the price P:
#
#   quantity shoppers want   Qd = a + b * P      with b > 0
#   quantity stallholders    Qs = c + d * P      with d > 0
#   bring
#
# The market clears where the two are equal, so
#
#   P* = (c - a) / (b - d)
#
# Nothing false is asserted anywhere. The prompt simply states the two
# formulas and lets the arithmetic follow. In the familiar case the
# first slope would be negative; here it is not, and the prompt makes
# no remark about that either way.


RANDOM_SEED = 20260823

TOTAL_QUESTIONS = 100

COUNT_CLEARING_PRICE = 20
COUNT_CLEARING_QUANTITY = 15
COUNT_PRICE_RISE_EFFECT = 15
COUNT_REVENUE_AT_PRICE = 20
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

DISPLAY_DECIMAL_PLACES = 2

OUTPUT_CSV = Path("upward_demand_market_v2_questions_100questions.csv")
OUTPUT_JSON = Path("upward_demand_market_v2_metadata_100questions.json")

# The two slopes must differ by at least this much for a clearing price
# to exist and be numerically well behaved.
MIN_SLOPE_SEPARATION = 0.40

# The correct answer and the answer a familiar downward-sloping reading
# would give must differ by at least this much, otherwise the item
# cannot measure leakage.
MIN_PRIOR_SEPARATION = 0.20

# For the inconsistent family, the quoted observation must miss the
# formulas by clearly more than two-decimal rounding could explain.
MIN_INCONSISTENCY_GAP = 1.20

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)

ROUNDING_TOLERANCE_NOTE = (
    "The figure I wrote down on the day is rounded to two decimal places, so "
    "please only treat something as a genuine conflict if the mismatch is "
    "clearly bigger than rounding could explain."
)

GroundTruth = Union[float, str]



# Data structures


@dataclass(frozen=True)
class MarketQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# Number helpers


def rounded(value: float) -> float:
    return round(value, DISPLAY_DECIMAL_PLACES)


def money(value: float) -> str:
    return f"{value:.2f}"


def clearing_price(a: float, b: float, c: float, d: float) -> float:
    return (c - a) / (b - d)


def prior_clearing_price(a: float, b: float, c: float, d: float) -> float:
    """What a reader gets after silently flipping the first slope so that
    the quantity wanted falls with price."""
    return (c - a) / (-b - d)



# World rules shown in every prompt


# Quantities are measured by weight and may be fractional.

WORLD_RULES = (
    "I help out with the Saturday craft market. The honey there is sold "
    "loose by weight, ladled straight from the barrel, so any amount at all "
    "can change hands. The organisers plan the stalls with two formulas, and "
    "they are firm that these are exact figures rather than rounded "
    "estimates:\n\n"
    "  kilograms shoppers want to buy at a price of P pounds a kilogram:  {demand}\n"
    "  kilograms the stallholders between them bring to sell:             {supply}\n\n"
    "P is the price in pounds per kilogram, and both quantities are in "
    "kilograms for the day. The market is said to clear at the price where "
    "the weight wanted is equal to the weight brought."
)


def demand_line(a: float, b: float) -> str:
    return f"Qd = {money(a)} + {money(b)} x P"


def supply_line(c: float, d: float) -> str:
    return f"Qs = {money(c)} + {money(d)} x P"


def world_text(a, b, c, d, hide: Optional[str] = None) -> str:
    if hide == "a":
        demand = f"Qd = (the first number is smudged) + {money(b)} x P"
    elif hide == "b":
        demand = f"Qd = {money(a)} + (the second number is smudged) x P"
    else:
        demand = demand_line(a, b)

    if hide == "c":
        supply = f"Qs = (the first number is smudged) + {money(d)} x P"
    elif hide == "d":
        supply = f"Qs = {money(c)} + (the second number is smudged) x P"
    else:
        supply = supply_line(c, d)

    return WORLD_RULES.format(demand=demand, supply=supply)


INTRO_TEMPLATES = [
    "I'm trying to sort out the pricing for this weekend and want to check my sums.",
    "I got handed the stall paperwork and I'd like to make sure I've read it right.",
    "I'm doing the planning for Saturday's market and want a second pair of eyes on this.",
    "I'm new to helping with the market accounts and want to check I've followed the sheet.",
    "Trying to get the honey pricing straight before the weekend.",
]



# Sampling the coefficients


def sample_coefficients(generator: random.Random) -> tuple[float, float, float, float]:
    """Both slopes positive, clearly separated, and giving a sensible
    clearing price."""
    while True:
        a = rounded(generator.uniform(4.0, 40.0))
        b = rounded(generator.uniform(1.0, 9.0))
        c = rounded(generator.uniform(4.0, 40.0))
        d = rounded(generator.uniform(1.0, 9.0))

        if abs(b - d) < MIN_SLOPE_SEPARATION:
            continue

        price = clearing_price(a, b, c, d)
        if not (1.00 <= price <= 20.00):
            continue

        quantity = a + b * price
        if quantity <= 2.0:
            continue

        prior_price = prior_clearing_price(a, b, c, d)
        if abs(price - prior_price) < MIN_PRIOR_SEPARATION:
            continue

        return a, b, c, d



# 6. FAMILY A1 - CLEARING PRICE


def make_clearing_price_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []

    while len(questions) < count:
        a, b, c, d = sample_coefficients(generator)
        price = clearing_price(a, b, c, d)
        prior_price = prior_clearing_price(a, b, c, d)

        index = len(questions) + 1
        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + world_text(a, b, c, d)
            + "\n\nAt what price per kilogram does the market clear? Please give the "
            "number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_price_{index:03d}",
                latent_instance_id=f"mkt2_price_{index:03d}",
                dataset_split="answerable",
                question_family="clearing_price",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(price),
                prior_predicted_answer=rounded(prior_price),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"a": a, "b": b, "c": c, "d": d}),
                question_text=question_text,
            )
        )

    return questions



# 7. FAMILY A2 - CLEARING QUANTITY


def make_clearing_quantity_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []

    while len(questions) < count:
        a, b, c, d = sample_coefficients(generator)
        price = clearing_price(a, b, c, d)
        quantity = a + b * price

        prior_price = prior_clearing_price(a, b, c, d)
        prior_quantity = a - b * prior_price

        if abs(quantity - prior_quantity) < 1.0:
            continue

        index = len(questions) + 1
        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + world_text(a, b, c, d)
            + "\n\nHow many kilograms change hands on a day when the market clears? "
            "Please give the number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_quantity_{index:03d}",
                latent_instance_id=f"mkt2_quantity_{index:03d}",
                dataset_split="answerable",
                question_family="clearing_quantity",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(quantity),
                prior_predicted_answer=rounded(prior_quantity),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"a": a, "b": b, "c": c, "d": d}),
                question_text=question_text,
            )
        )

    return questions



# 8. FAMILY A3 - EFFECT OF A PRICE RISE
#
# The change in the quantity wanted is b * (P2 - P1), which is positive
# here. A reader carrying the familiar downward slope reports the same
# magnitude with the opposite sign.


def make_price_rise_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []

    while len(questions) < count:
        a, b, c, d = sample_coefficients(generator)

        first_price = rounded(generator.uniform(2.0, 8.0))
        rise = rounded(generator.uniform(0.5, 4.0))
        second_price = rounded(first_price + rise)

        change = b * (second_price - first_price)
        if change < 1.0:
            continue

        index = len(questions) + 1
        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + world_text(a, b, c, d)
            + f"\n\nIf we move the price from {money(first_price)} pounds a kilogram "
            f"to {money(second_price)} pounds a kilogram, how does the weight of honey "
            "shoppers want to buy change? Give the size of the change as a "
            "number to two decimal places, positive if it goes up and negative "
            "if it goes down. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_rise_{index:03d}",
                latent_instance_id=f"mkt2_rise_{index:03d}",
                dataset_split="answerable",
                question_family="price_rise_effect",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(change),
                prior_predicted_answer=rounded(-change),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"a": a, "b": b, "c": c, "d": d,
                     "p1": first_price, "p2": second_price}
                ),
                question_text=question_text,
            )
        )

    return questions



# 9. FAMILY A4 - TAKINGS AT A STATED PRICE


def make_revenue_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []

    while len(questions) < count:
        a, b, c, d = sample_coefficients(generator)
        price = rounded(generator.uniform(2.0, 9.0))

        wanted = a + b * price
        revenue = price * wanted

        prior_wanted = a - b * price
        prior_revenue = price * prior_wanted

        if abs(revenue - prior_revenue) < 5.0:
            continue

        index = len(questions) + 1
        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + world_text(a, b, c, d)
            + f"\n\nSuppose we set the price at {money(price)} pounds a kilogram and "
            "sell exactly the weight shoppers want at that price. What "
            "would the takings be in pounds? Please give the number to two "
            "decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_revenue_{index:03d}",
                latent_instance_id=f"mkt2_revenue_{index:03d}",
                dataset_split="answerable",
                question_family="revenue_at_price",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(revenue),
                prior_predicted_answer=rounded(prior_revenue),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"a": a, "b": b, "c": c, "d": d, "p": price}
                ),
                question_text=question_text,
            )
        )

    return questions



# 10. ABSTAIN - INCONSISTENT CONDITIONS
#
# Half the items give two formulas with identical slopes and different
# intercepts, so the two quantities are never equal at any price. The
# other half give ordinary formulas alongside a quoted clearing price
# that the formulas cannot produce.


def make_inconsistent_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []
    parallel_target = count // 2

    while len(questions) < count:
        make_parallel = len(questions) < parallel_target

        if make_parallel:
            a = rounded(generator.uniform(4.0, 30.0))
            b = rounded(generator.uniform(1.5, 8.0))
            d = b
            offset = rounded(generator.uniform(3.0, 15.0))
            c = rounded(a + offset if generator.random() < 0.5 else a - offset)
            if c <= 0.5:
                continue

            index = len(questions) + 1
            body = (
                world_text(a, b, c, d)
                + "\n\nAt what price per kilogram does the market clear? Please give "
                "the number to two decimal places. "
                + ABSTAIN_INSTRUCTION
            )
            prior_value = rounded(prior_clearing_price(a, b, c, d))
            condition = "parallel"
            extra = {}
        else:
            a, b, c, d = sample_coefficients(generator)
            true_price = clearing_price(a, b, c, d)

            shift = rounded(generator.uniform(MIN_INCONSISTENCY_GAP, 6.0))
            quoted = rounded(true_price + shift if generator.random() < 0.5
                             else true_price - shift)
            if quoted <= 0.5:
                continue
            if abs(quoted - true_price) < MIN_INCONSISTENCY_GAP:
                continue

            prior_price = prior_clearing_price(a, b, c, d)
            if abs(quoted - prior_price) < MIN_INCONSISTENCY_GAP:
                continue

            index = len(questions) + 1
            body = (
                world_text(a, b, c, d)
                + f"\n\nOne of the organisers told me that last season the market "
                f"cleared at {money(quoted)} pounds a kilogram. Taking that together "
                "with the two formulas, how many kilograms change hands on a day when "
                "the market clears? Please give the number to two decimal "
                "places. "
                + ROUNDING_TOLERANCE_NOTE
                + " "
                + ABSTAIN_INSTRUCTION
            )
            prior_value = rounded(a - b * prior_price)
            condition = "quoted_price_conflicts"
            extra = {"quoted_price": quoted, "true_price": rounded(true_price)}

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_inconsistent_{index:03d}",
                latent_instance_id=f"mkt2_inconsistent_{index:03d}",
                dataset_split="abstain",
                question_family="market_inconsistent",
                abstain_type="inconsistent",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=prior_value,
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"a": a, "b": b, "c": c, "d": d,
                     "condition": condition, **extra}
                ),
                question_text=generator.choice(INTRO_TEMPLATES) + "\n\n" + body,
            )
        )

    return questions



# 11. ABSTAIN - GENUINELY NON-UNIQUE
#
# Identical slopes and identical intercepts, so the two quantities are
# equal at every price and no single clearing price is picked out.


def make_non_unique_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []

    while len(questions) < count:
        a = rounded(generator.uniform(5.0, 30.0))
        b = rounded(generator.uniform(1.5, 8.0))
        c = a
        d = b

        index = len(questions) + 1
        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + world_text(a, b, c, d)
            + "\n\nAt what price per kilogram does the market clear? Please give the "
            "number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_nonunique_{index:03d}",
                latent_instance_id=f"mkt2_nonunique_{index:03d}",
                dataset_split="abstain",
                question_family="market_every_price_clears",
                abstain_type="non_unique",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=0.0,
                prior_distinguishes=True,
                parameter_summary=json.dumps({"a": a, "b": b, "c": c, "d": d}),
                question_text=question_text,
            )
        )

    return questions



# 12. ABSTAIN - INSUFFICIENT INFORMATION
#
# One of the four numbers is missing. The clearing price depends on all
# four, so it cannot be worked out. No prior-predicted value is recorded
# here, because a missing coefficient leaves nothing for a familiar
# reading to compute either.


def make_insufficient_questions(generator: random.Random, count: int) -> list[MarketQuestion]:
    questions: list[MarketQuestion] = []

    while len(questions) < count:
        a, b, c, d = sample_coefficients(generator)
        hidden = generator.choice(["a", "b", "c", "d"])

        index = len(questions) + 1
        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + world_text(a, b, c, d, hide=hidden)
            + "\n\nAt what price per kilogram does the market clear? Please give the "
            "number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MarketQuestion(
                question_id=f"mkt2_insufficient_{index:03d}",
                latent_instance_id=f"mkt2_insufficient_{index:03d}",
                dataset_split="abstain",
                question_family="market_missing_coefficient",
                abstain_type="insufficient",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=None,
                prior_distinguishes=False,
                parameter_summary=json.dumps(
                    {"a": a, "b": b, "c": c, "d": d, "hidden": hidden}
                ),
                question_text=question_text,
            )
        )

    return questions



# Independent verification


def verify_questions(questions: list[MarketQuestion]) -> None:
    problems: list[str] = []

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family
        a, b, c, d = parameters["a"], parameters["b"], parameters["c"], parameters["d"]

        if family == "clearing_price":
            recomputed = round((c - a) / (b - d), 2)
        elif family == "clearing_quantity":
            price = (c - a) / (b - d)
            recomputed = round(a + b * price, 2)
        elif family == "price_rise_effect":
            recomputed = round(b * (parameters["p2"] - parameters["p1"]), 2)
        elif family == "revenue_at_price":
            recomputed = round(parameters["p"] * (a + b * parameters["p"]), 2)
        elif family == "market_inconsistent":
            if parameters["condition"] == "parallel":
                if b != d:
                    problems.append(f"{question.question_id}: slopes are not equal")
                if a == c:
                    problems.append(f"{question.question_id}: intercepts match, so it is not inconsistent")
            else:
                gap = abs(parameters["quoted_price"] - parameters["true_price"])
                if gap < MIN_INCONSISTENCY_GAP:
                    problems.append(f"{question.question_id}: conflict of {gap:.2f} is too small to be safe")
            recomputed = "ABSTAIN"
        elif family == "market_every_price_clears":
            if not (a == c and b == d):
                problems.append(f"{question.question_id}: the two formulas are not identical")
            recomputed = "ABSTAIN"
        elif family == "market_missing_coefficient":
            if parameters["hidden"] not in {"a", "b", "c", "d"}:
                problems.append(f"{question.question_id}: nothing was actually hidden")
            recomputed = "ABSTAIN"
        else:
            problems.append(f"{question.question_id}: unrecognised family {family}")
            continue

        if recomputed != question.expected_answer:
            problems.append(
                f"{question.question_id}: recomputed {recomputed} vs stored {question.expected_answer}"
            )

        # A leaked answer must never coincide with the true answer.
        if (
            question.prior_predicted_answer is not None
            and question.expected_answer != "ABSTAIN"
            and abs(float(question.expected_answer) - question.prior_predicted_answer) < 0.01
        ):
            problems.append(f"{question.question_id}: prior value equals the true answer")

    if problems:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(problems))

    counts: dict[str, int] = {}
    for question in questions:
        counts[question.abstain_type] = counts.get(question.abstain_type, 0) + 1
    print("Verification passed. Abstain-type counts:", counts)



# Output


OUTPUT_COLUMNS = [field.name for field in MarketQuestion.__dataclass_fields__.values()]


def write_csv(questions: list[MarketQuestion], output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list[MarketQuestion], output_path: Path) -> None:
    family_counts: dict[str, int] = {}
    abstain_counts: dict[str, int] = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "world": "a market for a good sold loose by weight, where the quantity wanted rises with price",
        "prior_attacked": (
            "that the quantity wanted falls as price rises, that a market has "
            "exactly one clearing price, and that raising price lowers takings"
        ),
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)



# Main


def main() -> None:
    generator = random.Random(RANDOM_SEED)

    questions: list[MarketQuestion] = []
    questions.extend(make_clearing_price_questions(generator, COUNT_CLEARING_PRICE))
    questions.extend(make_clearing_quantity_questions(generator, COUNT_CLEARING_QUANTITY))
    questions.extend(make_price_rise_questions(generator, COUNT_PRICE_RISE_EFFECT))
    questions.extend(make_revenue_questions(generator, COUNT_REVENUE_AT_PRICE))
    questions.extend(make_inconsistent_questions(generator, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS} questions, built {len(questions)}.")

    verify_questions(questions)

    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    print(f"Wrote metadata to {OUTPUT_JSON.resolve()}")

    answerable = [q for q in questions if q.dataset_split == "answerable"]
    abstain = [q for q in questions if q.dataset_split == "abstain"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(abstain)}")
    print(f"Questions with a distinguishing prior value: "
          f"{len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
