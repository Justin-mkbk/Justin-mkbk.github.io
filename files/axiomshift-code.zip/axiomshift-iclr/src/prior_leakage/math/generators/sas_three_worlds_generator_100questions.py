# Two sides and their included angle describe a triangle on a flat or curved surface.
# Find the third side using the stated geometry.
# Using the familiar flat-space rule on a curved surface is the tested mistake.

from __future__ import annotations

import csv
import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
# SAS (Side-Angle-Side)
# Two sides and the angle between them fix the third side. Which rule
# applies depends on the curvature of the surface:
#
#   flat        BC^2 = AB^2 + AC^2 - 2 AB AC cos(A)
#   spherical   cos(BC/R) = cos(AB/R)cos(AC/R) + sin(AB/R)sin(AC/R)cos(A)
#   hyperbolic  cosh(BC/R) = cosh(AB/R)cosh(AC/R) - sinh(AB/R)sinh(AC/R)cos(A)
#
# The curvature is always stated in the prompt when it is knowable, so
# nothing has to be assumed. The flat items are controls: there the
# familiar rule is the correct rule, so they cannot measure leakage.


RANDOM_SEED = 20260818

TOTAL_QUESTIONS = 100

COUNT_EUCLIDEAN = 23
COUNT_SPHERICAL = 23
COUNT_HYPERBOLIC = 24
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

DISPLAY_DECIMAL_PLACES = 2

OUTPUT_CSV = Path("sas_three_worlds_questions_100questions.csv")
OUTPUT_JSON = Path("sas_three_worlds_metadata_100questions.json")

RADIUS_CHOICES = [0.75, 1.00, 1.25, 1.50, 2.00]

# The curved answer and the flat answer must differ by at least this
# much, otherwise the item cannot tell the two rules apart.
MIN_PRIOR_SEPARATION = 0.06

# A quoted third side must miss the true one by clearly more than
# two-decimal rounding could explain.
MIN_INCONSISTENCY_GAP = 0.25

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)

ROUNDING_TOLERANCE_NOTE = (
    "All the measurements are rounded to two decimal places, so please only "
    "treat something as a genuine conflict if the mismatch is clearly bigger "
    "than rounding could explain."
)

GroundTruth = Union[float, str]

EUCLIDEAN = "euclidean"
SPHERICAL = "spherical"
HYPERBOLIC = "hyperbolic"



# Data structures


@dataclass(frozen=True)
class SASQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# The three rules


def clamp(value: float, lower: float = -1.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


def solve_euclidean(side_ab: float, side_ac: float, angle_deg: float) -> float:
    angle = math.radians(angle_deg)
    squared = side_ab ** 2 + side_ac ** 2 - 2.0 * side_ab * side_ac * math.cos(angle)
    return math.sqrt(squared)


def solve_spherical(side_ab: float, side_ac: float, angle_deg: float, radius: float) -> float:
    angle = math.radians(angle_deg)
    cosine = (
        math.cos(side_ab / radius) * math.cos(side_ac / radius)
        + math.sin(side_ab / radius) * math.sin(side_ac / radius) * math.cos(angle)
    )
    return radius * math.acos(clamp(cosine))


def solve_hyperbolic(side_ab: float, side_ac: float, angle_deg: float, radius: float) -> float:
    angle = math.radians(angle_deg)
    cosh_value = (
        math.cosh(side_ab / radius) * math.cosh(side_ac / radius)
        - math.sinh(side_ab / radius) * math.sinh(side_ac / radius) * math.cos(angle)
    )
    return radius * math.acosh(max(1.0, cosh_value))


def solve_for_world(world: str, side_ab: float, side_ac: float,
                    angle_deg: float, radius: float) -> float:
    if world == EUCLIDEAN:
        return solve_euclidean(side_ab, side_ac, angle_deg)
    if world == SPHERICAL:
        return solve_spherical(side_ab, side_ac, angle_deg, radius)
    return solve_hyperbolic(side_ab, side_ac, angle_deg, radius)


def curvature_for_world(world: str, radius: float) -> float:
    if world == EUCLIDEAN:
        return 0.0
    if world == SPHERICAL:
        return 1.0 / (radius ** 2)
    return -1.0 / (radius ** 2)



# Number helpers


def rounded(value: float) -> float:
    return round(value, DISPLAY_DECIMAL_PLACES)


def two_places(value: float) -> str:
    return f"{value:.2f}"


def one_place(value: float) -> str:
    return f"{value:.1f}"



# Lifestyle framing


INTRO_TEMPLATES = [
    "I'm helping a friend mark out a triangular patch and want to check one measurement.",
    "I'm working from a surveyor's sketch and want to make sure I've got the last side right.",
    "We're cutting a triangular sail panel and I need the third edge before I cut.",
    "I'm laying out a triangular flower bed from a plan and want to check the last side.",
    "I'm copying a triangular patch from an old survey sheet and one length is missing.",
]

SETTING_TEMPLATES = [
    "The patch sits on ground that is mapped as a surface of constant curvature.",
    "The sketch is drawn on a curved map, and all lengths are measured along the surface itself.",
    "The plan is set out on a surface of constant curvature, and every length follows the surface.",
]


def curvature_sentence(world: str, radius: float) -> str:
    curvature = curvature_for_world(world, radius)
    if world == EUCLIDEAN:
        return "The sheet gives the curvature as K = 0.00, with the radius of curvature marked as infinite."
    return (
        f"The sheet gives the curvature as K = {curvature:+.2f}, with a radius "
        f"of curvature of R = {two_places(radius)}."
    )


def geometry_sentence(side_ab: float, side_ac: float, angle_deg: float) -> str:
    return (
        f"Corner A has two edges running from it: AB is {two_places(side_ab)} and "
        f"AC is {two_places(side_ac)}, both measured along the surface, and the "
        f"angle at A between them is {one_place(angle_deg)} degrees."
    )


def build_prompt(generator: random.Random, body_lines: list[str], closing: str) -> str:
    parts = [generator.choice(INTRO_TEMPLATES), ""]
    parts.extend(body_lines)
    parts.extend(["", closing])
    return "\n".join(parts)



# Sampling a triangle


def sample_triangle(generator: random.Random, world: str) -> tuple:
    """Returns (side_ab, side_ac, angle_deg, radius, true_bc, flat_bc)."""
    while True:
        radius = generator.choice(RADIUS_CHOICES) if world != EUCLIDEAN else float("inf")

        upper = 1.5 if world == EUCLIDEAN else min(1.5, 0.6 * math.pi * (radius if world == SPHERICAL else 2.0))
        side_ab = rounded(generator.uniform(0.45, upper))
        side_ac = rounded(generator.uniform(0.45, upper))
        angle_deg = round(generator.uniform(25.0, 150.0), 1)

        if world == SPHERICAL:
            if side_ab >= math.pi * radius or side_ac >= math.pi * radius:
                continue

        try:
            true_bc = solve_for_world(world, side_ab, side_ac, angle_deg, radius)
        except (ValueError, ArithmeticError):
            continue

        if not (0.10 < true_bc < 6.0):
            continue

        flat_bc = solve_euclidean(side_ab, side_ac, angle_deg)

        if world != EUCLIDEAN and abs(true_bc - flat_bc) < MIN_PRIOR_SEPARATION:
            continue

        return side_ab, side_ac, angle_deg, radius, true_bc, flat_bc



# Answerable questions


def make_answerable_questions(
    generator: random.Random, world: str, count: int, tag: str
) -> list[SASQuestion]:
    questions: list[SASQuestion] = []

    while len(questions) < count:
        side_ab, side_ac, angle_deg, radius, true_bc, flat_bc = sample_triangle(generator, world)

        index = len(questions) + 1
        body = [
            generator.choice(SETTING_TEMPLATES),
            "",
            geometry_sentence(side_ab, side_ac, angle_deg),
            curvature_sentence(world, radius),
        ]
        question_text = build_prompt(
            generator, body,
            "How long is the third edge BC? Please give the number to two "
            "decimal places. " + ABSTAIN_INSTRUCTION,
        )

        # On a flat sheet the familiar rule is the right rule, so these
        # items cannot separate a leaked answer from a correct one. They
        # are kept as controls.
        distinguishes = world != EUCLIDEAN

        questions.append(
            SASQuestion(
                question_id=f"sas_{tag}_{index:03d}",
                latent_instance_id=f"sas_{tag}_{index:03d}",
                dataset_split="answerable",
                question_family=f"sas_{world}",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(true_bc),
                prior_predicted_answer=rounded(flat_bc) if distinguishes else None,
                prior_distinguishes=distinguishes,
                parameter_summary=json.dumps({
                    "world": world, "ab": side_ab, "ac": side_ac,
                    "angle": angle_deg,
                    "radius": None if world == EUCLIDEAN else radius,
                }),
                question_text=question_text,
            )
        )

    return questions



# 8. ABSTAIN - INCONSISTENT CONDITIONS
#
# A third side is quoted that the two edges and the angle cannot give.


def make_inconsistent_questions(generator: random.Random, count: int) -> list[SASQuestion]:
    questions: list[SASQuestion] = []
    worlds = [EUCLIDEAN, SPHERICAL, HYPERBOLIC]

    while len(questions) < count:
        world = worlds[len(questions) % 3]
        side_ab, side_ac, angle_deg, radius, true_bc, flat_bc = sample_triangle(generator, world)

        shift = rounded(generator.uniform(MIN_INCONSISTENCY_GAP, 1.20))
        quoted = rounded(true_bc + shift if generator.random() < 0.5 else true_bc - shift)
        if quoted <= 0.15:
            continue
        if abs(quoted - true_bc) < MIN_INCONSISTENCY_GAP:
            continue
        if abs(quoted - flat_bc) < MIN_INCONSISTENCY_GAP:
            continue

        # The area is asked for, so the quoted side is load bearing.
        index = len(questions) + 1
        body = [
            generator.choice(SETTING_TEMPLATES),
            "",
            geometry_sentence(side_ab, side_ac, angle_deg),
            curvature_sentence(world, radius),
            "",
            f"The sheet also records the third edge BC as {two_places(quoted)}.",
        ]
        question_text = build_prompt(
            generator, body,
            "Taking the sheet as a whole, how long is the third edge BC? Please "
            "give the number to two decimal places. "
            + ROUNDING_TOLERANCE_NOTE + " " + ABSTAIN_INSTRUCTION,
        )

        questions.append(
            SASQuestion(
                question_id=f"sas_inconsistent_{index:03d}",
                latent_instance_id=f"sas_inconsistent_{index:03d}",
                dataset_split="abstain",
                question_family="sas_quoted_side_conflicts",
                abstain_type="inconsistent",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=rounded(flat_bc),
                prior_distinguishes=True,
                parameter_summary=json.dumps({
                    "world": world, "ab": side_ab, "ac": side_ac,
                    "angle": angle_deg,
                    "radius": None if world == EUCLIDEAN else radius,
                    "quoted_bc": quoted, "true_bc": rounded(true_bc),
                }),
                question_text=question_text,
            )
        )

    return questions



# 9. ABSTAIN - GENUINELY NON-UNIQUE
#
# The angle given is not the one between the two known edges, it is the
# angle at A while the known sides are AB and the edge opposite A. Two
# different triangles then fit the same three figures.


def make_non_unique_questions(generator: random.Random, count: int) -> list[SASQuestion]:
    questions: list[SASQuestion] = []

    while len(questions) < count:
        side_ab = rounded(generator.uniform(3.00, 6.00))
        angle_deg = round(generator.uniform(25.0, 55.0), 1)
        angle = math.radians(angle_deg)

        lower = side_ab * math.sin(angle)
        side_bc = rounded(generator.uniform(lower + 0.20, side_ab - 0.20))
        if side_bc <= lower + 0.10 or side_bc >= side_ab - 0.10:
            continue

        discriminant = 4.0 * side_ab ** 2 * math.cos(angle) ** 2 - 4.0 * (side_ab ** 2 - side_bc ** 2)
        if discriminant <= 0.0:
            continue

        root = math.sqrt(discriminant)
        first = (2.0 * side_ab * math.cos(angle) - root) / 2.0
        second = (2.0 * side_ab * math.cos(angle) + root) / 2.0

        if first <= 0.20 or second <= 0.20:
            continue
        if abs(second - first) < 0.40:
            continue

        index = len(questions) + 1
        body = [
            "The patch is on flat ground, so the sheet gives the curvature as "
            "K = 0.00 and the radius of curvature as infinite.",
            "",
            f"The sheet records AB as {two_places(side_ab)} and BC as "
            f"{two_places(side_bc)}, both measured along the ground, and the "
            f"angle at corner A as {one_place(angle_deg)} degrees.",
        ]
        question_text = build_prompt(
            generator, body,
            "How long is the remaining edge AC? Please give the number to two "
            "decimal places. " + ABSTAIN_INSTRUCTION,
        )

        questions.append(
            SASQuestion(
                question_id=f"sas_nonunique_{index:03d}",
                latent_instance_id=f"sas_nonunique_{index:03d}",
                dataset_split="abstain",
                question_family="sas_two_triangles_fit",
                abstain_type="non_unique",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=rounded(second),
                prior_distinguishes=True,
                parameter_summary=json.dumps({
                    "world": EUCLIDEAN, "ab": side_ab, "bc": side_bc,
                    "angle": angle_deg,
                    "solution_one": rounded(first), "solution_two": rounded(second),
                }),
                question_text=question_text,
            )
        )

    return questions



# 10. ABSTAIN - INSUFFICIENT INFORMATION
#
# The surface is curved, but the part of the sheet giving the curvature
# has been lost. Without it the third edge cannot be worked out. A
# reader who quietly assumes flat ground gets a definite number.


def make_insufficient_questions(generator: random.Random, count: int) -> list[SASQuestion]:
    questions: list[SASQuestion] = []
    worlds = [SPHERICAL, HYPERBOLIC]

    while len(questions) < count:
        world = worlds[len(questions) % 2]
        side_ab, side_ac, angle_deg, radius, true_bc, flat_bc = sample_triangle(generator, world)

        index = len(questions) + 1
        body = [
            "The patch is on ground that the survey describes as a surface of "
            "constant curvature, and every length is measured along the surface "
            "itself.",
            "",
            geometry_sentence(side_ab, side_ac, angle_deg),
            "The corner of the sheet that gives the curvature K and the radius "
            "of curvature R has been torn off, so I cannot read either of them.",
        ]
        question_text = build_prompt(
            generator, body,
            "How long is the third edge BC? Please give the number to two "
            "decimal places. " + ABSTAIN_INSTRUCTION,
        )

        questions.append(
            SASQuestion(
                question_id=f"sas_insufficient_{index:03d}",
                latent_instance_id=f"sas_insufficient_{index:03d}",
                dataset_split="abstain",
                question_family="sas_curvature_missing",
                abstain_type="insufficient",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=rounded(flat_bc),
                prior_distinguishes=True,
                parameter_summary=json.dumps({
                    "world": world, "ab": side_ab, "ac": side_ac,
                    "angle": angle_deg, "hidden_radius": radius,
                }),
                question_text=question_text,
            )
        )

    return questions



# Independent verification


def verify_questions(questions: list[SASQuestion]) -> None:
    problems: list[str] = []

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family

        if family.startswith("sas_") and question.abstain_type == "none":
            world = parameters["world"]
            radius = parameters["radius"] if parameters["radius"] else float("inf")
            recomputed = rounded(
                solve_for_world(world, parameters["ab"], parameters["ac"],
                                parameters["angle"], radius)
            )
            if recomputed != question.expected_answer:
                problems.append(
                    f"{question.question_id}: recomputed {recomputed} vs stored {question.expected_answer}"
                )

        elif family == "sas_quoted_side_conflicts":
            gap = abs(parameters["quoted_bc"] - parameters["true_bc"])
            if gap < MIN_INCONSISTENCY_GAP:
                problems.append(f"{question.question_id}: conflict of {gap:.2f} is too small")

        elif family == "sas_two_triangles_fit":
            # Both solutions must reproduce the quoted opposite side.
            angle = math.radians(parameters["angle"])
            for key in ("solution_one", "solution_two"):
                candidate = parameters[key]
                implied = math.sqrt(
                    parameters["ab"] ** 2 + candidate ** 2
                    - 2.0 * parameters["ab"] * candidate * math.cos(angle)
                )
                if abs(implied - parameters["bc"]) > 0.02:
                    problems.append(
                        f"{question.question_id}: {key} does not reproduce BC "
                        f"({implied:.3f} vs {parameters['bc']})"
                    )
            if abs(parameters["solution_one"] - parameters["solution_two"]) < 0.30:
                problems.append(f"{question.question_id}: the two solutions are too close")

        elif family == "sas_curvature_missing":
            if "K =" in question.question_text or "R =" in question.question_text:
                problems.append(f"{question.question_id}: the curvature is still visible")

        if (
            question.prior_predicted_answer is not None
            and question.expected_answer != "ABSTAIN"
            and abs(float(question.expected_answer) - question.prior_predicted_answer) < 0.01
        ):
            problems.append(f"{question.question_id}: prior value equals the true answer")

    if problems:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(problems))

    counts: dict[str, int] = {}
    for question in questions:
        counts[question.abstain_type] = counts.get(question.abstain_type, 0) + 1
    print("Verification passed. Abstain-type counts:", counts)



# Output


OUTPUT_COLUMNS = [field.name for field in SASQuestion.__dataclass_fields__.values()]


def write_csv(questions: list[SASQuestion], output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list[SASQuestion], output_path: Path) -> None:
    family_counts: dict[str, int] = {}
    abstain_counts: dict[str, int] = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "world": "triangles on flat, spherical and hyperbolic surfaces",
        "prior_attacked": "that the flat law of cosines applies whatever the curvature",
        "note": "flat-surface items are controls, since there the familiar rule is correct",
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)



# Main


def main() -> None:
    generator = random.Random(RANDOM_SEED)

    questions: list[SASQuestion] = []
    questions.extend(make_answerable_questions(generator, EUCLIDEAN, COUNT_EUCLIDEAN, "flat"))
    questions.extend(make_answerable_questions(generator, SPHERICAL, COUNT_SPHERICAL, "sph"))
    questions.extend(make_answerable_questions(generator, HYPERBOLIC, COUNT_HYPERBOLIC, "hyp"))
    questions.extend(make_inconsistent_questions(generator, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS} questions, built {len(questions)}.")

    verify_questions(questions)
    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    answerable = [q for q in questions if q.dataset_split == "answerable"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(questions) - len(answerable)}")
    print(f"Questions with a distinguishing prior value: "
          f"{len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
