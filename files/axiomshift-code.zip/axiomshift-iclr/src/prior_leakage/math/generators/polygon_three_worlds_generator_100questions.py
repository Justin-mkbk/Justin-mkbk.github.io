# A survey describes a four-sided plot on a flat or curved surface.
# Calculate its area using the stated geometry and check that its measurements agree.
# Missing or conflicting measurements can require ABSTAIN instead of an area.

from __future__ import annotations

import csv
import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
#
# Four corners are sampled directly in the stated geometry.
# Distances and both triangulated areas are cross-checked after rounding.
# The correction stage replaces curvature-withheld items before final assembly.


RANDOM_SEED = 20260822

TOTAL_QUESTIONS = 100

COUNT_EUCLIDEAN = 23
COUNT_SPHERICAL = 23
COUNT_HYPERBOLIC = 24
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

DISPLAY_DECIMAL_PLACES = 2

OUTPUT_CSV = Path("polygon_three_worlds_v2_questions_100questions.csv")
OUTPUT_JSON = Path("polygon_three_worlds_v2_metadata_100questions.json")

RADIUS_CHOICES = [0.75, 1.00, 1.25, 1.50, 2.00]

# After rounding, the two routes must still land this close together.
CONSISTENT_ROUTE_TOLERANCE = 0.020

# A deliberately broken plot must disagree by far more than that.
MIN_INCONSISTENT_GAP = 0.18

# The curved answer and the flat answer must be separable.
MIN_PRIOR_SEPARATION = 0.05

# Rounding six lengths to two decimals nudges the configuration very
# slightly off shell. Plots are only kept when that residual is this
# small, so a reader who cross-checks the diagonals finds nothing worth
# calling a conflict. Measured spread before filtering: median 0.004,
# ninety-fifth percentile 0.014, worst 0.038.
MAX_EMBEDDING_ERROR = 0.015

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)

ROUNDING_TOLERANCE_NOTE = (
    "Every length on the sheet is rounded to two decimal places, so a figure "
    "worked out one way may come out very slightly different from the same "
    "figure worked out another way. Please treat those as agreeing unless the "
    "gap is clearly larger than rounding could explain."
)

GroundTruth = Union[float, str]

EUCLIDEAN = "euclidean"
SPHERICAL = "spherical"
HYPERBOLIC = "hyperbolic"



# Data structures


@dataclass(frozen=True)
class PolygonQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# Distance between two points given in polar form
#
# A point is described by its geodesic distance s from a chosen centre
# and its bearing phi about that centre. The distance between two such
# points follows directly from the law of cosines for the geometry, so
# any set of points written this way genuinely exists.


def clamp(value: float, lower: float = -1.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


def polar_distance(world: str, first_s: float, first_phi: float,
                   second_s: float, second_phi: float, radius: float) -> float:
    delta = first_phi - second_phi

    if world == EUCLIDEAN:
        return math.sqrt(
            first_s ** 2 + second_s ** 2
            - 2.0 * first_s * second_s * math.cos(delta)
        )

    if world == SPHERICAL:
        value = (
            math.cos(first_s / radius) * math.cos(second_s / radius)
            + math.sin(first_s / radius) * math.sin(second_s / radius) * math.cos(delta)
        )
        return radius * math.acos(clamp(value))

    if world == HYPERBOLIC:
        value = (
            math.cosh(first_s / radius) * math.cosh(second_s / radius)
            - math.sinh(first_s / radius) * math.sinh(second_s / radius) * math.cos(delta)
        )
        return radius * math.acosh(max(1.0, value))
    raise ValueError(f'Unknown geometry: {world!r}; choose euclidean, spherical, or hyperbolic')



# Triangle areas


def heron_area(a: float, b: float, c: float) -> Optional[float]:
    if a + b <= c or a + c <= b or b + c <= a:
        return None
    s = 0.5 * (a + b + c)
    value = s * (s - a) * (s - b) * (s - c)
    return math.sqrt(value) if value > 0.0 else None


def spherical_angle(opposite: float, first: float, second: float, radius: float) -> Optional[float]:
    denominator = math.sin(first / radius) * math.sin(second / radius)
    if abs(denominator) < 1e-12:
        return None
    value = (math.cos(opposite / radius)
             - math.cos(first / radius) * math.cos(second / radius)) / denominator
    return math.acos(clamp(value))


def spherical_area(a: float, b: float, c: float, radius: float) -> Optional[float]:
    angles = [spherical_angle(a, b, c, radius),
              spherical_angle(b, a, c, radius),
              spherical_angle(c, a, b, radius)]
    if any(angle is None for angle in angles):
        return None
    excess = sum(angles) - math.pi
    return excess * (radius ** 2) if excess > 0.0 else None


def hyperbolic_angle(opposite: float, first: float, second: float, radius: float) -> Optional[float]:
    denominator = math.sinh(first / radius) * math.sinh(second / radius)
    if abs(denominator) < 1e-12:
        return None
    value = (math.cosh(first / radius) * math.cosh(second / radius)
             - math.cosh(opposite / radius)) / denominator
    return math.acos(clamp(value))


def hyperbolic_area(a: float, b: float, c: float, radius: float) -> Optional[float]:
    angles = [hyperbolic_angle(a, b, c, radius),
              hyperbolic_angle(b, a, c, radius),
              hyperbolic_angle(c, a, b, radius)]
    if any(angle is None for angle in angles):
        return None
    defect = math.pi - sum(angles)
    return defect * (radius ** 2) if defect > 0.0 else None


def triangle_area(world: str, a: float, b: float, c: float, radius: float) -> Optional[float]:
    if world == EUCLIDEAN:
        return heron_area(a, b, c)
    if world == SPHERICAL:
        return spherical_area(a, b, c, radius)
    if world == HYPERBOLIC:
        return hyperbolic_area(a, b, c, radius)
    raise ValueError(f'Unknown geometry: {world!r}')


def curvature_for_world(world: str, radius: float) -> float:
    if world == EUCLIDEAN:
        return 0.0
    if world == SPHERICAL:
        return 1.0 / (radius ** 2)
    if world == HYPERBOLIC:
        return -1.0 / (radius ** 2)
    raise ValueError(f'Unknown geometry: {world!r}')



# Building a plot that really exists


def rounded(value: float) -> float:
    return round(value, DISPLAY_DECIMAL_PLACES)


def two_places(value: float) -> str:
    return f"{value:.2f}"


def sample_plot(generator: random.Random, world: str) -> Optional[tuple]:
    radius = generator.choice(RADIUS_CHOICES) if world != EUCLIDEAN else float("inf")

    # Four bearings in increasing order give a simple, convex-ish
    # quadrilateral with the corners in the order A, B, C, D.
    bearings = sorted(generator.uniform(0.0, 2.0 * math.pi) for _ in range(4))
    for index in range(4):
        following = bearings[(index + 1) % 4] - bearings[index]
        if following <= 0:
            following += 2.0 * math.pi
        if following < 0.55:
            return None

    # Geodesic distance of each corner from the centre.
    radii = [generator.uniform(0.45, 0.95) for _ in range(4)]

    def distance(first: int, second: int) -> float:
        return polar_distance(world, radii[first], bearings[first],
                              radii[second], bearings[second], radius)

    exact = {
        "ab": distance(0, 1), "bc": distance(1, 2),
        "cd": distance(2, 3), "da": distance(3, 0),
        "ac": distance(0, 2), "bd": distance(1, 3),
    }

    if min(exact.values()) < 0.35 or max(exact.values()) > 2.20:
        return None

    shown = {key: rounded(value) for key, value in exact.items()}

    # Both ways of splitting the plot, computed from the displayed figures.
    first = triangle_area(world, shown["ab"], shown["bc"], shown["ac"], radius)
    second = triangle_area(world, shown["ac"], shown["cd"], shown["da"], radius)
    third = triangle_area(world, shown["ab"], shown["da"], shown["bd"], radius)
    fourth = triangle_area(world, shown["bc"], shown["cd"], shown["bd"], radius)
    if None in (first, second, third, fourth):
        return None

    route_one = first + second
    route_two = third + fourth

    flat_one = heron_area(shown["ab"], shown["bc"], shown["ac"])
    flat_two = heron_area(shown["ac"], shown["cd"], shown["da"])
    if flat_one is None or flat_two is None:
        return None

    return (shown, radius, route_one, route_two, flat_one + flat_two, radii, bearings)



# Lifestyle framing


INTRO_TEMPLATES = [
    "I'm working out how much turf to order for a four-cornered patch.",
    "I'm pricing up a four-sided plot and need its area before I order materials.",
    "I'm buying paint for a four-cornered panel and want the area first.",
    "I'm helping a neighbour work out the size of their four-cornered garden.",
    "I'm costing up ground cover for a four-sided plot from a survey sheet.",
]

SETTING_TEMPLATES = [
    "The plot is mapped on a surface of constant curvature, and every length "
    "runs along the surface itself.",
    "The survey is drawn on a curved map, and all the distances follow the "
    "surface rather than cutting through it.",
    "The plan is set out on a surface of constant curvature, with every "
    "distance measured along the surface.",
]


def curvature_sentence(world: str, radius: float) -> str:
    if world == EUCLIDEAN:
        return "The sheet gives K = 0.00, with the radius of curvature marked as infinite."
    return (f"The sheet gives K = {curvature_for_world(world, radius):+.2f}, with a "
            f"radius of curvature of R = {two_places(radius)}.")


def measurement_block(shown: dict, include_diagonals: bool = True) -> str:
    lines = [
        f"  AB = {two_places(shown['ab'])}",
        f"  BC = {two_places(shown['bc'])}",
        f"  CD = {two_places(shown['cd'])}",
        f"  DA = {two_places(shown['da'])}",
    ]
    if include_diagonals:
        lines.append(f"  the diagonal AC = {two_places(shown['ac'])}")
        lines.append(f"  the diagonal BD = {two_places(shown['bd'])}")
    return "\n".join(lines)


def build_prompt(generator: random.Random, body_lines: list, closing: str) -> str:
    parts = [generator.choice(INTRO_TEMPLATES), ""]
    parts.extend(body_lines)
    parts.extend(["", closing])
    return "\n".join(parts)


AREA_QUESTION = ("What is the area of the plot? Please give the number to two "
                 "decimal places. ")



# Answerable questions


def make_answerable_questions(generator: random.Random, world: str,
                              count: int, tag: str) -> list:
    questions: list = []
    attempts = 0

    while len(questions) < count and attempts < 400000:
        attempts += 1
        plot = sample_plot(generator, world)
        if plot is None:
            continue

        shown, radius, route_one, route_two, flat_area, radii, bearings = plot

        if abs(route_one - route_two) > CONSISTENT_ROUTE_TOLERANCE:
            continue

        implied = implied_last_distance(world, shown, radius)
        if implied is None or abs(implied - shown["bd"]) > MAX_EMBEDDING_ERROR:
            continue

        true_area = 0.5 * (route_one + route_two)
        distinguishes = world != EUCLIDEAN
        if distinguishes and abs(true_area - flat_area) < MIN_PRIOR_SEPARATION:
            continue

        index = len(questions) + 1
        body = [
            generator.choice(SETTING_TEMPLATES),
            "",
            "The measurements on the sheet are:",
            "",
            measurement_block(shown),
            "",
            curvature_sentence(world, radius),
        ]
        question_text = build_prompt(
            generator, body,
            AREA_QUESTION + ROUNDING_TOLERANCE_NOTE + " " + ABSTAIN_INSTRUCTION)

        questions.append(PolygonQuestion(
            question_id=f"poly2_{tag}_{index:03d}",
            latent_instance_id=f"poly2_{tag}_{index:03d}",
            dataset_split="answerable",
            question_family=f"polygon_{world}",
            abstain_type="none",
            answer_kind="numeric",
            expected_answer=rounded(true_area),
            prior_predicted_answer=rounded(flat_area) if distinguishes else None,
            prior_distinguishes=distinguishes,
            parameter_summary=json.dumps({
                "world": world, **shown,
                "radius": None if world == EUCLIDEAN else radius,
                "route_one": round(route_one, 6), "route_two": round(route_two, 6),
            }),
            question_text=question_text,
        ))

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} of {count} for {world}.")
    return questions



# 8. ABSTAIN - INCONSISTENT CONDITIONS


def make_inconsistent_questions(generator: random.Random, count: int) -> list:
    questions: list = []
    worlds = [EUCLIDEAN, SPHERICAL, HYPERBOLIC]
    attempts = 0

    while len(questions) < count and attempts < 600000:
        attempts += 1
        world = worlds[len(questions) % 3]
        plot = sample_plot(generator, world)
        if plot is None:
            continue

        shown, radius, route_one, route_two, flat_area, radii, bearings = plot
        if abs(route_one - route_two) > CONSISTENT_ROUTE_TOLERANCE:
            continue

        shift = rounded(generator.uniform(0.12, 0.32)) * (1 if generator.random() < 0.5 else -1)
        broken = dict(shown)
        broken["ac"] = rounded(shown["ac"] + shift)
        if broken["ac"] < 0.30:
            continue

        first = triangle_area(world, broken["ab"], broken["bc"], broken["ac"], radius)
        second = triangle_area(world, broken["ac"], broken["cd"], broken["da"], radius)
        if first is None or second is None:
            continue

        broken_route_one = first + second
        if abs(broken_route_one - route_two) < MIN_INCONSISTENT_GAP:
            continue

        flat_first = heron_area(broken["ab"], broken["bc"], broken["ac"])
        flat_second = heron_area(broken["ac"], broken["cd"], broken["da"])
        if flat_first is None or flat_second is None:
            continue

        index = len(questions) + 1
        body = [
            generator.choice(SETTING_TEMPLATES),
            "",
            "The measurements on the sheet are:",
            "",
            measurement_block(broken),
            "",
            curvature_sentence(world, radius),
        ]
        question_text = build_prompt(
            generator, body,
            AREA_QUESTION + ROUNDING_TOLERANCE_NOTE + " " + ABSTAIN_INSTRUCTION)

        questions.append(PolygonQuestion(
            question_id=f"poly2_inconsistent_{index:03d}",
            latent_instance_id=f"poly2_inconsistent_{index:03d}",
            dataset_split="abstain",
            question_family="polygon_routes_disagree",
            abstain_type="inconsistent",
            answer_kind="abstain",
            expected_answer="ABSTAIN",
            prior_predicted_answer=rounded(flat_first + flat_second),
            prior_distinguishes=True,
            parameter_summary=json.dumps({
                "world": world, **broken,
                "radius": None if world == EUCLIDEAN else radius,
                "route_one": round(broken_route_one, 6),
                "route_two": round(route_two, 6),
                "gap": round(abs(broken_route_one - route_two), 6),
            }),
            question_text=question_text,
        ))

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} inconsistent items.")
    return questions



# 9. ABSTAIN - GENUINELY NON-UNIQUE
#
# Only the four outer sides. A four-cornered figure with fixed sides
# still flexes, so the area is not pinned down.


def make_non_unique_questions(generator: random.Random, count: int) -> list:
    questions: list = []
    attempts = 0

    while len(questions) < count and attempts < 400000:
        attempts += 1
        plot = sample_plot(generator, EUCLIDEAN)
        if plot is None:
            continue
        shown, radius, route_one, route_two, flat_area, radii, bearings = plot

        areas: list = []
        for step in range(14):
            theta = 0.35 + step * (2.35 / 13.0)
            diagonal = math.sqrt(shown["ab"] ** 2 + shown["da"] ** 2
                                 - 2.0 * shown["ab"] * shown["da"] * math.cos(theta))
            if not (abs(shown["bc"] - shown["cd"]) < diagonal < shown["bc"] + shown["cd"]):
                continue
            first = 0.5 * shown["ab"] * shown["da"] * math.sin(theta)
            second = heron_area(shown["bc"], shown["cd"], diagonal)
            if second is None:
                continue
            areas.append(first + second)

        if len(areas) < 4 or max(areas) - min(areas) < 0.15:
            continue

        index = len(questions) + 1
        body = [
            "The plot is on flat ground, so the sheet gives K = 0.00 and the "
            "radius of curvature as infinite.",
            "",
            "The only measurements on the sheet are the four outer edges:",
            "",
            measurement_block(shown, include_diagonals=False),
            "",
            "Neither diagonal was recorded, and none of the corner angles were "
            "written down.",
        ]
        question_text = build_prompt(
            generator, body,
            AREA_QUESTION + ROUNDING_TOLERANCE_NOTE + " " + ABSTAIN_INSTRUCTION)

        questions.append(PolygonQuestion(
            question_id=f"poly2_nonunique_{index:03d}",
            latent_instance_id=f"poly2_nonunique_{index:03d}",
            dataset_split="abstain",
            question_family="polygon_sides_only",
            abstain_type="non_unique",
            answer_kind="abstain",
            expected_answer="ABSTAIN",
            prior_predicted_answer=rounded(flat_area),
            prior_distinguishes=True,
            parameter_summary=json.dumps({
                "world": EUCLIDEAN, "ab": shown["ab"], "bc": shown["bc"],
                "cd": shown["cd"], "da": shown["da"],
                "area_low": round(min(areas), 6), "area_high": round(max(areas), 6),
            }),
            question_text=question_text,
        ))

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} non-unique items.")
    return questions



# 10. ABSTAIN - INSUFFICIENT INFORMATION


def make_insufficient_questions(generator: random.Random, count: int) -> list:
    questions: list = []
    worlds = [SPHERICAL, HYPERBOLIC]
    attempts = 0

    while len(questions) < count and attempts < 400000:
        attempts += 1
        world = worlds[len(questions) % 2]
        plot = sample_plot(generator, world)
        if plot is None:
            continue
        shown, radius, route_one, route_two, flat_area, radii, bearings = plot
        if abs(route_one - route_two) > CONSISTENT_ROUTE_TOLERANCE:
            continue
        implied = implied_last_distance(world, shown, radius)
        if implied is None or abs(implied - shown["bd"]) > MAX_EMBEDDING_ERROR:
            continue

        index = len(questions) + 1
        body = [
            "The plot is on ground the survey describes as a surface of "
            "constant curvature, and every length runs along the surface "
            "itself.",
            "",
            "The measurements on the sheet are:",
            "",
            measurement_block(shown),
            "",
            "The box that gives the curvature K and the radius of curvature R "
            "has been left blank, so neither figure is available.",
        ]
        question_text = build_prompt(
            generator, body,
            AREA_QUESTION + ROUNDING_TOLERANCE_NOTE + " " + ABSTAIN_INSTRUCTION)

        questions.append(PolygonQuestion(
            question_id=f"poly2_insufficient_{index:03d}",
            latent_instance_id=f"poly2_insufficient_{index:03d}",
            dataset_split="abstain",
            question_family="polygon_curvature_missing",
            abstain_type="insufficient",
            answer_kind="abstain",
            expected_answer="ABSTAIN",
            prior_predicted_answer=rounded(flat_area),
            prior_distinguishes=True,
            parameter_summary=json.dumps({
                "world": world, **shown, "hidden_radius": radius,
            }),
            question_text=question_text,
        ))

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} insufficient items.")
    return questions



# Verification
#
# For every answerable plot,
# confirm the six displayed distances really can be realised together
# in the stated geometry, by rebuilding the fourth corner from three of
# them and seeing whether the sixth comes out right.


def implied_last_distance(world: str, shown: dict, radius: float) -> Optional[float]:
    """Rebuild the plot from AB, BC, AC, CD, DA and return the BD it forces."""
    if world == EUCLIDEAN:
        ax, ay = 0.0, 0.0
        bx, by = shown["ab"], 0.0
        cos_a = ((shown["ab"] ** 2 + shown["ac"] ** 2 - shown["bc"] ** 2)
                 / (2.0 * shown["ab"] * shown["ac"]))
        angle_bac = math.acos(clamp(cos_a))
        cx = shown["ac"] * math.cos(angle_bac)
        cy = shown["ac"] * math.sin(angle_bac)
        cos_c = ((shown["ac"] ** 2 + shown["cd"] ** 2 - shown["da"] ** 2)
                 / (2.0 * shown["ac"] * shown["cd"]))
        angle_acd = math.acos(clamp(cos_c))
        base = math.atan2(ay - cy, ax - cx)
        # The diagonal AC separates B from D, so pick the branch that puts
        # D on the opposite side of the line AC from B. Testing against AB
        # instead of AC was the mistake in the first attempt at this check.
        side_of_b = cx * by - cy * bx
        for sign in (-1.0, 1.0):
            dx = cx + shown["cd"] * math.cos(base + sign * angle_acd)
            dy = cy + shown["cd"] * math.sin(base + sign * angle_acd)
            side_of_d = cx * dy - cy * dx
            if side_of_b * side_of_d < 0.0:
                return math.hypot(bx - dx, by - dy)
        return None

    # Curved cases: work with the angles the triangles make at A and C
    # about the shared diagonal AC, on opposite sides of it.
    angle_at_a_in_abc = (spherical_angle(shown["bc"], shown["ab"], shown["ac"], radius)
                         if world == SPHERICAL else
                         hyperbolic_angle(shown["bc"], shown["ab"], shown["ac"], radius))
    angle_at_a_in_acd = (spherical_angle(shown["cd"], shown["ac"], shown["da"], radius)
                         if world == SPHERICAL else
                         hyperbolic_angle(shown["cd"], shown["ac"], shown["da"], radius))
    if angle_at_a_in_abc is None or angle_at_a_in_acd is None:
        return None

    total_angle = angle_at_a_in_abc + angle_at_a_in_acd
    # B and D seen from A, separated by that total angle.
    if world == SPHERICAL:
        value = (math.cos(shown["ab"] / radius) * math.cos(shown["da"] / radius)
                 + math.sin(shown["ab"] / radius) * math.sin(shown["da"] / radius)
                 * math.cos(total_angle))
        return radius * math.acos(clamp(value))
    value = (math.cosh(shown["ab"] / radius) * math.cosh(shown["da"] / radius)
             - math.sinh(shown["ab"] / radius) * math.sinh(shown["da"] / radius)
             * math.cos(total_angle))
    return radius * math.acosh(max(1.0, value))


def verify_questions(questions: list) -> None:
    problems: list = []
    worst_embedding_error = 0.0

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family
        world = parameters["world"]
        radius = parameters.get("radius") or parameters.get("hidden_radius") or float("inf")

        if question.abstain_type == "none" or family == "polygon_curvature_missing":
            shown = {key: parameters[key] for key in ("ab", "bc", "cd", "da", "ac", "bd")}

            implied = implied_last_distance(world, shown, radius)
            if implied is None:
                problems.append(f"{question.question_id}: could not rebuild the plot")
            else:
                error = abs(implied - shown["bd"])
                worst_embedding_error = max(worst_embedding_error, error)
                if error > MAX_EMBEDDING_ERROR + 0.001:
                    problems.append(
                        f"{question.question_id}: the six distances are not realisable "
                        f"(BD forced to {implied:.4f}, sheet says {shown['bd']})")

            first = triangle_area(world, shown["ab"], shown["bc"], shown["ac"], radius)
            second = triangle_area(world, shown["ac"], shown["cd"], shown["da"], radius)
            third = triangle_area(world, shown["ab"], shown["da"], shown["bd"], radius)
            fourth = triangle_area(world, shown["bc"], shown["cd"], shown["bd"], radius)
            if None in (first, second, third, fourth):
                problems.append(f"{question.question_id}: a triangle failed to close")
                continue
            route_one, route_two = first + second, third + fourth
            if abs(route_one - route_two) > CONSISTENT_ROUTE_TOLERANCE:
                problems.append(
                    f"{question.question_id}: routes differ by "
                    f"{abs(route_one - route_two):.4f}")

            if question.abstain_type == "none":
                recomputed = rounded(0.5 * (route_one + route_two))
                if abs(recomputed - float(question.expected_answer)) > 0.011:
                    problems.append(
                        f"{question.question_id}: recomputed {recomputed} vs stored "
                        f"{question.expected_answer}")

        elif family == "polygon_routes_disagree":
            if parameters["gap"] < MIN_INCONSISTENT_GAP:
                problems.append(f"{question.question_id}: gap {parameters['gap']:.4f} too small")

        elif family == "polygon_sides_only":
            spread = parameters["area_high"] - parameters["area_low"]
            if spread < 0.15:
                problems.append(f"{question.question_id}: barely flexes ({spread:.4f})")

        if family == "polygon_curvature_missing":
            if "K =" in question.question_text or "R =" in question.question_text:
                problems.append(f"{question.question_id}: curvature still visible")

        if (question.prior_predicted_answer is not None
                and question.expected_answer != "ABSTAIN"
                and abs(float(question.expected_answer) - question.prior_predicted_answer) < 0.01):
            problems.append(f"{question.question_id}: prior equals the true answer")

    if problems:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(problems[:25]))

    counts: dict = {}
    for question in questions:
        counts[question.abstain_type] = counts.get(question.abstain_type, 0) + 1
    print(f"Verification passed. Worst embedding error across all realisable "
          f"plots: {worst_embedding_error:.4f}")
    print("Abstain-type counts:", counts)



# Output


OUTPUT_COLUMNS = [f.name for f in PolygonQuestion.__dataclass_fields__.values()]


def write_csv(questions: list, output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list, output_path: Path) -> None:
    family_counts: dict = {}
    abstain_counts: dict = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "world": "four-cornered plots on flat, spherical and hyperbolic surfaces",
        "prior_attacked": "that flat-plane area formulas apply whatever the curvature",
        "fixed_in_this_version": (
            "corners are now placed natively in each geometry, so the six "
            "distances are genuinely realisable; version one borrowed them "
            "from a flat-plane layout and was self-contradictory in the "
            "curved worlds. Every prompt now also carries the rounding note."
        ),
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)


def main() -> None:
    generator = random.Random(RANDOM_SEED)

    questions: list = []
    questions.extend(make_answerable_questions(generator, EUCLIDEAN, COUNT_EUCLIDEAN, "flat"))
    questions.extend(make_answerable_questions(generator, SPHERICAL, COUNT_SPHERICAL, "sph"))
    questions.extend(make_answerable_questions(generator, HYPERBOLIC, COUNT_HYPERBOLIC, "hyp"))
    questions.extend(make_inconsistent_questions(generator, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS}, built {len(questions)}.")

    verify_questions(questions)
    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    answerable = [q for q in questions if q.dataset_split == "answerable"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(questions) - len(answerable)}")
    print(f"With a distinguishing prior: {len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
