# The seven worlds and dataset generation

Each world contributes 100 questions: 70 have numeric answers and 30 require ABSTAIN because the supplied information is inconsistent, insufficient, or non-unique.

| World | What the reader does | Tempting prior knowledge |
|---|---|---|
| Two-mass materials | Use separate measurements of weight and resistance to acceleration to predict motion | Assuming all materials have the same free-fall acceleration |
| Altered-valence chemistry | Use the supplied combining-power table to calculate formulas, masses, and balanced reactions | Substituting familiar element valences |
| Altered codon table | Translate/count using the microbe's printed genetic code | Using the familiar genetic code instead |
| SAS triangles | Calculate a third side on a flat, spherical, or hyperbolic surface | Applying the flat-space cosine rule everywhere |
| Partial orders | Chain stated rod-length comparisons to count implied relationships | Counting only directly stated comparisons |
| Polygons | Find a plot's area and check whether its measurements agree in the stated geometry | Using flat-area formulas on curved surfaces or guessing missing information |
| Upward-demand market | Solve the explicitly stated supply and demand equations | Replacing upward-sloping demand with the familiar downward-sloping rule |

## Reproduce the published 700 questions

Install the package from the repository root, then run:

```bash
axiomshift generate --output outputs/published
```

The final recipe is:

1. Generate materials, chemistry, codons, SAS, and partial orders: **500 questions**.
2. Generate polygon and market candidates: **200 questions**.
3. Apply `axiomshift/dataset/finalize.py` and independently verify all 200 final polygon/market answers from their prompt text. For the published seed recipe, this replaces 43 candidate items.
4. Combine **500 + 200 = 700**, preserving the published order/format when no new seed is supplied.

`verification.json` must report `byte_identical: true`. Candidate CSVs are temporary; only the final question set is saved. All seven files ending `_generator_100questions.py` are active; polygon and market contain the candidate-generation algorithms. Their correction stage remains required for the published question set.

## Generate a new variant

```bash
axiomshift generate --seed 42 --output outputs/datasets/seed42
```

This samples new parameters with the same world/family/abstention balance. Each source receives a deterministic derived seed. Partial-order graphs that cannot supply enough qualifying questions are deterministically resampled; attempts and seeds are recorded. Independent mathematical verification failures stop generation. Repeated structural questions are possible.

The output directory must be new or empty. Keep its final `seven_worlds.csv`, `verification.json`, and `source_ids.json` together. Use the variant CSV as `--data` for both evaluation and analysis.

The optional [extension guide](../docs/extending.md) is only for users changing the benchmark's rules, families, or counts.
