# Elements use a printed table of combining powers that differs from the familiar one.
# Use that table to count atoms, calculate formula masses, and balance reactions.
# Remembered textbook combining powers are the tempting alternative.

from __future__ import annotations

import csv
import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
#
# Real element names and real atomic masses are used throughout.
# Only the combining powers are changed, and the changed table is
# printed in full in every prompt. A model that answers from the
# familiar combining powers instead of the printed ones lands on a
# specific, recorded wrong answer.


RANDOM_SEED = 20260813

TOTAL_QUESTIONS = 100

COUNT_FORMULA_RATIO = 25
COUNT_MOLAR_MASS = 25
COUNT_BALANCING = 20
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

MOLAR_MASS_DECIMAL_PLACES = 2

OUTPUT_CSV = Path("altered_valence_chemistry_questions_100questions.csv")
OUTPUT_JSON = Path("altered_valence_chemistry_metadata_100questions.json")

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)

ROUNDING_TOLERANCE_NOTE = (
    "The masses in the table are rounded, so please only treat something as a "
    "genuine conflict if the mismatch is clearly bigger than rounding could "
    "explain."
)

GroundTruth = Union[float, str]



# Element data
#
# Atomic masses are the real ones. "real_power" records the familiar
# combining power, used only to work out what a leaked answer would be.


@dataclass(frozen=True)
class Element:
    symbol: str
    name: str
    atomic_mass: float
    real_power: int
    role: str          # "metal" gives, "nonmetal" takes
    forms_diatomic: bool


ELEMENTS = [
    Element("Na", "sodium", 22.99, 1, "metal", False),
    Element("K", "potassium", 39.10, 1, "metal", False),
    Element("Mg", "magnesium", 24.31, 2, "metal", False),
    Element("Ca", "calcium", 40.08, 2, "metal", False),
    Element("Al", "aluminium", 26.98, 3, "metal", False),
    Element("Zn", "zinc", 65.38, 2, "metal", False),
    Element("O", "oxygen", 16.00, 2, "nonmetal", True),
    Element("S", "sulfur", 32.06, 2, "nonmetal", False),
    Element("Cl", "chlorine", 35.45, 1, "nonmetal", True),
    Element("F", "fluorine", 19.00, 1, "nonmetal", True),
    Element("N", "nitrogen", 14.01, 3, "nonmetal", True),
]

METALS = [element for element in ELEMENTS if element.role == "metal"]
NONMETALS = [element for element in ELEMENTS if element.role == "nonmetal"]

# The combining powers this world uses. Every one differs from the
# familiar value, so any leaked answer is distinguishable.
ALTERED_POWERS = {
    "Na": 2, "K": 3, "Mg": 1, "Ca": 3, "Al": 2, "Zn": 1,
    "O": 3, "S": 1, "Cl": 2, "F": 3, "N": 1,
}


def element_by_symbol(symbol: str) -> Element:
    for element in ELEMENTS:
        if element.symbol == symbol:
            return element
    raise KeyError(symbol)



# Data structures


@dataclass(frozen=True)
class ChemistryQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# The combining rule
#
# A compound of a metal with combining power p and a non-metal with
# combining power q takes the smallest whole-number counts a and b for
# which a*p equals b*q. That is a = q/gcd(p, q) and b = p/gcd(p, q).
#
# Fed the familiar combining powers, this rule reproduces ordinary
# chemistry, which is what makes the leaked answer well defined.


def simplest_counts(metal_power: int, nonmetal_power: int) -> tuple[int, int]:
    divisor = math.gcd(metal_power, nonmetal_power)
    metal_count = nonmetal_power // divisor
    nonmetal_count = metal_power // divisor
    return metal_count, nonmetal_count


def format_formula(metal: Element, nonmetal: Element, metal_count: int, nonmetal_count: int) -> str:
    metal_part = metal.symbol + ("" if metal_count == 1 else str(metal_count))
    nonmetal_part = nonmetal.symbol + ("" if nonmetal_count == 1 else str(nonmetal_count))
    return metal_part + nonmetal_part


def compound_molar_mass(
    metal: Element, nonmetal: Element, metal_count: int, nonmetal_count: int
) -> float:
    return metal_count * metal.atomic_mass + nonmetal_count * nonmetal.atomic_mass



# The printed table


def render_power_table(
    symbols: list[str],
    powers: dict,
    omitted_symbol: Optional[str] = None,
) -> str:
    lines: list[str] = []
    for symbol in symbols:
        element = element_by_symbol(symbol)
        if symbol == omitted_symbol:
            continue
        value = powers[symbol]
        if isinstance(value, tuple):
            shown = f"{value[0]} or {value[1]}"
        else:
            shown = str(value)
        lines.append(f"  {element.name} ({element.symbol}): combining power {shown}")
    return "\n".join(lines)


def render_mass_table(symbols: list[str]) -> str:
    lines: list[str] = []
    for symbol in symbols:
        element = element_by_symbol(symbol)
        lines.append(f"  {element.name} ({element.symbol}): {element.atomic_mass:.2f}")
    return "\n".join(lines)


WORLD_RULES_TEMPLATE = (
    "{possessive_capitalised} textbook has a table of combining powers at the "
    "front, and the chapter says a compound of two elements takes the smallest "
    "whole numbers of atoms for which the total combining power on each side "
    "matches.\n\n"
    "The combining powers in {possessive} table are:\n\n"
    "{power_table}\n\n"
    "The relative atomic masses in the same table are:\n\n"
    "{mass_table}"
)

# Each intro is paired with the possessive the world text should use, so
# the pronouns stay consistent through the whole prompt.
INTRO_TEMPLATES = [
    (
        "I'm helping my niece with her chemistry homework and I want to make "
        "sure I've followed her textbook properly.",
        "her",
    ),
    (
        "I'm going through a chemistry worksheet with my daughter and I'd like "
        "to check I've read her textbook's table right.",
        "her",
    ),
    (
        "I'm tutoring a neighbour's son in chemistry this term and want to be "
        "sure I'm using his textbook consistently.",
        "his",
    ),
    (
        "My son asked me for help with a chemistry question and I'm working "
        "from the table in his textbook.",
        "his",
    ),
]


def build_world_text(
    symbols: list[str],
    powers: dict,
    possessive: str,
    omitted_symbol: Optional[str] = None,
) -> str:
    return WORLD_RULES_TEMPLATE.format(
        possessive=possessive,
        possessive_capitalised=possessive.capitalize(),
        power_table=render_power_table(symbols, powers, omitted_symbol),
        mass_table=render_mass_table(symbols),
    )


def choose_table_symbols(
    generator: random.Random, must_include: list[str]
) -> list[str]:
    """Builds a table that always contains the elements the question needs,
    plus a few distractors, so the table is never a giveaway."""
    chosen = list(must_include)
    remaining = [element.symbol for element in ELEMENTS if element.symbol not in chosen]
    generator.shuffle(remaining)
    extra_count = generator.randint(2, 4)
    chosen.extend(remaining[:extra_count])
    generator.shuffle(chosen)
    return chosen



# 6. FAMILY A - HOW MANY ATOMS


def make_formula_ratio_questions(generator: random.Random, count: int) -> list[ChemistryQuestion]:
    questions: list[ChemistryQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 20000:
        attempts += 1

        metal = generator.choice(METALS)
        nonmetal = generator.choice(NONMETALS)

        altered_metal_power = ALTERED_POWERS[metal.symbol]
        altered_nonmetal_power = ALTERED_POWERS[nonmetal.symbol]

        metal_count, nonmetal_count = simplest_counts(altered_metal_power, altered_nonmetal_power)
        real_metal_count, real_nonmetal_count = simplest_counts(metal.real_power, nonmetal.real_power)

        # Ask about whichever element the two tables actually disagree on.
        if nonmetal_count != real_nonmetal_count:
            asked_element = nonmetal
            true_answer = nonmetal_count
            prior_answer = real_nonmetal_count
        elif metal_count != real_metal_count:
            asked_element = metal
            true_answer = metal_count
            prior_answer = real_metal_count
        else:
            continue

        index = len(questions) + 1
        symbols = choose_table_symbols(generator, [metal.symbol, nonmetal.symbol])
        intro_text, possessive = generator.choice(INTRO_TEMPLATES)
        world_text = build_world_text(symbols, ALTERED_POWERS, possessive)

        question_text = (
            intro_text
            + "\n\n"
            + world_text
            + "\n\n"
            + f"The exercise asks for the simplest compound of {metal.name} and "
            + f"{nonmetal.name}. In one formula unit of that compound, how many "
            + f"atoms of {asked_element.name} are there? Please give a whole "
            + "number. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            ChemistryQuestion(
                question_id=f"chem_ratio_{index:03d}",
                latent_instance_id=f"chem_ratio_{index:03d}",
                dataset_split="answerable",
                question_family="formula_ratio",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=float(true_answer),
                prior_predicted_answer=float(prior_answer),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "metal": metal.symbol, "nonmetal": nonmetal.symbol,
                        "asked": asked_element.symbol,
                        "formula": format_formula(metal, nonmetal, metal_count, nonmetal_count),
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 7. FAMILY B - MOLAR MASS OF THE COMPOUND


def make_molar_mass_questions(generator: random.Random, count: int) -> list[ChemistryQuestion]:
    questions: list[ChemistryQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 20000:
        attempts += 1

        metal = generator.choice(METALS)
        nonmetal = generator.choice(NONMETALS)

        metal_count, nonmetal_count = simplest_counts(
            ALTERED_POWERS[metal.symbol], ALTERED_POWERS[nonmetal.symbol]
        )
        real_metal_count, real_nonmetal_count = simplest_counts(metal.real_power, nonmetal.real_power)

        if (metal_count, nonmetal_count) == (real_metal_count, real_nonmetal_count):
            continue

        true_mass = compound_molar_mass(metal, nonmetal, metal_count, nonmetal_count)
        prior_mass = compound_molar_mass(metal, nonmetal, real_metal_count, real_nonmetal_count)

        if abs(true_mass - prior_mass) < 1.0:
            continue

        index = len(questions) + 1
        symbols = choose_table_symbols(generator, [metal.symbol, nonmetal.symbol])
        intro_text, possessive = generator.choice(INTRO_TEMPLATES)
        world_text = build_world_text(symbols, ALTERED_POWERS, possessive)

        question_text = (
            intro_text
            + "\n\n"
            + world_text
            + "\n\n"
            + f"The question asks about the simplest compound of {metal.name} "
            + f"and {nonmetal.name}. What is the relative formula mass of one "
            + "formula unit of it? Please give the number to two decimal "
            + "places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            ChemistryQuestion(
                question_id=f"chem_mass_{index:03d}",
                latent_instance_id=f"chem_mass_{index:03d}",
                dataset_split="answerable",
                question_family="molar_mass",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=round(true_mass, MOLAR_MASS_DECIMAL_PLACES),
                prior_predicted_answer=round(prior_mass, MOLAR_MASS_DECIMAL_PLACES),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "metal": metal.symbol, "nonmetal": nonmetal.symbol,
                        "counts": [metal_count, nonmetal_count],
                        "formula": format_formula(metal, nonmetal, metal_count, nonmetal_count),
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 8. FAMILY C - BALANCING A REACTION
#
# The reaction is  c1 X  +  c2 Y2  ->  c3 (X_a Y_b), with Y a gas that
# travels as pairs of atoms. Balancing gives c3 = 1 when b is even and
# c3 = 2 when b is odd, then c1 = c3*a and c2 = c3*b/2.


def balancing_coefficients(metal_count: int, nonmetal_count: int) -> tuple[int, int, int]:
    if nonmetal_count % 2 == 0:
        compound_coefficient = 1
    else:
        compound_coefficient = 2
    metal_coefficient = compound_coefficient * metal_count
    gas_coefficient = compound_coefficient * nonmetal_count // 2
    return metal_coefficient, gas_coefficient, compound_coefficient


def make_balancing_questions(generator: random.Random, count: int) -> list[ChemistryQuestion]:
    questions: list[ChemistryQuestion] = []
    attempts = 0
    diatomic_nonmetals = [element for element in NONMETALS if element.forms_diatomic]

    while len(questions) < count and attempts < 20000:
        attempts += 1

        metal = generator.choice(METALS)
        nonmetal = generator.choice(diatomic_nonmetals)

        metal_count, nonmetal_count = simplest_counts(
            ALTERED_POWERS[metal.symbol], ALTERED_POWERS[nonmetal.symbol]
        )
        real_metal_count, real_nonmetal_count = simplest_counts(metal.real_power, nonmetal.real_power)

        true_coefficients = balancing_coefficients(metal_count, nonmetal_count)
        prior_coefficients = balancing_coefficients(real_metal_count, real_nonmetal_count)

        # Ask for the gas coefficient, and only when the two differ.
        if true_coefficients[1] == prior_coefficients[1]:
            continue

        index = len(questions) + 1
        symbols = choose_table_symbols(generator, [metal.symbol, nonmetal.symbol])
        intro_text, possessive = generator.choice(INTRO_TEMPLATES)
        world_text = build_world_text(symbols, ALTERED_POWERS, possessive)

        question_text = (
            intro_text
            + "\n\n"
            + world_text
            + "\n\n"
            + f"The worksheet says {nonmetal.name} gas travels as pairs of "
            + f"atoms, written {nonmetal.symbol}2, and asks her to balance this "
            + "reaction using the smallest whole numbers:\n\n"
            + f"  {metal.symbol} + {nonmetal.symbol}2 --> the simplest compound "
            + f"of {metal.name} and {nonmetal.name}\n\n"
            + f"Once it is balanced, what number goes in front of "
            + f"{nonmetal.symbol}2? Please give a whole number. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            ChemistryQuestion(
                question_id=f"chem_balance_{index:03d}",
                latent_instance_id=f"chem_balance_{index:03d}",
                dataset_split="answerable",
                question_family="balancing",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=float(true_coefficients[1]),
                prior_predicted_answer=float(prior_coefficients[1]),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "metal": metal.symbol, "nonmetal": nonmetal.symbol,
                        "counts": [metal_count, nonmetal_count],
                        "coefficients": list(true_coefficients),
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 9. ABSTAIN - INSUFFICIENT INFORMATION
#
# One of the two elements the question needs is left out of the printed
# table, so its combining power is simply not available. A model that
# fills the gap from memory answers confidently.


def make_insufficient_questions(generator: random.Random, count: int) -> list[ChemistryQuestion]:
    questions: list[ChemistryQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 20000:
        attempts += 1

        metal = generator.choice(METALS)
        nonmetal = generator.choice(NONMETALS)

        omitted = generator.choice([metal, nonmetal])

        real_metal_count, real_nonmetal_count = simplest_counts(metal.real_power, nonmetal.real_power)
        prior_mass = compound_molar_mass(metal, nonmetal, real_metal_count, real_nonmetal_count)

        index = len(questions) + 1
        symbols = choose_table_symbols(generator, [metal.symbol, nonmetal.symbol])
        intro_text, possessive = generator.choice(INTRO_TEMPLATES)
        world_text = build_world_text(
            symbols, ALTERED_POWERS, possessive, omitted_symbol=omitted.symbol
        )

        question_text = (
            intro_text
            + "\n\n"
            + world_text
            + "\n\n"
            + f"The question asks about the simplest compound of {metal.name} "
            + f"and {nonmetal.name}. What is the relative formula mass of one "
            + "formula unit of it? Please give the number to two decimal "
            + "places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            ChemistryQuestion(
                question_id=f"chem_insufficient_{index:03d}",
                latent_instance_id=f"chem_insufficient_{index:03d}",
                dataset_split="abstain",
                question_family="molar_mass_missing_power",
                abstain_type="insufficient",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=round(prior_mass, MOLAR_MASS_DECIMAL_PLACES),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "metal": metal.symbol, "nonmetal": nonmetal.symbol,
                        "omitted": omitted.symbol,
                        "table": symbols,
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 10. ABSTAIN - GENUINELY NON-UNIQUE
#
# One element is listed with two combining powers and nothing in the
# question says which applies, so two different compounds both satisfy
# the printed rules.


def make_non_unique_questions(generator: random.Random, count: int) -> list[ChemistryQuestion]:
    questions: list[ChemistryQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 20000:
        attempts += 1

        metal = generator.choice(METALS)
        nonmetal = generator.choice(NONMETALS)

        # Give the metal two possible combining powers.
        first_power = ALTERED_POWERS[metal.symbol]
        second_power = generator.choice([p for p in [1, 2, 3, 4] if p != first_power])

        nonmetal_power = ALTERED_POWERS[nonmetal.symbol]

        first_counts = simplest_counts(first_power, nonmetal_power)
        second_counts = simplest_counts(second_power, nonmetal_power)

        if first_counts == second_counts:
            continue

        first_mass = compound_molar_mass(metal, nonmetal, first_counts[0], first_counts[1])
        second_mass = compound_molar_mass(metal, nonmetal, second_counts[0], second_counts[1])

        if abs(first_mass - second_mass) < 1.0:
            continue

        real_metal_count, real_nonmetal_count = simplest_counts(metal.real_power, nonmetal.real_power)
        prior_mass = compound_molar_mass(metal, nonmetal, real_metal_count, real_nonmetal_count)

        index = len(questions) + 1
        symbols = choose_table_symbols(generator, [metal.symbol, nonmetal.symbol])

        powers_with_choice = dict(ALTERED_POWERS)
        powers_with_choice[metal.symbol] = (first_power, second_power)
        intro_text, possessive = generator.choice(INTRO_TEMPLATES)
        world_text = build_world_text(symbols, powers_with_choice, possessive)

        question_text = (
            intro_text
            + "\n\n"
            + world_text
            + "\n\n"
            + f"The question asks about the simplest compound of {metal.name} "
            + f"and {nonmetal.name}. What is the relative formula mass of one "
            + "formula unit of it? Please give the number to two decimal "
            + "places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            ChemistryQuestion(
                question_id=f"chem_nonunique_{index:03d}",
                latent_instance_id=f"chem_nonunique_{index:03d}",
                dataset_split="abstain",
                question_family="molar_mass_two_powers",
                abstain_type="non_unique",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=round(prior_mass, MOLAR_MASS_DECIMAL_PLACES),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "metal": metal.symbol, "nonmetal": nonmetal.symbol,
                        "powers": [first_power, second_power],
                        "mass_options": [
                            round(first_mass, 2), round(second_mass, 2)
                        ],
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 11. ABSTAIN - INCONSISTENT CONDITIONS
#
# The worksheet states a formula outright, and that formula cannot be
# reconciled with the combining powers printed in the same table.


def make_inconsistent_questions(generator: random.Random, count: int) -> list[ChemistryQuestion]:
    questions: list[ChemistryQuestion] = []
    attempts = 0

    while len(questions) < count and attempts < 20000:
        attempts += 1

        metal = generator.choice(METALS)
        nonmetal = generator.choice(NONMETALS)

        metal_power = ALTERED_POWERS[metal.symbol]
        nonmetal_power = ALTERED_POWERS[nonmetal.symbol]
        true_counts = simplest_counts(metal_power, nonmetal_power)

        # Quote a formula whose totals genuinely cannot balance.
        stated_metal_count = generator.randint(1, 4)
        stated_nonmetal_count = generator.randint(1, 4)

        if stated_metal_count * metal_power == stated_nonmetal_count * nonmetal_power:
            continue
        if (stated_metal_count, stated_nonmetal_count) == true_counts:
            continue

        stated_formula = format_formula(
            metal, nonmetal, stated_metal_count, stated_nonmetal_count
        )
        stated_mass = compound_molar_mass(
            metal, nonmetal, stated_metal_count, stated_nonmetal_count
        )

        index = len(questions) + 1
        symbols = choose_table_symbols(generator, [metal.symbol, nonmetal.symbol])
        intro_text, possessive = generator.choice(INTRO_TEMPLATES)
        world_text = build_world_text(symbols, ALTERED_POWERS, possessive)

        question_text = (
            intro_text
            + "\n\n"
            + world_text
            + "\n\n"
            + f"The worksheet states that {metal.name} and {nonmetal.name} form "
            + f"the compound {stated_formula}, and asks for the relative "
            + "formula mass of one formula unit of it. Please give the number "
            + "to two decimal places. "
            + ROUNDING_TOLERANCE_NOTE
            + " "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            ChemistryQuestion(
                question_id=f"chem_inconsistent_{index:03d}",
                latent_instance_id=f"chem_inconsistent_{index:03d}",
                dataset_split="abstain",
                question_family="stated_formula_conflicts",
                abstain_type="inconsistent",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=round(stated_mass, MOLAR_MASS_DECIMAL_PLACES),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "metal": metal.symbol, "nonmetal": nonmetal.symbol,
                        "stated": [stated_metal_count, stated_nonmetal_count],
                        "powers": [metal_power, nonmetal_power],
                        "formula": stated_formula,
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# Independent verification


def verify_questions(questions: list[ChemistryQuestion]) -> None:
    mismatches: list[str] = []

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family

        if family == "formula_ratio":
            metal = element_by_symbol(parameters["metal"])
            nonmetal = element_by_symbol(parameters["nonmetal"])
            counts = simplest_counts(
                ALTERED_POWERS[metal.symbol], ALTERED_POWERS[nonmetal.symbol]
            )
            asked = parameters["asked"]
            recomputed = float(counts[0] if asked == metal.symbol else counts[1])

        elif family == "molar_mass":
            metal = element_by_symbol(parameters["metal"])
            nonmetal = element_by_symbol(parameters["nonmetal"])
            counts = simplest_counts(
                ALTERED_POWERS[metal.symbol], ALTERED_POWERS[nonmetal.symbol]
            )
            recomputed = round(
                compound_molar_mass(metal, nonmetal, counts[0], counts[1]), 2
            )

        elif family == "balancing":
            metal = element_by_symbol(parameters["metal"])
            nonmetal = element_by_symbol(parameters["nonmetal"])
            counts = simplest_counts(
                ALTERED_POWERS[metal.symbol], ALTERED_POWERS[nonmetal.symbol]
            )
            coefficients = balancing_coefficients(counts[0], counts[1])
            # Confirm the equation really does balance.
            metal_left = coefficients[0]
            metal_right = coefficients[2] * counts[0]
            gas_left = coefficients[1] * 2
            gas_right = coefficients[2] * counts[1]
            if metal_left != metal_right or gas_left != gas_right:
                mismatches.append(f"{question.question_id}: equation does not balance")
            recomputed = float(coefficients[1])

        elif family == "molar_mass_missing_power":
            if parameters["omitted"] in {parameters["metal"], parameters["nonmetal"]}:
                recomputed = "ABSTAIN"
            else:
                mismatches.append(f"{question.question_id}: the omitted element was not needed")
                recomputed = "ABSTAIN"

        elif family == "molar_mass_two_powers":
            options = parameters["mass_options"]
            if abs(options[0] - options[1]) < 1.0:
                mismatches.append(f"{question.question_id}: the two options are too close")
            recomputed = "ABSTAIN"

        elif family == "stated_formula_conflicts":
            stated = parameters["stated"]
            powers = parameters["powers"]
            if stated[0] * powers[0] == stated[1] * powers[1]:
                mismatches.append(f"{question.question_id}: stated formula actually balances")
            recomputed = "ABSTAIN"

        else:
            mismatches.append(f"{question.question_id}: unrecognised family {family}")
            continue

        if recomputed != question.expected_answer:
            mismatches.append(
                f"{question.question_id}: recomputed {recomputed} vs stored {question.expected_answer}"
            )

    if mismatches:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(mismatches))

    abstain_counts: dict[str, int] = {}
    for question in questions:
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1
    print("Verification passed. Abstain-type counts:", abstain_counts)


def verify_rule_reproduces_real_chemistry() -> None:
    """The combining rule must give ordinary chemistry when fed the familiar
    combining powers, otherwise the recorded prior answer is meaningless."""
    checks = [
        ("Na", "O", "Na2O"),
        ("Mg", "O", "MgO"),
        ("Al", "O", "Al2O3"),
        ("Ca", "Cl", "CaCl2"),
        ("K", "S", "K2S"),
    ]
    for metal_symbol, nonmetal_symbol, expected_formula in checks:
        metal = element_by_symbol(metal_symbol)
        nonmetal = element_by_symbol(nonmetal_symbol)
        counts = simplest_counts(metal.real_power, nonmetal.real_power)
        produced = format_formula(metal, nonmetal, counts[0], counts[1])
        if produced != expected_formula:
            raise AssertionError(
                f"Rule check failed: {metal_symbol}+{nonmetal_symbol} gave "
                f"{produced}, expected {expected_formula}"
            )
    print("Combining rule reproduces ordinary chemistry on the familiar powers.")



# Output


OUTPUT_COLUMNS = [field.name for field in ChemistryQuestion.__dataclass_fields__.values()]


def write_csv(questions: list[ChemistryQuestion], output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list[ChemistryQuestion], output_path: Path) -> None:
    family_counts: dict[str, int] = {}
    abstain_counts: dict[str, int] = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "altered_powers": ALTERED_POWERS,
        "real_powers": {element.symbol: element.real_power for element in ELEMENTS},
        "world": "ordinary elements and masses with a changed table of combining powers",
        "prior_attacked": "memorised valences and memorised formulas such as water and common oxides",
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)



# Main


def main() -> None:
    verify_rule_reproduces_real_chemistry()

    generator = random.Random(RANDOM_SEED)

    questions: list[ChemistryQuestion] = []
    questions.extend(make_formula_ratio_questions(generator, COUNT_FORMULA_RATIO))
    questions.extend(make_molar_mass_questions(generator, COUNT_MOLAR_MASS))
    questions.extend(make_balancing_questions(generator, COUNT_BALANCING))
    questions.extend(make_inconsistent_questions(generator, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS} questions, built {len(questions)}.")

    verify_questions(questions)

    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    print(f"Wrote metadata to {OUTPUT_JSON.resolve()}")

    answerable = [q for q in questions if q.dataset_split == "answerable"]
    abstain = [q for q in questions if q.dataset_split == "abstain"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(abstain)}")
    print(f"Questions where the prior gives a different answer: "
          f"{len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
