# A microbe uses a printed genetic translation table.
# Count amino acids or bases using that table, including its stated stop signals.
# The familiar genetic code can lead to a different count.

from __future__ import annotations

import csv
import json
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
#
# A microbe whose translation table differs from the familiar one. The
# table is printed in full in every prompt, so nothing has to be
# remembered. Real organisms do reassign codons, so the world is not
# even unusual, only unfamiliar.
#
# Every answer is a whole number, which keeps the existing numeric
# evaluator usable without change.


RANDOM_SEED = 20260816

TOTAL_QUESTIONS = 100

COUNT_CHAIN_LENGTH = 20
COUNT_RESIDUE_COUNT = 20
COUNT_BASES_USED = 15
COUNT_SYNONYM_COUNT = 15
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

OUTPUT_CSV = Path("altered_codon_table_questions_100questions.csv")
OUTPUT_JSON = Path("altered_codon_table_metadata_100questions.json")

# A stated chain length must miss the true one by at least this much,
# so the conflict can never be read as an off-by-one slip.
MIN_LENGTH_CONFLICT = 2

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)

EXACT_COUNTS_NOTE = (
    "The counts printed on the card are exact whole numbers rather than "
    "estimates, so a mismatch of one or more is a real conflict rather than "
    "a rounding artefact."
)

GroundTruth = Union[int, str]

BASES = ["U", "C", "A", "G"]



# The familiar table
#
# Used only to work out what answer a reader would get from memory.
# It is never shown to the model.


STANDARD_CODE = {
    "UUU": "Phe", "UUC": "Phe", "UUA": "Leu", "UUG": "Leu",
    "CUU": "Leu", "CUC": "Leu", "CUA": "Leu", "CUG": "Leu",
    "AUU": "Ile", "AUC": "Ile", "AUA": "Ile", "AUG": "Met",
    "GUU": "Val", "GUC": "Val", "GUA": "Val", "GUG": "Val",
    "UCU": "Ser", "UCC": "Ser", "UCA": "Ser", "UCG": "Ser",
    "CCU": "Pro", "CCC": "Pro", "CCA": "Pro", "CCG": "Pro",
    "ACU": "Thr", "ACC": "Thr", "ACA": "Thr", "ACG": "Thr",
    "GCU": "Ala", "GCC": "Ala", "GCA": "Ala", "GCG": "Ala",
    "UAU": "Tyr", "UAC": "Tyr", "UAA": "STOP", "UAG": "STOP",
    "CAU": "His", "CAC": "His", "CAA": "Gln", "CAG": "Gln",
    "AAU": "Asn", "AAC": "Asn", "AAA": "Lys", "AAG": "Lys",
    "GAU": "Asp", "GAC": "Asp", "GAA": "Glu", "GAG": "Glu",
    "UGU": "Cys", "UGC": "Cys", "UGA": "STOP", "UGG": "Trp",
    "CGU": "Arg", "CGC": "Arg", "CGA": "Arg", "CGG": "Arg",
    "AGU": "Ser", "AGC": "Ser", "AGA": "Arg", "AGG": "Arg",
    "GGU": "Gly", "GGC": "Gly", "GGA": "Gly", "GGG": "Gly",
}


def all_codons() -> list[str]:
    codons: list[str] = []
    for first in BASES:
        for second in BASES:
            for third in BASES:
                codons.append(first + second + third)
    return codons


CODONS = all_codons()



# Data structures


@dataclass(frozen=True)
class CodonQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# 4. BUILDING THE MICROBE'S TABLE
#
# The assignments of the familiar table are shuffled across the codons.
# That keeps the same number of codons per amino acid and the same
# number of stops, so the table looks like a plausible variant code
# rather than an obviously arbitrary one.


def build_altered_code(generator: random.Random) -> dict:
    assignments = [STANDARD_CODE[codon] for codon in CODONS]
    while True:
        generator.shuffle(assignments)
        altered = dict(zip(CODONS, assignments))

        # It must differ from the familiar table on most codons,
        # otherwise a leaked answer would often be right by accident.
        differences = sum(1 for codon in CODONS if altered[codon] != STANDARD_CODE[codon])
        if differences < 55:
            continue

        # None of the three stops may sit where a familiar stop sits.
        altered_stops = {c for c in CODONS if altered[c] == "STOP"}
        standard_stops = {c for c in CODONS if STANDARD_CODE[c] == "STOP"}
        if altered_stops & standard_stops:
            continue

        return altered


def stop_codons(code: dict) -> list[str]:
    return [codon for codon in CODONS if code[codon] == "STOP"]


def sense_codons(code: dict) -> list[str]:
    return [codon for codon in CODONS if code[codon] != "STOP"]



# Rendering the card


def render_code_table(
    code: dict,
    omitted: Optional[str] = None,
    ambiguous: Optional[tuple] = None,
) -> str:
    """Four codons per line. A codon may be left out entirely, or shown
    with two possible readings."""
    entries: list[str] = []
    for codon in CODONS:
        if codon == omitted:
            continue
        if ambiguous is not None and codon == ambiguous[0]:
            entries.append(f"{codon} = {ambiguous[1]} or {ambiguous[2]}")
        else:
            entries.append(f"{codon} = {code[codon]}")

    lines: list[str] = []
    for start in range(0, len(entries), 4):
        lines.append("  " + "   ".join(entry.ljust(14) for entry in entries[start:start + 4]).rstrip())
    return "\n".join(lines)


WORLD_RULES = (
    "The card is about a microbe from a deep-sea vent that reads its genetic "
    "material with its own translation table. The table is printed in full on "
    "the card:\n\n"
    "{table}\n\n"
    "The card also explains how to read a stretch of the microbe's message:\n\n"
    "  The stretch below is already lined up, so read it in threes starting "
    "from the very first letter.\n"
    "  Look each triple up in the table above.\n"
    "  Reading stops at the first triple marked STOP, and that triple is not "
    "part of the finished chain."
)

INTRO_TEMPLATES = [
    "I'm helping put together a display card for the local science museum and "
    "want to check I've read it correctly.",
    "I volunteer at the science museum and I'm proofreading one of the new "
    "display cards.",
    "My reading group went to the science museum and I'm still puzzling over "
    "one of the cards.",
    "I'm writing up some notes from a museum visit and want to make sure I "
    "followed the card properly.",
]


def build_prompt(
    generator: random.Random,
    code: dict,
    sequence: str,
    tail: str,
    omitted: Optional[str] = None,
    ambiguous: Optional[tuple] = None,
    extra_sentence: str = "",
    closing: str = "",
) -> str:
    table_text = render_code_table(code, omitted=omitted, ambiguous=ambiguous)
    parts = [
        generator.choice(INTRO_TEMPLATES),
        "",
        WORLD_RULES.format(table=table_text),
        "",
        "The stretch printed on the card is:",
        "",
        "  " + sequence,
    ]
    if extra_sentence:
        parts.extend(["", extra_sentence])
    parts.extend(["", closing])
    return "\n".join(parts)



# Building a message


def build_sequence(
    generator: random.Random, code: dict, chain_length: int
) -> tuple[str, list[str]]:
    """Returns the printed sequence and the list of codons in it. The
    first chain_length codons are sense codons, then one stop, then a
    short tail so the stretch does not end exactly at the stop."""
    senses = sense_codons(code)
    stops = stop_codons(code)

    codons = [generator.choice(senses) for _ in range(chain_length)]
    codons.append(generator.choice(stops))
    for _ in range(generator.randint(1, 3)):
        codons.append(generator.choice(CODONS))

    return "".join(codons), codons


def read_chain(codons: list[str], code: dict) -> Optional[list[str]]:
    """Amino acids up to the first stop. None if no stop is reached."""
    chain: list[str] = []
    for codon in codons:
        if codon not in code:
            return None
        if code[codon] == "STOP":
            return chain
        chain.append(code[codon])
    return None


def standard_chain(codons: list[str]) -> list[str]:
    """What a reader working from the familiar table would get. If no
    familiar stop appears, the whole stretch is translated."""
    chain: list[str] = []
    for codon in codons:
        if STANDARD_CODE[codon] == "STOP":
            return chain
        chain.append(STANDARD_CODE[codon])
    return chain


def standard_reaches_stop(codons: list[str]) -> bool:
    return any(STANDARD_CODE[codon] == "STOP" for codon in codons)



# 7. FAMILY D1 - LENGTH OF THE FINISHED CHAIN


def make_chain_length_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []

    while len(questions) < count:
        chain_length = generator.randint(5, 12)
        sequence, codons = build_sequence(generator, code, chain_length)

        true_chain = read_chain(codons, code)
        if true_chain is None or len(true_chain) != chain_length:
            continue

        prior_length = len(standard_chain(codons))
        if prior_length == chain_length:
            continue

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            closing=(
                "How many links long is the finished chain? Please give a whole "
                "number. " + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_length_{index:03d}",
                latent_instance_id=f"codon_length_{index:03d}",
                dataset_split="answerable",
                question_family="chain_length",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=chain_length,
                prior_predicted_answer=float(prior_length),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"codons": codons}),
                question_text=question_text,
            )
        )

    return questions



# 8. FAMILY D2 - HOW OFTEN ONE UNIT APPEARS


def make_residue_count_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []

    while len(questions) < count:
        chain_length = generator.randint(6, 12)
        sequence, codons = build_sequence(generator, code, chain_length)

        true_chain = read_chain(codons, code)
        if true_chain is None or len(true_chain) != chain_length:
            continue

        target = generator.choice(sorted(set(true_chain)))
        true_count = true_chain.count(target)
        prior_count = standard_chain(codons).count(target)

        if true_count == prior_count:
            continue

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            closing=(
                f"How many times does {target} appear in the finished chain? "
                "Please give a whole number. " + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_residue_{index:03d}",
                latent_instance_id=f"codon_residue_{index:03d}",
                dataset_split="answerable",
                question_family="residue_count",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=true_count,
                prior_predicted_answer=float(prior_count),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"codons": codons, "target": target}),
                question_text=question_text,
            )
        )

    return questions



# 9. FAMILY D3 - LETTERS USED UP


def make_bases_used_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []

    while len(questions) < count:
        chain_length = generator.randint(5, 12)
        sequence, codons = build_sequence(generator, code, chain_length)

        true_chain = read_chain(codons, code)
        if true_chain is None or len(true_chain) != chain_length:
            continue

        true_bases = 3 * (chain_length + 1)

        if standard_reaches_stop(codons):
            prior_bases = 3 * (len(standard_chain(codons)) + 1)
        else:
            prior_bases = 3 * len(codons)

        if true_bases == prior_bases:
            continue

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            closing=(
                "Counting from the very first letter up to and including the "
                "triple that stops the reading, how many letters are used up? "
                "Please give a whole number. " + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_bases_{index:03d}",
                latent_instance_id=f"codon_bases_{index:03d}",
                dataset_split="answerable",
                question_family="bases_used",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=true_bases,
                prior_predicted_answer=float(prior_bases),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"codons": codons}),
                question_text=question_text,
            )
        )

    return questions



# 10. FAMILY D4 - HOW MANY TRIPLES SHARE A READING


def make_synonym_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []
    used: set[str] = set()

    while len(questions) < count:
        codon = generator.choice(CODONS)
        if codon in used:
            continue

        target = code[codon]
        if target == "STOP":
            continue

        true_count = sum(1 for other in CODONS if code[other] == target)
        standard_target = STANDARD_CODE[codon]
        prior_count = sum(1 for other in CODONS if STANDARD_CODE[other] == standard_target)

        if true_count == prior_count:
            continue

        used.add(codon)
        chain_length = generator.randint(5, 9)
        sequence, codons = build_sequence(generator, code, chain_length)

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            closing=(
                f"Looking at the table on the card, the triple {codon} is read "
                f"as {target}. How many of the triples in the whole table are "
                f"read as {target}? Please give a whole number. "
                + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_synonym_{index:03d}",
                latent_instance_id=f"codon_synonym_{index:03d}",
                dataset_split="answerable",
                question_family="synonym_count",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=true_count,
                prior_predicted_answer=float(prior_count),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"codon": codon, "reading": target}),
                question_text=question_text,
            )
        )

    return questions



# 11. ABSTAIN - INCONSISTENT CONDITIONS
#
# The card states a chain length that the table and the stretch cannot
# produce.


def make_inconsistent_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []

    while len(questions) < count:
        chain_length = generator.randint(6, 12)
        sequence, codons = build_sequence(generator, code, chain_length)

        true_chain = read_chain(codons, code)
        if true_chain is None or len(true_chain) != chain_length:
            continue

        offset = generator.choice([-4, -3, -2, 2, 3, 4])
        stated_length = chain_length + offset
        if stated_length < 2:
            continue
        if abs(stated_length - chain_length) < MIN_LENGTH_CONFLICT:
            continue

        prior_chain = standard_chain(codons)
        if len(prior_chain) == stated_length:
            continue

        target = generator.choice(sorted(set(true_chain)))
        prior_count = prior_chain.count(target)

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            extra_sentence=(
                f"The card adds that the finished chain from this stretch is "
                f"{stated_length} links long."
            ),
            closing=(
                f"Taking the card as a whole, how many times does {target} "
                "appear in the finished chain? Please give a whole number. "
                + EXACT_COUNTS_NOTE + " " + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_inconsistent_{index:03d}",
                latent_instance_id=f"codon_inconsistent_{index:03d}",
                dataset_split="abstain",
                question_family="stated_length_conflicts",
                abstain_type="inconsistent",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=float(prior_count),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"codons": codons, "target": target,
                     "true_length": chain_length, "stated_length": stated_length}
                ),
                question_text=question_text,
            )
        )

    return questions



# 12. ABSTAIN - GENUINELY NON-UNIQUE
#
# One triple is printed with two readings, one of which stops the
# reading. That triple occurs before the stop, so the chain could end
# in two different places.


def make_non_unique_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []

    while len(questions) < count:
        chain_length = generator.randint(6, 12)
        sequence, codons = build_sequence(generator, code, chain_length)

        true_chain = read_chain(codons, code)
        if true_chain is None or len(true_chain) != chain_length:
            continue

        # Choose a sense codon that appears early in the chain.
        early = codons[1:chain_length]
        if not early:
            continue
        ambiguous_codon = generator.choice(early)
        if code[ambiguous_codon] == "STOP":
            continue

        first_position = codons.index(ambiguous_codon)
        if first_position >= chain_length:
            continue

        prior_length = len(standard_chain(codons))

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            ambiguous=(ambiguous_codon, code[ambiguous_codon], "STOP"),
            extra_sentence=(
                f"The entry for {ambiguous_codon} on the card lists two readings "
                "and does not say which one applies."
            ),
            closing=(
                "How many links long is the finished chain? Please give a whole "
                "number. " + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_nonunique_{index:03d}",
                latent_instance_id=f"codon_nonunique_{index:03d}",
                dataset_split="abstain",
                question_family="ambiguous_codon",
                abstain_type="non_unique",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=float(prior_length),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"codons": codons, "ambiguous": ambiguous_codon,
                     "first_position": first_position,
                     "length_if_sense": chain_length,
                     "length_if_stop": first_position}
                ),
                question_text=question_text,
            )
        )

    return questions



# 13. ABSTAIN - INSUFFICIENT INFORMATION
#
# One triple that occurs in the stretch is missing from the table. All
# three stops are still shown, so the missing triple is certainly not a
# stop and the chain length is still fixed. What it is read as, and
# therefore how often a given unit appears, is not.


def make_insufficient_questions(
    generator: random.Random, code: dict, count: int
) -> list[CodonQuestion]:
    questions: list[CodonQuestion] = []

    while len(questions) < count:
        chain_length = generator.randint(6, 12)
        sequence, codons = build_sequence(generator, code, chain_length)

        true_chain = read_chain(codons, code)
        if true_chain is None or len(true_chain) != chain_length:
            continue

        body = codons[:chain_length]
        omitted = generator.choice(body)
        if code[omitted] == "STOP":
            continue

        # The question must be about the very reading that was lost.
        target = code[omitted]
        prior_count = standard_chain(codons).count(target)

        index = len(questions) + 1
        question_text = build_prompt(
            generator, code, sequence, "",
            omitted=omitted,
            extra_sentence=(
                f"The line of the table for {omitted} has been rubbed away and "
                "cannot be read."
            ),
            closing=(
                f"How many times does {target} appear in the finished chain? "
                "Please give a whole number. " + ABSTAIN_INSTRUCTION
            ),
        )

        questions.append(
            CodonQuestion(
                question_id=f"codon_insufficient_{index:03d}",
                latent_instance_id=f"codon_insufficient_{index:03d}",
                dataset_split="abstain",
                question_family="missing_codon_line",
                abstain_type="insufficient",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=float(prior_count),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"codons": codons, "omitted": omitted, "target": target}
                ),
                question_text=question_text,
            )
        )

    return questions



# Independent verification


def verify_questions(questions: list[CodonQuestion], code: dict) -> None:
    problems: list[str] = []
    stops = set(stop_codons(code))

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family

        if family == "chain_length":
            recomputed = len(read_chain(parameters["codons"], code))
        elif family == "residue_count":
            recomputed = read_chain(parameters["codons"], code).count(parameters["target"])
        elif family == "bases_used":
            recomputed = 3 * (len(read_chain(parameters["codons"], code)) + 1)
        elif family == "synonym_count":
            recomputed = sum(1 for c in CODONS if code[c] == parameters["reading"])
        elif family == "stated_length_conflicts":
            gap = abs(parameters["stated_length"] - parameters["true_length"])
            if gap < MIN_LENGTH_CONFLICT:
                problems.append(f"{question.question_id}: conflict of {gap} is too small")
            recomputed = "ABSTAIN"
        elif family == "ambiguous_codon":
            if parameters["length_if_sense"] == parameters["length_if_stop"]:
                problems.append(f"{question.question_id}: both readings give the same length")
            if parameters["first_position"] >= parameters["length_if_sense"]:
                problems.append(f"{question.question_id}: the ambiguous triple is past the stop")
            recomputed = "ABSTAIN"
        elif family == "missing_codon_line":
            if parameters["omitted"] in stops:
                problems.append(f"{question.question_id}: a stop line was removed, so the length would move")
            if parameters["omitted"] not in parameters["codons"][:len(read_chain(parameters["codons"], code))]:
                problems.append(f"{question.question_id}: the missing triple never occurs before the stop")
            recomputed = "ABSTAIN"
        else:
            problems.append(f"{question.question_id}: unrecognised family {family}")
            continue

        if recomputed != question.expected_answer:
            problems.append(
                f"{question.question_id}: recomputed {recomputed} vs stored {question.expected_answer}"
            )

        if (
            question.prior_predicted_answer is not None
            and question.expected_answer != "ABSTAIN"
            and float(question.expected_answer) == question.prior_predicted_answer
        ):
            problems.append(f"{question.question_id}: prior value equals the true answer")

    # All three stops must be visible in every prompt that hides a line.
    for question in questions:
        if question.question_family != "missing_codon_line":
            continue
        for stop in stops:
            if f"{stop} = STOP" not in question.question_text:
                problems.append(f"{question.question_id}: stop {stop} is not visible on the card")

    if problems:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(problems))

    counts: dict[str, int] = {}
    for question in questions:
        counts[question.abstain_type] = counts.get(question.abstain_type, 0) + 1
    print("Verification passed. Abstain-type counts:", counts)



# Output


OUTPUT_COLUMNS = [field.name for field in CodonQuestion.__dataclass_fields__.values()]


def write_csv(questions: list[CodonQuestion], output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list[CodonQuestion], code: dict, output_path: Path) -> None:
    family_counts: dict[str, int] = {}
    abstain_counts: dict[str, int] = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    differences = sum(1 for codon in CODONS if code[codon] != STANDARD_CODE[codon])

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "codons_differing_from_the_familiar_table": differences,
        "stop_codons_in_this_world": stop_codons(code),
        "world": "a microbe with its own translation table, printed in full",
        "prior_attacked": "the memorised genetic code, including which triples stop translation",
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)



# Main


def main() -> None:
    generator = random.Random(RANDOM_SEED)
    code = build_altered_code(generator)

    differences = sum(1 for codon in CODONS if code[codon] != STANDARD_CODE[codon])
    print(f"Table differs from the familiar one on {differences} of 64 triples.")
    print(f"Stops in this world: {stop_codons(code)}")

    questions: list[CodonQuestion] = []
    questions.extend(make_chain_length_questions(generator, code, COUNT_CHAIN_LENGTH))
    questions.extend(make_residue_count_questions(generator, code, COUNT_RESIDUE_COUNT))
    questions.extend(make_bases_used_questions(generator, code, COUNT_BASES_USED))
    questions.extend(make_synonym_questions(generator, code, COUNT_SYNONYM_COUNT))
    questions.extend(make_inconsistent_questions(generator, code, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, code, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, code, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS} questions, built {len(questions)}.")

    verify_questions(questions, code)

    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, code, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    print(f"Wrote metadata to {OUTPUT_JSON.resolve()}")

    answerable = [q for q in questions if q.dataset_split == "answerable"]
    abstain = [q for q in questions if q.dataset_split == "abstain"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(abstain)}")
    print(f"Questions with a distinguishing prior value: "
          f"{len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
