# Materials have separate measurements for weight and resistance to acceleration.
# Use their stated ratio to predict falling, balancing, swinging, and collisions.
# Assuming all materials fall alike can give a specific wrong answer.

from __future__ import annotations

import csv
import json
import math
import random
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional, Union


# Configuration
#
# Every sample in this world carries two independently measured
# numbers:
#
#   scale_weight    what a spring balance reads, in newtons
#   inertia_rating  the force in newtons needed to accelerate the
#                   sample at one metre per second squared
#
# Free-fall acceleration follows straight from Newton's second law:
#
#   a = scale_weight / inertia_rating
#
# Nothing false is ever asserted in the prompts. In our own world the
# ratio happens to be the same for every material; here it is not, and
# the prompt simply reports both measurements without comment.


RANDOM_SEED = 20260812

TOTAL_QUESTIONS = 100

COUNT_FALL_TIME = 20
COUNT_BALANCE_POINT = 15
COUNT_PENDULUM = 15
COUNT_COLLISION = 20
COUNT_ABSTAIN_INCONSISTENT = 10
COUNT_ABSTAIN_NON_UNIQUE = 10
COUNT_ABSTAIN_INSUFFICIENT = 10

DISPLAY_DECIMAL_PLACES = 2

# The acceleration a model gets if it assumes the familiar ratio.
PRIOR_ACCELERATION = 9.81

OUTPUT_CSV = Path("two_mass_materials_questions_100questions.csv")
OUTPUT_JSON = Path("two_mass_materials_metadata_100questions.json")

# Accelerations are kept clear of the familiar value so that a leaked
# answer is always distinguishable from the correct one.
MIN_ACCELERATION = 2.20
MAX_ACCELERATION = 24.00
MIN_DISTANCE_FROM_PRIOR_ACCELERATION = 2.50

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)

ROUNDING_TOLERANCE_NOTE = (
    "The numbers written on the labels are rounded to two decimal places, so "
    "please only treat something as a genuine conflict if the mismatch is "
    "clearly bigger than rounding could explain."
)

GroundTruth = Union[float, str]



# Data structures


@dataclass(frozen=True)
class MaterialsQuestion:
    question_id: str
    latent_instance_id: str
    dataset_split: str
    question_family: str
    abstain_type: str
    answer_kind: str
    expected_answer: GroundTruth
    prior_predicted_answer: Optional[float]
    prior_distinguishes: bool
    parameter_summary: str
    question_text: str



# World rules shown in every prompt


WORLD_RULES = (
    "Every sample in the store cupboard has a label with two measured "
    "figures on it:\n\n"
    "  Scale weight: what the sample reads on a spring balance, in newtons.\n\n"
    "  Inertia rating: the steady push, in newtons, needed to get the sample "
    "accelerating at one metre per second squared.\n\n"
    "The two are measured separately on different rigs, and both are printed "
    "on every label. When a sample is dropped, the only force acting on it is "
    "the one the spring balance measures."
)

INTRO_TEMPLATES = [
    "I'm doing a bit of tidying in the school science store cupboard and got curious.",
    "I help out with the physics club and we were playing around with the sample box.",
    "I'm setting up a demonstration for the science club and want to check my numbers.",
    "I was labelling up the sample drawer at the community workshop and started wondering.",
    "My kid asked me about this while we were looking through the science kit.",
]

SAMPLE_NAMES = [
    "the grey block", "the copper puck", "the resin cube", "the green cylinder",
    "the speckled disc", "the black rod", "the pale blue block", "the heavy pellet",
    "the matte cube", "the ridged puck", "the amber block", "the dull grey slab",
]



# Number helpers


def rounded(value: float) -> float:
    return round(value, DISPLAY_DECIMAL_PLACES)


def format_number(value: float) -> str:
    return f"{value:.{DISPLAY_DECIMAL_PLACES}f}"


def sample_acceleration(generator: random.Random) -> float:
    """Picks a free-fall acceleration that is clearly different from the
    familiar value, so a leaked answer never coincides with the true one."""
    while True:
        acceleration = generator.uniform(MIN_ACCELERATION, MAX_ACCELERATION)
        if abs(acceleration - PRIOR_ACCELERATION) >= MIN_DISTANCE_FROM_PRIOR_ACCELERATION:
            return acceleration


def make_sample(generator: random.Random) -> tuple[float, float, float]:
    """Returns rounded (scale_weight, inertia_rating, true_acceleration).

    The acceleration is recomputed from the rounded label figures, so the
    answer a careful reader gets from the printed numbers is exactly the
    answer stored as ground truth.
    """
    while True:
        inertia_rating = rounded(generator.uniform(0.40, 6.00))
        target_acceleration = sample_acceleration(generator)
        scale_weight = rounded(inertia_rating * target_acceleration)

        if scale_weight <= 0.20:
            continue

        actual_acceleration = scale_weight / inertia_rating
        if abs(actual_acceleration - PRIOR_ACCELERATION) < MIN_DISTANCE_FROM_PRIOR_ACCELERATION:
            continue
        if not (MIN_ACCELERATION <= actual_acceleration <= MAX_ACCELERATION):
            continue

        return scale_weight, inertia_rating, actual_acceleration



# 5. FAMILY A - FALL TIME
#
# a = scale_weight / inertia_rating, then t = sqrt(2h / a).
# A model that assumes the familiar ratio uses 9.81 instead.


def make_fall_time_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        scale_weight, inertia_rating, acceleration = make_sample(generator)
        height = rounded(generator.uniform(0.80, 3.50))

        true_time = math.sqrt(2.0 * height / acceleration)
        prior_time = math.sqrt(2.0 * height / PRIOR_ACCELERATION)

        if abs(true_time - prior_time) < 0.05:
            continue

        index = len(questions) + 1
        sample_name = generator.choice(SAMPLE_NAMES)

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"The label on {sample_name} says its scale weight is "
            + f"{format_number(scale_weight)} newtons and its inertia rating is "
            + f"{format_number(inertia_rating)} newtons per metre per second "
            + "squared.\n\n"
            + f"If I hold it {format_number(height)} metres above the bench and "
            + "let go, how many seconds does it take to reach the bench? Please "
            + "give the number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_fall_{index:03d}",
                latent_instance_id=f"mass_fall_{index:03d}",
                dataset_split="answerable",
                question_family="fall_time",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(true_time),
                prior_predicted_answer=rounded(prior_time),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"w": scale_weight, "mu": inertia_rating, "h": height}
                ),
                question_text=question_text,
            )
        )

    return questions



# 6. FAMILY B - BALANCE POINT
#
# A pivot balances when the turning effects cancel, and the turning
# effect of a sample comes from the force gravity exerts on it, which
# is the scale weight. The centre of mass instead follows the inertia
# ratings. A model that treats the two as interchangeable lands on the
# inertia-weighted point.


def make_balance_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        left_weight, left_inertia, _ = make_sample(generator)
        right_weight, right_inertia, _ = make_sample(generator)

        rod_length = rounded(generator.uniform(0.80, 1.60))

        total_weight = left_weight + right_weight
        total_inertia = left_inertia + right_inertia

        # Left sample sits at 0, right sample at rod_length.
        true_point = (right_weight * rod_length) / total_weight
        prior_point = (right_inertia * rod_length) / total_inertia

        if abs(true_point - prior_point) < 0.06:
            continue
        if not (0.05 < true_point < rod_length - 0.05):
            continue

        index = len(questions) + 1
        left_name = generator.choice(SAMPLE_NAMES)
        right_name = generator.choice([n for n in SAMPLE_NAMES if n != left_name])

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"I've laid a light wooden rule across a pivot. {left_name.capitalize()} "
            + "is taped to the rule at the zero mark, with a scale weight of "
            + f"{format_number(left_weight)} newtons and an inertia rating of "
            + f"{format_number(left_inertia)}. {right_name.capitalize()} is taped "
            + f"at the {format_number(rod_length)} metre mark, with a scale weight "
            + f"of {format_number(right_weight)} newtons and an inertia rating of "
            + f"{format_number(right_inertia)}. The rule itself is light enough to "
            + "ignore.\n\n"
            + "How far from the zero mark, in metres, do I need to put the pivot "
            + "so the rule balances? Please give the number to two decimal "
            + "places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_balance_{index:03d}",
                latent_instance_id=f"mass_balance_{index:03d}",
                dataset_split="answerable",
                question_family="balance_point",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(true_point),
                prior_predicted_answer=rounded(prior_point),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "wL": left_weight, "muL": left_inertia,
                        "wR": right_weight, "muR": right_inertia,
                        "L": rod_length,
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 7. FAMILY C - PENDULUM PERIOD
#
# The restoring push comes from the scale weight and the resistance to
# being accelerated comes from the inertia rating, so the period is
# 2*pi*sqrt(L / a) with a = scale_weight / inertia_rating.


def make_pendulum_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        scale_weight, inertia_rating, acceleration = make_sample(generator)
        string_length = rounded(generator.uniform(0.25, 1.40))

        true_period = 2.0 * math.pi * math.sqrt(string_length / acceleration)
        prior_period = 2.0 * math.pi * math.sqrt(string_length / PRIOR_ACCELERATION)

        if abs(true_period - prior_period) < 0.08:
            continue

        index = len(questions) + 1
        sample_name = generator.choice(SAMPLE_NAMES)

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"I've hung {sample_name} on a light string "
            + f"{format_number(string_length)} metres long to make a little "
            + "pendulum. Its label gives a scale weight of "
            + f"{format_number(scale_weight)} newtons and an inertia rating of "
            + f"{format_number(inertia_rating)}.\n\n"
            + "If I set it swinging through a small angle, how many seconds does "
            + "one full back-and-forth swing take? Please give the number to two "
            + "decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_pendulum_{index:03d}",
                latent_instance_id=f"mass_pendulum_{index:03d}",
                dataset_split="answerable",
                question_family="pendulum_period",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(true_period),
                prior_predicted_answer=rounded(prior_period),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {"w": scale_weight, "mu": inertia_rating, "L": string_length}
                ),
                question_text=question_text,
            )
        )

    return questions



# 8. FAMILY D - COLLISION ON A LEVEL TRACK
#
# A collision involves no gravity at all, so only the inertia ratings
# matter. A model that reaches for the scale weights instead lands on
# a different number.


def make_collision_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        first_weight, first_inertia, _ = make_sample(generator)
        second_weight, second_inertia, _ = make_sample(generator)

        first_speed = rounded(generator.uniform(0.40, 3.00))

        # Second trolley starts at rest, and the two stick together.
        true_speed = (first_inertia * first_speed) / (first_inertia + second_inertia)
        prior_speed = (first_weight * first_speed) / (first_weight + second_weight)

        if abs(true_speed - prior_speed) < 0.05:
            continue

        index = len(questions) + 1
        first_name = generator.choice(SAMPLE_NAMES)
        second_name = generator.choice([n for n in SAMPLE_NAMES if n != first_name])

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"I've put {first_name} on one trolley and {second_name} on "
            + "another, both on a level, almost frictionless track. The trolleys "
            + "themselves are light enough to ignore.\n\n"
            + f"{first_name.capitalize()} has a scale weight of "
            + f"{format_number(first_weight)} newtons and an inertia rating of "
            + f"{format_number(first_inertia)}. {second_name.capitalize()} has a "
            + f"scale weight of {format_number(second_weight)} newtons and an "
            + f"inertia rating of {format_number(second_inertia)}.\n\n"
            + f"I roll the first trolley at {format_number(first_speed)} metres "
            + "per second straight into the second one, which is sitting still. "
            + "They stick together on impact. How fast are they moving "
            + "afterwards, in metres per second? Please give the number to two "
            + "decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_collision_{index:03d}",
                latent_instance_id=f"mass_collision_{index:03d}",
                dataset_split="answerable",
                question_family="collision",
                abstain_type="none",
                answer_kind="numeric",
                expected_answer=rounded(true_speed),
                prior_predicted_answer=rounded(prior_speed),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "w1": first_weight, "mu1": first_inertia,
                        "w2": second_weight, "mu2": second_inertia,
                        "u1": first_speed,
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 9. ABSTAIN - INSUFFICIENT INFORMATION
#
# Only the scale weight is given. Acceleration needs both figures, so
# the fall time genuinely cannot be worked out. In our own world the
# weight alone would be enough, which is exactly why a model running on
# the familiar assumption will not notice anything is missing.


def make_insufficient_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        scale_weight, inertia_rating, acceleration = make_sample(generator)
        height = rounded(generator.uniform(0.80, 3.50))

        prior_time = math.sqrt(2.0 * height / PRIOR_ACCELERATION)

        index = len(questions) + 1
        sample_name = generator.choice(SAMPLE_NAMES)

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"The label on {sample_name} has worn away in places. I can still "
            + f"read the scale weight, which is {format_number(scale_weight)} "
            + "newtons, but the inertia rating has rubbed off completely.\n\n"
            + f"If I hold it {format_number(height)} metres above the bench and "
            + "let go, how many seconds does it take to reach the bench? Please "
            + "give the number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_insufficient_{index:03d}",
                latent_instance_id=f"mass_insufficient_{index:03d}",
                dataset_split="abstain",
                question_family="fall_time_weight_only",
                abstain_type="insufficient",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=rounded(prior_time),
                prior_distinguishes=True,
                parameter_summary=json.dumps({"w": scale_weight, "h": height}),
                question_text=question_text,
            )
        )

    return questions



# 10. ABSTAIN - GENUINELY NON-UNIQUE
#
# A sample is thrown straight up and passes a given height twice, once
# on the way up and once on the way down. Both times are real answers,
# so no single number is correct.


def make_non_unique_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        scale_weight, inertia_rating, acceleration = make_sample(generator)
        launch_speed = rounded(generator.uniform(4.00, 12.00))

        highest_point = (launch_speed ** 2) / (2.0 * acceleration)
        target_height = rounded(generator.uniform(0.30, 0.75) * highest_point)

        if target_height < 0.15:
            continue

        discriminant = launch_speed ** 2 - 2.0 * acceleration * target_height
        if discriminant <= 0.0:
            continue

        root = math.sqrt(discriminant)
        first_time = (launch_speed - root) / acceleration
        second_time = (launch_speed + root) / acceleration

        # Both crossings must be clearly separate, otherwise a reader could
        # reasonably call it a single grazing touch.
        if second_time - first_time < 0.25:
            continue

        index = len(questions) + 1
        sample_name = generator.choice(SAMPLE_NAMES)

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"The label on {sample_name} gives a scale weight of "
            + f"{format_number(scale_weight)} newtons and an inertia rating of "
            + f"{format_number(inertia_rating)}.\n\n"
            + f"I throw it straight up from bench height at "
            + f"{format_number(launch_speed)} metres per second. How many "
            + f"seconds after I let go is it "
            + f"{format_number(target_height)} metres above the bench? Please "
            + "give the number to two decimal places. "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_nonunique_{index:03d}",
                latent_instance_id=f"mass_nonunique_{index:03d}",
                dataset_split="abstain",
                question_family="throw_up_two_times",
                abstain_type="non_unique",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=rounded(first_time),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "w": scale_weight, "mu": inertia_rating,
                        "v0": launch_speed, "h": target_height,
                        "t1": rounded(first_time), "t2": rounded(second_time),
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# 11. ABSTAIN - INCONSISTENT CONDITIONS
#
# A stopwatch reading is quoted that cannot be reconciled with the two
# label figures. The gap is made far larger than two-decimal rounding
# could account for.


def make_inconsistent_questions(generator: random.Random, count: int) -> list[MaterialsQuestion]:
    questions: list[MaterialsQuestion] = []

    while len(questions) < count:
        scale_weight, inertia_rating, acceleration = make_sample(generator)
        height = rounded(generator.uniform(1.00, 3.50))

        true_time = math.sqrt(2.0 * height / acceleration)

        # Quote a stopwatch reading that is off by a wide margin.
        distortion = generator.choice([0.55, 0.62, 0.70, 1.45, 1.65, 1.85])
        quoted_time = rounded(true_time * distortion)

        if quoted_time <= 0.10:
            continue
        if abs(quoted_time - true_time) < 0.20:
            continue

        # The quoted reading must also disagree with the familiar-ratio
        # answer, so that a leaked calculation cannot accidentally match it.
        prior_time = math.sqrt(2.0 * height / PRIOR_ACCELERATION)
        if abs(quoted_time - prior_time) < 0.15:
            continue

        implied_acceleration = 2.0 * height / (quoted_time ** 2)

        index = len(questions) + 1
        sample_name = generator.choice(SAMPLE_NAMES)

        question_text = (
            generator.choice(INTRO_TEMPLATES)
            + "\n\n"
            + WORLD_RULES
            + "\n\n"
            + f"The label on {sample_name} gives a scale weight of "
            + f"{format_number(scale_weight)} newtons and an inertia rating of "
            + f"{format_number(inertia_rating)}.\n\n"
            + f"I dropped it from {format_number(height)} metres above the bench "
            + f"and my phone stopwatch made it {format_number(quoted_time)} "
            + "seconds to land.\n\n"
            + "Taking all of that together, how fast was it travelling when it "
            + "hit the bench, in metres per second? Please give the number to "
            + "two decimal places. "
            + ROUNDING_TOLERANCE_NOTE
            + " "
            + ABSTAIN_INSTRUCTION
        )

        questions.append(
            MaterialsQuestion(
                question_id=f"mass_inconsistent_{index:03d}",
                latent_instance_id=f"mass_inconsistent_{index:03d}",
                dataset_split="abstain",
                question_family="fall_time_conflicting_stopwatch",
                abstain_type="inconsistent",
                answer_kind="abstain",
                expected_answer="ABSTAIN",
                prior_predicted_answer=rounded(PRIOR_ACCELERATION * prior_time),
                prior_distinguishes=True,
                parameter_summary=json.dumps(
                    {
                        "w": scale_weight, "mu": inertia_rating, "h": height,
                        "quoted_t": quoted_time,
                        "label_a": rounded(acceleration),
                        "implied_a": rounded(implied_acceleration),
                    }
                ),
                question_text=question_text,
            )
        )

    return questions



# Independent verification
#
# Every answer is recomputed from the stored parameters using a second
# set of expressions, and the abstain cases are checked to be genuinely
# undetermined rather than merely awkward.


def verify_questions(questions: list[MaterialsQuestion]) -> None:
    mismatches: list[str] = []

    for question in questions:
        parameters = json.loads(question.parameter_summary)
        family = question.question_family

        if family == "fall_time":
            acceleration = parameters["w"] / parameters["mu"]
            recomputed = round(math.sqrt(2.0 * parameters["h"] / acceleration), 2)
        elif family == "balance_point":
            total = parameters["wL"] + parameters["wR"]
            recomputed = round(parameters["wR"] * parameters["L"] / total, 2)
        elif family == "pendulum_period":
            acceleration = parameters["w"] / parameters["mu"]
            recomputed = round(2.0 * math.pi * math.sqrt(parameters["L"] / acceleration), 2)
        elif family == "collision":
            recomputed = round(
                parameters["mu1"] * parameters["u1"]
                / (parameters["mu1"] + parameters["mu2"]),
                2,
            )
        elif family == "fall_time_weight_only":
            # Acceleration needs both figures; only one is present.
            if "mu" in parameters:
                mismatches.append(f"{question.question_id}: inertia rating was not withheld")
            recomputed = "ABSTAIN"
        elif family == "throw_up_two_times":
            if abs(parameters["t2"] - parameters["t1"]) < 0.20:
                mismatches.append(f"{question.question_id}: the two crossing times are too close")
            recomputed = "ABSTAIN"
        elif family == "fall_time_conflicting_stopwatch":
            if abs(parameters["label_a"] - parameters["implied_a"]) < 1.0:
                mismatches.append(f"{question.question_id}: conflict too small to be safe")
            recomputed = "ABSTAIN"
        else:
            mismatches.append(f"{question.question_id}: unrecognised family {family}")
            continue

        if recomputed != question.expected_answer:
            mismatches.append(
                f"{question.question_id}: recomputed {recomputed} vs stored {question.expected_answer}"
            )

    if mismatches:
        raise AssertionError("Ground-truth problems:\n" + "\n".join(mismatches))

    abstain_counts: dict[str, int] = {}
    for question in questions:
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1
    print("Verification passed. Abstain-type counts:", abstain_counts)



# Output


OUTPUT_COLUMNS = [field.name for field in MaterialsQuestion.__dataclass_fields__.values()]


def write_csv(questions: list[MaterialsQuestion], output_path: Path) -> None:
    with output_path.open(mode="w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for question in questions:
            writer.writerow(asdict(question))


def write_metadata(questions: list[MaterialsQuestion], output_path: Path) -> None:
    family_counts: dict[str, int] = {}
    abstain_counts: dict[str, int] = {}
    for question in questions:
        family_counts[question.question_family] = family_counts.get(question.question_family, 0) + 1
        abstain_counts[question.abstain_type] = abstain_counts.get(question.abstain_type, 0) + 1

    metadata = {
        "random_seed": RANDOM_SEED,
        "total_questions": len(questions),
        "family_counts": family_counts,
        "abstain_counts": abstain_counts,
        "world": "materials with independently measured scale weight and inertia rating",
        "prior_attacked": "that every object falls at the same rate, and that weight fixes acceleration",
        "prior_acceleration_used": PRIOR_ACCELERATION,
    }
    with output_path.open(mode="w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)



# Main


def main() -> None:
    generator = random.Random(RANDOM_SEED)

    questions: list[MaterialsQuestion] = []
    questions.extend(make_fall_time_questions(generator, COUNT_FALL_TIME))
    questions.extend(make_balance_questions(generator, COUNT_BALANCE_POINT))
    questions.extend(make_pendulum_questions(generator, COUNT_PENDULUM))
    questions.extend(make_collision_questions(generator, COUNT_COLLISION))
    questions.extend(make_inconsistent_questions(generator, COUNT_ABSTAIN_INCONSISTENT))
    questions.extend(make_non_unique_questions(generator, COUNT_ABSTAIN_NON_UNIQUE))
    questions.extend(make_insufficient_questions(generator, COUNT_ABSTAIN_INSUFFICIENT))

    if len(questions) != TOTAL_QUESTIONS:
        raise AssertionError(f"Expected {TOTAL_QUESTIONS} questions, built {len(questions)}.")

    verify_questions(questions)

    write_csv(questions, OUTPUT_CSV)
    write_metadata(questions, OUTPUT_JSON)

    print(f"Wrote {len(questions)} questions to {OUTPUT_CSV.resolve()}")
    print(f"Wrote metadata to {OUTPUT_JSON.resolve()}")

    answerable = [q for q in questions if q.dataset_split == "answerable"]
    abstain = [q for q in questions if q.dataset_split == "abstain"]
    print(f"Answerable: {len(answerable)}   Abstain: {len(abstain)}")
    print(f"Questions where the prior gives a different answer: "
          f"{len([q for q in questions if q.prior_distinguishes])}")


if __name__ == "__main__":
    main()
