# Run and test locally

These commands work from any checkout of this build. They do not publish changes or submit cluster jobs. Python 3.10+ is required.

## 1. Open the repository root and install

In PowerShell, enter the extracted folder containing `pyproject.toml`:

```powershell
Set-Location -LiteralPath 'C:\path\to\axiomshift-iclr'
```

Replace the example with your extracted folder path. Create an environment if one does not exist, then install:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
```

On Linux/macOS replace `py` with `python3`, and `.\.venv\Scripts\python.exe` with `.venv/bin/python` in every command below. Existing environments only need the install command after updating the code.

## 2. Check the dataset and tests

```powershell
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift validate --canonical
.\.venv\Scripts\python.exe -m unittest discover -s tests/math -v
```

Expect 700 questions, 100 per world, and a test result of `OK`. The canonical SHA-256 is `dc689eda14540809bbe4b0915b909fa128d289b8ae0cfea06643ad564d8f1cbe`. The tests check actual reconstruction, independent gold-answer verification, all 26 saved model scores, repeatable variants, and GUI/model HTTP behavior. Their model server is a controlled mock, not a real LLM.

## 3. Reconstruct questions and saved results without a model

Use fresh output names each time:

```powershell
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift generate --output outputs/test-published
Get-Content outputs/test-published/verification.json | ConvertFrom-Json | Select-Object rows,byte_identical,same_family_balance
Get-FileHash src/prior_leakage/math/data/assembled/seven_worlds.csv,outputs/test-published/seven_worlds.csv -Algorithm SHA256
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift analyse --output outputs/test-reference
Get-Content outputs/test-reference/README.md
```

Expect equal CSV hashes, `rows=700`, and `byte_identical=True`. Only the final question CSV is saved; candidate files are temporary. The saved-result analysis includes 26 models, grading checks, and missing/incomplete counts.

## 4. Launch the GUI

```powershell
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift gui
```

Open **http://127.0.0.1:8765** if the browser does not open automatically. Keep the terminal running. If this port is occupied, add `--port 8766` and use the printed address.

Without a model, try **Analyse reference results**, or **Generate 700 questions**. Leave the seed blank to reconstruct published questions. Enter `42` and a folder name such as `seed-42` to generate a balanced variant. Generated datasets appear in the evaluation dropdown. Repeating the same seed in a different folder must give identical CSV bytes; a different seed should change parameters.

## 5. Connect LM Studio

Load a text-generation model, then start LM Studio's local server in its Developer tab. Use port `1234`, or enter your chosen port in the GUI's URL. LM Studio must have a context window large enough for the entire prompt and output budget.

In the GUI, keep **Local server API URL** as `http://localhost:1234/v1`, click **Connect & find models**, and select/enter the exact loaded model identifier. If authentication is enabled, set `LMSTUDIO_API_KEY` in the terminal before launching the GUI; do not put the token in project files.

## 6. Run five questions before all 700

| Field | First run |
|---|---|
| Dataset | `data/seven_worlds.csv` (GUI alias for the installed canonical dataset) |
| Run size | 5-question smoke test |
| Model type | Chat / instruct, or Base / completion for a base model |
| Maximum output tokens | 800 initially; thinking models may need 4096 or more |
| Run folder name | `my-model-smoke` |
| Resume | Unchecked |

Click **Start evaluation**. Open the `answers.csv` and `analysis/README.md` links when it finishes. Expect five attempted questions, model response text, and no request errors. Low accuracy can be a valid result; 695 missing questions is expected for this smoke test. Investigate truncated or unparsed responses before a long run.

Next select **Full 700 questions**, use a new folder such as `my-model-full`, and start. To evaluate a variant, select its generated CSV first. Outputs are in `outputs/gui-runs/<name>/`.

## 7. Pause, resume, and retain results

Click **Pause after current answer** and wait for `paused`. To resume, use the same folder, model, data, run size, and settings, check **Resume**, and start again. Completed answers are skipped. A five-question selection cannot be resumed as a 700-question selection. Code upgrades also require a new run or the original code version.

Preserve `run.json`, `answers.jsonl`, `answers.csv`, and the exact dataset and generation record. Record your model checksum/revision, quantization, context size, chat template, LM Studio version, and environment. Fresh responses may differ from saved historical results.

Once paused or finished, stop the GUI with **Ctrl+C** in the terminal. Reloading the page alone does not stop a running evaluation.

## 8. Optional direct CLI and paper reproduction

```powershell
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift run --model YOUR_LOADED_MODEL_ID --backend api --base-url http://localhost:1234/v1 --limit 5 --output outputs/cli-smoke
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift analyse --results outputs/cli-smoke/answers.csv --output outputs/cli-smoke/analysis
.\.venv\Scripts\python.exe -m pip install -e ".[plots]"
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift paper-assets --output outputs/test-figures
.\.venv\Scripts\python.exe -m prior_leakage.math.axiomshift stage-paper mathai --output outputs/test-mathai
```

For variants, pass the same `--data outputs/datasets/seed-42/seven_worlds.csv` to inference and analysis. Paper staging prepares dependencies; compiling the manuscript requires a separate LaTeX installation.

## Troubleshooting

| Symptom | Action |
|---|---|
| Import error | Install with the same environment's Python, from the repository root |
| Connection refused/timeout | Start LM Studio's server and verify its port |
| HTTP 401/403 | Check authentication and `LMSTUDIO_API_KEY` |
| Model not found | Select a loaded text-generation model and its exact identifier |
| Context overflow | Increase model context; do not truncate the supplied axioms |
| Repeated truncation | Raise output budget and start a new run |
| Output already exists | Use a fresh folder or resume with unchanged settings |
| Resume refused | Restore original code/data/settings or use a new run folder |
| `.running` remains after a crash | Confirm no evaluator is running before removing that run's stale lock |

New runs are written under `outputs/`. Keep them separate from the reference data. See [the pipeline](pipeline.md), [configuration](../configs/README.md), and [Slurm instructions](../../../../scripts/math/slurm/README.md).
