# Evaluation protocol

The release has seven worlds of 100 questions: `altered_codon_table`, `altered_valence_chemistry`, `partial_order_counts`, `polygon_three_worlds`, `sas_three_worlds`, `two_mass_materials`, and `upward_demand_market`. Order is fixed unless explicitly shuffled with `--seed`.

Only `question_text` is sent to the model. Gold answers, prior answers, world names, and parameter metadata stay in the evaluator. `configs/prompts.json` preserves the historical OpenAI instruction, local instruction, and API base-completion cue. HF base runs use the local instruction followed by the question and `FINAL_ANSWER:`. Budgets and parser profiles are in `configs/models.json`.

Historical runs did not all share one token budget, parser revision, or immutable model snapshot. Presets identify their selected source runner/job; some released results combine runs made with different budgets. A new full run repeats the documented protocol. Exact response identity is not guaranteed by greedy decoding across hosted revisions, hardware, quantization, or templates.

## Parsing and grading

The `openai` profile uses the `FINAL_ANSWER` label, a leading answer for API base continuations, then historical abstention/last-number fallbacks. `local` additionally recognizes boxed answers, “answer is” phrases, and a bare final line. Earlier LM Studio runs use the `openai` profile because they shared those rules. Both profiles use one parser. Fallback parsing is retained for compatibility and recorded in `parse_method`; it can mistake a number in prose for an answer. Changing it defines a new protocol.

Closed and unfinished `<think>` blocks are removed. A truncated response without a labelled answer is `ran_out_of_room`; a labelled answer before truncation is graded, matching the original evaluators. An unparseable finished response is `unreadable_reply`.

Gold and prior matching both use `abs(prediction - target) <= max(0.02, 0.01 * abs(target))`.

`prior_distinguishes` defines where leakage is measurable: 644 items, comprising 444 answerable and 200 abstention questions. Accuracy and false/failure-to-abstain use the full relevant completed pool.

## Denominators

Default `analyse --basis complete` follows the manuscript: exclude request/runtime failures, truncations without answers, and unreadable/missing answers. Attempted, missing, completed, and excluded counts are separate. Partial runs use their own observed counts; absent rows are never fabricated.

| Metric | Numerator | Denominator |
|---|---|---|
| `accuracy_pct` | Correct outcomes | Completed outcomes |
| `leak_pct_committed_prior` | Incorrect numeric answers matching a distinguishing prior | Completed distinguishing items answered numerically |
| `leak_pct_seen_prior` | Same leaked answers | All completed distinguishing items, including abstentions |
| `failure_to_abstain_pct` | Numeric replies to abstention items | Completed abstention items |
| `false_abstention_pct` | Abstentions on answerable items | Completed answerable items |

The manuscript's “All models” Leak column uses **committed prior**. The separate seen-prior metric makes the effect of conditioning on numeric commitment inspectable. Accuracy intervals are Wilson 95% bounds.

Four disjoint counts partition completed errors: A, wrong non-prior number on an answerable item; B, non-prior numeric failure to abstain; C, incorrect numeric prior match on a distinguishing item; D, false abstention. Each is also reported as a percentage of completed answers and of completed errors. Their counts must sum to the completed error count.

`--basis attempted` is a sensitivity analysis including truncated/unreadable responses as incorrect; request/runtime failures remain excluded. Four-mode percentages still use completed answers. This is not the paper's primary denominator.

## Stored outcomes and retries

Analysis uses stored parsed outcomes, validates their gold/prior metadata against the dataset, and audits their correctness/category against the common grader. It never silently reparses or rewrites historical results. Every released complete-answer label/category passes the audit.

Attempts reduce to the last complete answer for each `(question_set, question_id)`, otherwise the last attempt. One model per input CSV is required. New runs store all attempts in JSONL and write a deduplicated CSV. Runtime failures stop with a nonzero exit status. Resume verifies the run identity before another request.

Adapter references: [OpenAI reasoning parameters](https://developers.openai.com/api/docs/guides/reasoning) and [Transformers generation configuration](https://huggingface.co/docs/transformers/main_classes/text_generation). These describe interfaces, not historical model availability.
