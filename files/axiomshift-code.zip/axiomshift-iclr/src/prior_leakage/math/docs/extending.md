# Extending the benchmark

## Models

Use `--model ANY_ID --backend api|hf` for a one-off run. For reuse, add a JSON entry in `configs/models.json`, or pass `--config configs/my-models.json`. No model-specific Python evaluator is needed.

An API preset specifies `model_id`, `base_url`, `api_style` (`chat`, `completion`, `responses_plain`, `responses_reasoning`), `max_output_tokens`, `temperature`, `prompt`, and `parser`. Reasoning presets set `reasoning_effort` and omit temperature from requests. API base models use `is_base_model: true` and `api_style: completion`. Custom authenticated endpoints specify `api_key_env`; an OpenAI credential is never automatically sent to another host.

An HF preset specifies `model_id` or local `model_path`, optional immutable `revision`, `dtype`, `device_map`, `max_input_tokens`, and `max_output_tokens`. `gpu_memory` and `cpu_memory` set loading ceilings. `is_base_model: true` selects an HF completion prompt. Remote model code is disabled by default; explicitly enable it only when required for the model you intend to load.

Use `--dry-run` to inspect resolved settings. Run a small smoke test into its own directory, then a full run into another. Preserve `run.json` when publishing outcomes. Original GGUF quantizations and HF snapshot hashes were not all recorded; preserve yours for future reproduction.

## Questions and worlds

For a new 700-question set with the same family balance, use `python -m prior_leakage.math.axiomshift generate --seed 42 --output outputs/datasets/seed42`. This samples new parameters and records derived seeds and code hashes. The GUI lists datasets generated in `outputs/datasets/`. Omitting the seed reconstructs the published CSV exactly. See [local testing](local_testing.md) for repeatability checks.

Export a world with `python -m prior_leakage.math.axiomshift export --world WORLD --output outputs/variant.csv`. Keep these columns:

| Column | Meaning |
|---|---|
| `question_set` | Stable world name |
| `question_id` | Globally unique stable question ID |
| `latent_instance_id` | Underlying instance ID |
| `dataset_split` | `answerable` or `abstain` |
| `question_family` | Task/formula family |
| `abstain_type` | `none`, `inconsistent`, `non_unique`, `insufficient` |
| `answer_kind` | `numeric` or the source abstention kind |
| `expected_answer` | Finite number or `ABSTAIN` |
| `prior_predicted_answer` | Finite real-world-prior answer, or empty |
| `prior_distinguishes` | Boolean controlling inclusion in leakage metrics |
| `parameter_summary` | JSON instance parameters |
| `question_text` | Full question including altered axioms |

Change IDs when changing questions. Recompute both answers whenever parameters or axioms change. Validate before evaluation and supply the same `--data` to `run` and `analyse`. `validate --canonical` is only for the unchanged release; custom datasets may have any number of worlds/questions. Add independent solver tests for new gold/prior calculators.

The seven active world generators are in `generators/`, with inline seeds, parameters, and altered/conventional-world calculations. First run `python -m prior_leakage.math.axiomshift generate --output outputs/baseline`. Create a branch before editing generator constants or formulas. `generate --allow-differences --output outputs/variant` reports intentional changes that retain the original 500 base IDs and final assembly shape. The market/polygon finalization module (`axiomshift/dataset/finalize.py`) has its own seed and formulas and must be reviewed when changing their rules.

For different worlds, counts, or ID schemes, run your generator into a scratch directory and assemble its output using the schema above; the canonical generation recipe requires the original base IDs/order. Then use `validate --data`, `run --data`, and `analyse --data`. See [the generator recipe](../generators/README.md). Independently test gold/prior calculations and ambiguous, inconsistent, and insufficient cases. Edits to active generators must pass dataset/solver checks. Record a new dataset manifest when publishing a changed benchmark.

## Backends

Implement `generate(question_text)` in `axiomshift/models/backends.py` and connect it in `axiomshift/models/runner.py`. Return `raw_response_text`, `finish_reason`, optional token counts, and `attempt_count`. Leave selection, logging, parsing, grading, resume, and aggregation in shared modules. The injected `backend` argument in `runner.run` supports offline tests.

## Troubleshooting

- **HTTP/model error:** check provider ID and access; load the LM Studio model and start its server. Historical hosted IDs may no longer be available.
- **Context overflow:** use a suitable context setting. HF refuses to truncate axioms. Configure local servers to fit prompt plus output budget.
- **Out of memory:** adjust output cap, sharding, or memory; changed settings constitute a new experiment.
- **Resume refused:** use original settings/data or a new directory. A smoke-test selection cannot resume into a different full selection.
- **`.running` exists:** another process may be writing. After confirming it stopped, remove only the lock file and resume. Forced termination can leave a lock behind.
- **Malformed final JSONL record:** preserve a copy and remove only the incomplete final line after checking it. Ambiguous recovery is not silently accepted.

Install the root package before running core commands; they use only standard-library runtime dependencies. Optional `pip install -e ".[hf]"` is an editable installation tied to this checkout and its data/configuration paths.
