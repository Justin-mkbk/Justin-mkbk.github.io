# What you can reproduce

| Goal | Command | Expected result |
|---|---|---|
| Exact published questions | `axiomshift generate --output outputs/published` | Same 700 question texts, values, IDs, answers, order, and CSV bytes |
| New parameter variant | `axiomshift generate --seed 42 --output outputs/datasets/seed42` | 700 questions with the same family/world/abstention balance; repeatable with the same seed and code |
| Published scores | `axiomshift analyse --output outputs/reference` | Metrics recalculated from all 26 saved response files |
| Publication figures | `axiomshift paper-assets --output outputs/figures` | Figures and statistical tables derived from the supplied data; requires plotting extras |
| Fresh local inference | `axiomshift gui` | New responses and scores from your loaded model |

Fresh inference need not match saved responses exactly. To make your run repeatable, retain the model snapshot/revision, quantization, model-file checksum, context size, chat template, inference settings, environment export, dataset, and output files.

Nine Hugging Face run summaries are supplied in `results/summary/`; seven include snapshot revisions. Full model and environment records are unavailable for some historical runs. Some result files combine multiple attempts, so use the analyser's documented selection and denominator rules rather than dividing every count by 700. See [the scoring protocol](protocol.md).

The GUI and CLI write new outputs beneath your current directory. Use a new output name for changed settings or datasets. Resume only with unchanged code, dataset, model, selection, and prompts; after a code upgrade, finish old runs with their original version or start a new run.
