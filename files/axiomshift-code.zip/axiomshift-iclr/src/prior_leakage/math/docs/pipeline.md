# Pipeline: from axioms to measured prior leakage

The folders follow the scientific pipeline. `axiomshift/__main__.py` connects these stages for the CLI; `axiomshift/gui/` provides the same actions in a local browser.

| Figure stage | Implementation | What to change |
|---|---|---|
| 1. Question families | Seven modules in `generators/` | Family definitions, sample counts, ambiguity/abstention cases |
| 2. Axiom perturbation | World rules and question templates in each generator | Supplied axioms and their conventional counterparts |
| 3. Value sampler | Seeded samplers in each generator; `axiomshift/dataset/generation.py` coordinates them | Parameter distributions and the master seed |
| 4. Gold and prior answers | World calculators in the generators; `dataset/finalize.py` supplies valid final polygon/market cases | Both calculators and any rejection conditions when changing axioms |
| Independent answer check | `dataset/verify_answers.py` | A separate prompt-based polygon/market solver, independent of the generator's parameter metadata |
| Assembly and validation | `dataset/generation.py`, `dataset/io.py`; `data/raw/` holds required ordering | Final schema, order, canonical fingerprint, and balanced variant checks |
| 4. Model answer | `axiomshift/models/backends.py` and `models/runner.py` | Endpoint/model settings or a new backend; only question text is sent to the model |
| 5. Scoring and four failure modes | `axiomshift/evaluation/scoring.py` and `evaluation/analysis.py` | Parsing protocols, numeric tolerances, failure categories, and denominators |
| Publication figures/tables | `analysis/figures.py`, `produce_figures.py`, and `workshop/` | Plot presentation and publication analyses |

The prior-distinguishing pool in the figure is a metric eligibility condition. The supplied 700-row benchmark contains 490 answerable and 210 abstention questions; 644 rows have `prior_distinguishes=true`. Retain all 700 for evaluation and use the flag for leakage denominators. Do not discard abstention or non-distinguishing rows when reproducing the published benchmark.

For completed answers the failure categories are A: wrong numeric answer without prior leakage; B: failure to abstain without prior leakage; C: prior leakage; D: false abstention. Runtime, parsing, and truncation failures are reported separately. [Scoring protocol](protocol.md) defines the denominator choices.

## Reproduction and modification

`axiomshift generate` rebuilds exact published bytes. `axiomshift generate --seed 42` changes parameters with the same world/family/abstention balance. The seed-v1 recipe is stable across this folder reorganization. `data/raw/base_five_world_order.json` contains IDs, not cached questions; generated question contents always come from the calculators.

Candidate generation happens in an isolated temporary directory. Finalization and assembly work on rows in memory, so users receive one `seven_worlds.csv`, `verification.json`, diagnostic logs, and a variant ID map when relevant. Keep the verification record to repeat a modified dataset.

To change families or axioms, start with the corresponding generator and its finalization/verification code. Recompute both answers, assign new question IDs, and test the mathematical rules independently. For different counts/worlds, assemble your own CSV using the schema in [the extension guide](extending.md); the runner and analyser accept it through `--data`.
