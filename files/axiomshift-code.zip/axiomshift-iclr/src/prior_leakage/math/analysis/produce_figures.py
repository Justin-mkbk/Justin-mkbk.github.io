"""Run a staged workshop figure script with the complete model-label lookup.

Called by ``axiomshift paper-assets`` after staging the benchmark and responses.
"""
import importlib.util
from pathlib import Path
import sys

path=Path(sys.argv[1]).resolve()
sys.argv=[str(path)]
spec=importlib.util.spec_from_file_location('_author_analysis',path)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
if path.name=='matched_comparisons.py':
    # The source lookup predates this model's addition to the 26-model paper.
    # This changes labels only, not observations, filtering or statistics.
    module.META['qwen3-235b-a22b-thinking']=('thinking',235)
    module.DISPLAY['qwen3-235b-a22b-thinking']='Qwen3-235B-A22B-Think'
    module.META['qwen2.5-coder-7b-instruct']=('code',7)
    module.DISPLAY['qwen2.5-coder-7b-instruct']='Qwen2.5-Coder-7B'
module.main()
