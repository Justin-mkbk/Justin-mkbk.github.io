# Workshop-paper analysis

These scripts reproduce the analyses supplied with the MATH-AI and AISciK workshop manuscripts. For ordinary model comparisons use `axiomshift analyse`.

```bash
python -m pip install -e ".[plots]"
axiomshift paper-assets --output outputs/paper-assets
```

Run after installing from the repository root. The command supplies the frozen dataset and all 26 reference response files, then writes figures, tables, calculation logs, and input fingerprints.

| Script in `workshop/` | Purpose |
|---|---|
| `main_figures.py` | Main workshop figures, regressions, question-type splits, and error shares |
| `family_table.py` | Question-family comparisons and the family table |
| `matched_comparisons.py` | Matched-question comparisons and robustness calculations used by the workshop analysis |

`produce_figures.py` supplies two model label/size lookup entries needed by the matched-model script and calls its main function. It does not change scoring or statistical formulas. The three scripts implement distinct required analyses.

Figures exported by `paper-assets` use `failure_modes_by_accuracy`, `prior_leakage_by_question_type`, and `error_shares_by_accuracy` as their stems.
