"""Reproduce workshop-paper figures/tables from the frozen dataset and 26 runs."""
from __future__ import annotations
import importlib.util
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path
from ..axiomshift.dataset.io import ROOT,DEFAULT_DATA,sha256

def paper_assets(output):
    if importlib.util.find_spec('matplotlib') is None:
        raise ValueError('Install plotting dependencies: python -m pip install -e ".[plots]"')
    output=Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError('Paper output must be an empty directory')
    output.mkdir(parents=True,exist_ok=True)
    stage=output/'inputs';stage.mkdir()
    shutil.copyfile(DEFAULT_DATA,stage/'seven_worlds_questions_700questions_revised.csv')
    results=list((ROOT/'results/reference').glob('*.csv'))
    if len(results)!=26:
        raise ValueError('Paper reproduction requires the 26 reference result files')
    for path in results:
        shutil.copyfile(path,stage/(path.stem+'_results.csv'))
    programs=['main_figures.py','family_table.py','matched_comparisons.py']
    for name in programs:
        script=stage/name
        shutil.copyfile(ROOT/'analysis/workshop'/name,script)
        result=subprocess.run([sys.executable,str(ROOT/'analysis/produce_figures.py'),str(script)],cwd=stage,capture_output=True,text=True,encoding='utf-8',timeout=180)
        (output/(script.stem+'.log')).write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
        if result.returncode:
            raise RuntimeError(f'{name} failed; see {output / (script.stem+".log")}')
    (output/'manifest.json').write_text(json.dumps({'dataset_sha256':sha256(DEFAULT_DATA),
        'reference_results':{p.name:sha256(p) for p in results},'scripts':{n:sha256(ROOT/'analysis/workshop'/n) for n in programs}},indent=2)+'\n')
    names={'fig1_decline':'failure_modes_by_accuracy', 'fig3_split':'prior_leakage_by_question_type',
           'fig4_share':'error_shares_by_accuracy'}
    for path in list(stage.rglob('*')):
        if path.is_file() and path.stem in names:
            path.rename(path.with_name(names[path.stem]+path.suffix))
    print(f'Workshop figures/tables and analysis logs written to {output}')

def stage_submission(submission,output):
    output=Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError('Submission output must be an empty directory')
    output.mkdir(parents=True,exist_ok=True)
    for name in ('main.tex','appendix_examples.tex'):
        shutil.copyfile(ROOT/'paper'/submission/name,output/name)
    shutil.copyfile(ROOT/'paper/neurips_2026.sty',output/'neurips_2026.sty')
    bibliography='references_aiscik.bib' if submission=='aiscik' else 'references_mathai.bib'
    bib=(ROOT/'paper/shared'/bibliography).read_text(encoding='utf-8')
    supplemental=[]
    if submission=='mathai':
        # The MATH-AI bibliography predates four citations in its final
        # manuscript. Supplement only absent entries from the supplied AISciK bib.
        present=set(re.findall(r'@\w+\s*\{\s*([^,\s]+)',bib))
        source=(ROOT/'paper/shared/references_aiscik.bib').read_text(encoding='utf-8')
        for entry in re.split(r'(?m)(?=^@)',source):
            match=re.match(r'@\w+\s*\{\s*([^,\s]+)',entry)
            if match and match[1] not in present:
                bib+='\n'+entry
                supplemental.append(match[1])
                present.add(match[1])
    (output/'references.bib').write_text(bib,encoding='utf-8')
    (output/'build_sources.json').write_text(json.dumps({
        'submission':submission,'bibliography':bibliography,
        'supplemental_bibliography':'references_aiscik.bib' if supplemental else None,
        'supplemental_keys':supplemental},indent=2)+'\n',encoding='utf-8')
    shutil.copyfile(ROOT/'paper/shared/fig_pipeline_tikz.tex',output/'fig_pipeline_tikz.tex')
    for path in (ROOT/'paper/shared/figures').glob('*.pdf'):
        shutil.copyfile(path,output/path.name)
    print(f'Staged {submission} at {output}; build there with latexmk -pdf main.tex')
