"""Plot failure modes, question-type leakage, and error shares for the workshop paper.

Uses per-question response CSVs when available, with a summary-CSV fallback.
The published workflow stages all 26 raw response files through:

    axiomshift paper-assets --output outputs/figures

Leakage counts include both answerable and abstention cases. Summary inputs
recover abstention-case leakage from its reported share of abstention failures.
"""

import csv
import glob
import math
import re
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

matplotlib.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 7,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "axes.linewidth": 0.6, "axes.edgecolor": "0.15",
    "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "savefig.dpi": 400, "savefig.bbox": "tight", "figure.dpi": 140,
})

HERE = Path(__file__).resolve().parent
SUMS = HERE / "summaries"
OUT = HERE / "paper_v3"
OUT.mkdir(exist_ok=True)

# Okabe-Ito, colourblind-safe and legible in greyscale print because the four
# lightnesses differ. Mode C (prior leakage) gets vermillion and every visual
# emphasis: filled marker, heaviest line, drawn last.
MODES = [
    ("A", "Wrong number, not the prior",      "o", "#0072B2", "-",  0.9, False),
    ("B", "Failed to abstain, not the prior", "s", "#009E73", "-",  0.9, False),
    ("D", "False abstention",                 "^", "#E69F00", "--", 0.9, False),
    ("C", "Prior-leaking answer"   ,            "D", "#D55E00", "-",  1.9, True),
]

# Fixed pools, from the question file: of 490 answerable items 444 are
# prior-distinguishing, and of 210 unanswerable items 200 are.
ANS_TOTAL, ANS_PRIOR = 490, 444
UNA_TOTAL, UNA_PRIOR = 210, 200




#  Load per-question responses when available; otherwise use summaries.
#  Denominators are ALWAYS this model's own complete-answer count, never 700.


COMPLETE_CATS = {"correct_numeric", "correct_abstention", "wrong_numeric",
                 "wrong_numeric_prior_leak", "failure_to_abstain", "false_abstention"}


def _rd(p):
    with open(p, newline="", encoding="utf-8-sig", errors="replace") as f:
        return list(csv.DictReader(f))


def _T(v):
    return str(v).strip().lower() in ("true", "1", "yes")


def load_raw():
    qfile = None
    for name in ("seven_worlds_questions_700questions_revised.csv",
                 "seven_worlds_questions_700questions.csv"):
        for folder in (HERE, HERE.parent):
            if (folder / name).is_file():
                qfile = folder / name
                break
        if qfile:
            break
    if qfile is None:
        return None
    Q = {r["question_id"]: r for r in _rd(qfile)}
    ans = {q for q, r in Q.items() if r["abstain_type"] == "none" and _T(r["prior_distinguishes"])}
    una = {q for q, r in Q.items() if r["abstain_type"] != "none" and _T(r["prior_distinguishes"])}
    print(f"  questions: {qfile.name}  ({len(ans)} answerable, {len(una)} unanswerable, "
          f"both prior-distinguishing)")

    models = []
    for p in sorted(HERE.glob("*.csv")):
        if any(k in p.name for k in ("questions", "summary", "ALL_MODELS", "table")):
            continue
        rows = _rd(p)
        if not rows or "error_category" not in rows[0]:
            continue
        seen = {r["question_id"]: r for r in rows}
        rs = [r for r in seen.values()
              if r["question_id"] in Q and r["error_category"] in COMPLETE_CATS]
        if not rs:
            continue
        n = len(rs)
        leak_rows = [r for r in rs if _T(r.get("matches_prior_prediction"))]
        fa = sum(1 for r in rs if r["error_category"] == "failure_to_abstain")
        leak_una = sum(1 for r in leak_rows if r["question_id"] in una)
        d = {
            "model": rs[0]["model_nickname"],
            "n": n,
            "acc": 100 * sum(1 for r in rs if _T(r["is_correct"])) / n,
            "A": sum(1 for r in rs if r["error_category"] == "wrong_numeric"),
            "B": fa - leak_una,
            "C": len(leak_rows),
            "D": sum(1 for r in rs if r["error_category"] == "false_abstention"),
            "leak_ans": len(leak_rows) - leak_una,
            "leak_una": leak_una,
            # Seen pools, so a partial run is never divided by 700.
            "n_ans_pool": sum(1 for r in rs if r["question_id"] in ans),
            "n_una_pool": sum(1 for r in rs if r["question_id"] in una),
        }
        models.append(d)
    models.sort(key=lambda m: m["acc"])
    return models


def read_summary(path):
    rows = list(csv.reader(open(path, encoding="utf-8-sig", newline="")))
    d, cur = {}, None
    d["model"] = rows[0][1]
    for r in rows:
        if not r:
            continue
        if r[0].startswith("==="):
            cur = r[0]
            continue
        if cur == "=== COVERAGE ===" and r[0] == "real answers":
            d["n"] = int(r[1])
        elif cur == "=== HEADLINE ===":
            if r[0] == "accuracy %":
                d["acc"] = float(r[1])
            elif r[0] == "prior share of abstention failures %":
                d["pshare"] = float(r[1]) if r[1] not in ("", "-") else 0.0
        elif cur == "=== FAILURE BREAKDOWN ===" and len(r) > 2 and r[2].isdigit():
            d[r[0]] = int(r[2])
        elif cur == "=== ABSTENTION ===" and len(r) > 2:
            if r[0] == "false abstention (answerable)":
                d["n_ans"] = int(r[2])
            elif r[0] == "failure to abstain (unanswerable)":
                d["n_una"] = int(r[2])
    fa = d.get("failure_to_abstain", 0)
    # Leakage on unanswerable items, recovered from the reported share.
    d["leak_una"] = round(d.get("pshare", 0.0) / 100.0 * fa)
    d["leak_ans"] = d.get("wrong_numeric_prior_leak", 0)
    d["A"] = d.get("wrong_numeric", 0)
    d["B"] = fa - d["leak_una"]
    d["C"] = d["leak_ans"] + d["leak_una"]
    d["D"] = d.get("false_abstention", 0)
    return d


def load():
    models = load_raw()
    if models:
        print("  source: raw per-item CSVs (complete answers only)")
    else:
        print("  source: summaries/ (raw CSVs not found)")
        models = [read_summary(p) for p in sorted(glob.glob(str(SUMS / "summary_*.csv")))]
        models.sort(key=lambda m: m["acc"])
    print(f"  {len(models)} models, accuracy {models[0]['acc']:.1f}-{models[-1]['acc']:.1f}")
    return models


def ols(xs, ys):
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    b = (sum((x - mx) * (y - my) for x, y in zip(xs, ys))
         / sum((x - mx) ** 2 for x in xs))
    return b, my - b * mx


def pearson(xs, ys):
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    sy = math.sqrt(sum((y - my) ** 2 for y in ys))
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / (sx * sy)


def scatter_fig(models, values, ylabel, ylim, fname, legend_loc, fmt="{:+.2f}"):
    """Shared drawing routine: same layout and shapes as the greyscale
    originals, one colour per mode, mode C emphasised and drawn on top."""
    acc = [m["acc"] for m in models]
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    handles, stats = [], []
    for key, label, mk, col, ls, lw, filled in MODES:
        ys = values(key, models)
        b, a = ols(acc, ys)
        r = pearson(acc, ys)
        z = 4 if filled else 2
        ax.scatter(acc, ys, marker=mk, s=15 if filled else 13,
                   facecolors=col if filled else "white",
                   edgecolors=col, linewidths=0.8, zorder=z + 1)
        ax.plot([0, 100], [a, a + 100 * b], ls=ls, lw=lw, color=col, zorder=z)
        handles.append(Line2D([0], [0], color=col, ls=ls, lw=lw, marker=mk,
                              ms=4 if filled else 3.5,
                              mfc=col if filled else "white", mec=col, mew=0.8,
                              label=f"{label}  ({fmt.format(b)})"))
        stats.append((label, b, r, a + 10 * b, a + 90 * b))
    ax.set_xlabel("model accuracy (%)")
    ax.set_ylabel(ylabel)
    ax.set_xlim(0, 100)
    ax.set_ylim(*ylim)
    ax.legend(handles=handles, frameon=False, loc=legend_loc, handlelength=2.2,
              handletextpad=0.5, labelspacing=0.3, borderaxespad=0.2, fontsize=5.8)
    for e in ("pdf", "png"):
        fig.savefig(OUT / f"{fname}.{e}")
    plt.close(fig)
    return stats


def fig1(models):
    stats = scatter_fig(
        models,
        lambda k, ms: [100 * m[k] / m["n"] for m in ms],
        "failures per 100 questions", (-4, 62), "fig1_decline", "upper right")
    print("\nFIG 1 / TABLE 1  (failures per 100 questions)")
    print(f"  {'mode':<34}{'slope':>8}{'r':>7}{'@10':>7}{'@90':>7}{'elim':>7}")
    for label, b, r, y10, y90 in stats:
        el = 100 * (y10 - y90) / y10 if y10 else float("nan")
        print(f"  {label:<34}{b:8.3f}{r:7.2f}{y10:7.1f}{y90:7.1f}{el:6.0f}%")
    return stats


def fig4(models):
    def share(k, ms):
        out = []
        for m in ms:
            t = m["A"] + m["B"] + m["C"] + m["D"]
            out.append(100 * m[k] / t if t else 0.0)
        return out
    stats = scatter_fig(models, share, "share of that model's errors (%)",
                        (-2, 100), "fig4_share", "upper left")
    print("\nFIG 4  (share of each model's errors)")
    print(f"  {'mode':<34}{'slope':>8}{'r':>7}{'@10':>7}{'@90':>7}")
    for label, b, r, y10, y90 in stats:
        print(f"  {label:<34}{b:+8.3f}{r:+7.2f}{y10:7.1f}{y90:7.1f}")
    return stats


def fig3(models):
    """Leakage split by item type, fixed denominators, no conditioning.

    For a partial run the pools scale with coverage; the file is shuffled, so a
    prefix is a fair draw. Exact for the 23 complete models.
    """
    acc = [m["acc"] for m in models]
    ya, yu = [], []
    for m in models:
        n_ans = m.get("n_ans_pool") or m.get("n_ans", ANS_TOTAL) * ANS_PRIOR / ANS_TOTAL
        n_una = m.get("n_una_pool") or m.get("n_una", UNA_TOTAL) * UNA_PRIOR / UNA_TOTAL
        ya.append(100 * m["leak_ans"] / n_ans)
        yu.append(100 * m["leak_una"] / n_una)
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    bu, au = ols(acc, yu); ru = pearson(acc, yu)
    ba, aa = ols(acc, ya); ra = pearson(acc, ya)
    ax.scatter(acc, yu, marker="D", s=15, facecolors="#D55E00",
               edgecolors="#D55E00", linewidths=0.8, zorder=4)
    ax.plot([0, 100], [au, au + 100 * bu], "-", lw=1.9, color="#D55E00", zorder=3)
    ax.scatter(acc, ya, marker="o", s=13, facecolors="white",
               edgecolors="#0072B2", linewidths=0.8, zorder=3)
    ax.plot([0, 100], [aa, aa + 100 * ba], "--", lw=0.9, color="#0072B2", zorder=2)
    ax.legend(handles=[
        Line2D([0], [0], color="#D55E00", lw=1.9, marker="D", ms=4,
               mfc="#D55E00", mec="#D55E00",
               label=f"unanswerable, $n$=200  ({bu:+.3f}, $r$={ru:+.2f})"),
        Line2D([0], [0], color="#0072B2", lw=0.9, ls="--", marker="o", ms=3.5,
               mfc="white", mec="#0072B2", mew=0.8,
               label=f"answerable, $n$=444  ({ba:+.3f}, $r$={ra:+.2f})")],
        frameon=False, loc="upper right", handlelength=2.2, handletextpad=0.5,
        labelspacing=0.3, borderaxespad=0.2, fontsize=5.8)
    ax.set_xlabel("model accuracy (%)")
    ax.set_ylabel("answers leaking the prior (%)")
    ax.set_xlim(0, 100)
    ax.set_ylim(-1, max(max(ya), max(yu)) * 1.15)
    for e in ("pdf", "png"):
        fig.savefig(OUT / f"fig3_split.{e}")
    plt.close(fig)
    print("\nFIG 3  (leakage split by item type)")
    print(f"  {'pool':<22}{'slope':>8}{'r':>7}{'@10':>7}{'@90':>7}")
    print(f"  {'answerable (444)':<22}{ba:+8.3f}{ra:+7.2f}{aa+10*ba:7.1f}{aa+90*ba:7.1f}")
    print(f"  {'unanswerable (200)':<22}{bu:+8.3f}{ru:+7.2f}{au+10*bu:7.1f}{au+90*bu:7.1f}")


def main():
    which = sys.argv[1:] or ["fig1", "fig3", "fig4"]
    models = load()
    tot_a = sum(m["leak_ans"] for m in models)
    tot_u = sum(m["leak_una"] for m in models)
    print(f"  leakage: {tot_a} answerable + {tot_u} unanswerable "
          f"({100*tot_u/(tot_a+tot_u):.0f}% would be misfiled under mode B)")
    if "fig1" in which:
        fig1(models)
    if "fig3" in which:
        fig3(models)
    if "fig4" in which:
        fig4(models)
    print(f"\n  written to {OUT}")


if __name__ == "__main__":
    main()
