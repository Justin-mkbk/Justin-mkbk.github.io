"""Compare abstention-case leakage across all 20 prior-distinguishing families.

Run through ``axiomshift paper-assets --output outputs/figures``. Families with
fewer than five numeric commitments in either model group are listed without a
rating. The table includes every eligible family rather than a selected example.
"""

import csv
import glob
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "paper_v2"
OUT.mkdir(exist_ok=True)

MIN_N = 5
GROUP = 5  # strongest GROUP models vs weakest GROUP models

COMPLETE = {"correct_numeric", "correct_abstention", "wrong_numeric",
            "wrong_numeric_prior_leak", "failure_to_abstain", "false_abstention"}

PRETTY = {
    "fall_time_weight_only": "Fall time, weight only",
    "fall_time_conflicting_stopwatch": "Fall time, conflicting stopwatch",
    "throw_up_two_times": "Throw up, two times",
    "molar_mass_two_powers": "Molar mass, two powers",
    "molar_mass_missing_power": "Molar mass, missing power",
    "missing_codon_line": "Codon table, missing line",
    "ambiguous_codon": "Codon table, ambiguous",
    "polygon_curvature_withheld": "Polygon, curvature withheld",
    "polygon_sides_only": "Polygon, sides only",
    "polygon_routes_disagree": "Polygon, routes disagree",
    "sas_curvature_missing": "SAS, curvature missing",
    "sas_quoted_side_conflicts": "SAS, quoted side conflicts",
    "sas_two_triangles_fit": "SAS, two triangles fit",
    "order_missing_label": "Order, missing label",
    "order_ambiguous_fact": "Order, ambiguous fact",
    "order_cycle_forced": "Order, cycle forced",
    "market_every_price_clears": "Market, every price clears",
    "market_inconsistent": "Market, inconsistent",
    "stated_formula_conflicts": "Stated formula conflicts",
    "stated_length_conflicts": "Stated length conflicts",
}


def rd(p):
    with open(p, newline="", encoding="utf-8-sig", errors="replace") as f:
        return list(csv.DictReader(f))


def T(v):
    return str(v).strip().lower() in ("true", "1", "yes")


def find_questions():
    for folder in (HERE, HERE.parent):
        for name in ("seven_worlds_questions_700questions_revised.csv",
                     "seven_worlds_questions_700questions.csv"):
            p = folder / name
            if p.is_file():
                rows = rd(p)
                if rows and "prior_distinguishes" in rows[0]:
                    print(f"  questions: {p.name}")
                    return {r["question_id"]: r for r in rows}
    raise SystemExit("question file not found")


def main():
    Q = find_questions()
    pool = {q for q, r in Q.items()
            if r["abstain_type"] != "none" and T(r["prior_distinguishes"])}

    models = {}
    for p in sorted(HERE.glob("*.csv")):
        if any(k in p.name for k in ("questions", "summary", "ALL_MODELS", "table")):
            continue
        rows = rd(p)
        if not rows or "error_category" not in rows[0]:
            continue
        seen = {r["question_id"]: r for r in rows}
        rs = [r for r in seen.values()
              if r["question_id"] in Q and r["error_category"] in COMPLETE]
        if not rs:
            continue
        acc = 100 * sum(1 for r in rs if T(r["is_correct"])) / len(rs)
        models[rs[0]["model_nickname"]] = (acc, rs)

    order = sorted(models, key=lambda m: -models[m][0])
    strong, weak = order[:GROUP], order[-GROUP:]
    print(f"  strongest {GROUP}: " + ", ".join(f"{m} ({models[m][0]:.0f})" for m in strong))
    print(f"  weakest   {GROUP}: " + ", ".join(f"{m} ({models[m][0]:.0f})" for m in weak))

    def rate(group, ids):
        x = y = 0
        for m in group:
            for r in models[m][1]:
                if (r["question_id"] in ids and not T(r["model_abstained"])
                        and str(r.get("model_answer_numeric", "")).strip()):
                    y += 1
                    x += T(r.get("matches_prior_prediction"))
        return x, y

    fams = sorted({Q[q]["question_family"] for q in pool})
    rated, unrated = [], []
    for f in fams:
        ids = {q for q in pool if Q[q]["question_family"] == f}
        xs, ys = rate(strong, ids)
        xw, yw = rate(weak, ids)
        if ys >= MIN_N and yw >= MIN_N:
            ps, pw = 100 * xs / ys, 100 * xw / yw
            rated.append((ps - pw, f, ps, ys, pw, yw))
        else:
            unrated.append((f, ys, yw))
    rated.sort(reverse=True)

    lines = ["% All families in the unanswerable, prior-distinguishing pool",
             r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Question family & \multicolumn{2}{c}{Strongest 5} & "
             r"\multicolumn{2}{c}{Weakest 5} & $\Delta$ \\",
             r"\cmidrule(lr){2-3}\cmidrule(lr){4-5}",
             r" & Leak & $n$ & Leak & $n$ & \\", r"\midrule"]
    for d, f, ps, ys, pw, yw in rated:
        name = PRETTY.get(f, f.replace("_", " "))
        bold = r"\textbf{%s}" % name if d > 0 else name
        lines.append(f"{bold} & {ps:.0f} & {ys} & {pw:.0f} & {yw} & ${d:+.0f}$ \\\\")
    if unrated:
        lines.append(r"\midrule")
        for f, ys, yw in sorted(unrated):
            name = PRETTY.get(f, f.replace("_", " "))
            lines.append(f"{name} & -- & {ys} & -- & {yw} & -- \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (OUT / "tableA_families.tex").write_text("\n".join(lines), encoding="utf-8")

    print(f"\n  {'family':<34}{'strong':>8}{'n':>5}{'weak':>7}{'n':>5}{'delta':>8}")
    for d, f, ps, ys, pw, yw in rated:
        print(f"  {f:<34}{ps:8.0f}{ys:5d}{pw:7.0f}{yw:5d}{d:+8.0f}")
    for f, ys, yw in sorted(unrated):
        print(f"  {f:<34}{'--':>8}{ys:5d}{'--':>7}{yw:5d}{'--':>8}")

    if rated:
        names = [f for _, f, *_ in rated]
        mid = sorted(d for d, *_ in rated)[len(rated) // 2]
        print(f"\n  families in pool: {len(fams)}   rated: {len(rated)}   "
              f"not rated (n<{MIN_N}): {len(unrated)}")
        if "fall_time_weight_only" in names:
            print(f"  fall_time_weight_only rank: {names.index('fall_time_weight_only') + 1}"
                  f" of {len(rated)}")
        print(f"  median delta among rated: {mid:+.0f}")
        print(f"  families with delta > 0: {sum(1 for d, *_ in rated if d > 0)} of {len(rated)}")
    print(f"\n  written to {OUT}/tableA_families.tex")


if __name__ == "__main__":
    main()
