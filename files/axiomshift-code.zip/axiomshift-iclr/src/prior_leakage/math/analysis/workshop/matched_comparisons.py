#!/usr/bin/env python3
"""Calculate failure-mode regressions and robustness tables for the workshop paper.

Run through ``axiomshift paper-assets --output outputs/figures``. The analysis
reports all four failure modes on both completed-answer and attempted-answer
bases, including absolute slopes and the fraction eliminated between 10% and
90% accuracy. It does not assume leakage is the slowest-declining failure mode.
"""

from __future__ import annotations

import csv
import math
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "paper_v2"

COMPLETE = {"correct_numeric", "correct_abstention", "wrong_numeric",
            "wrong_numeric_prior_leak", "failure_to_abstain", "false_abstention"}
ALL_REAL = COMPLETE | {"missing_numeric_answer", "ran_out_of_room", "unreadable_reply"}

WORLD_SHORT = {
    "altered_valence_chemistry": "Valence chemistry",
    "two_mass_materials": "Two-mass physics",
    "altered_codon_table": "Codon table",
    "polygon_three_worlds": "Polygon geometry",
    "partial_order_counts": "Partial orders",
    "sas_three_worlds": "SAS congruence",
    "upward_demand_market": "Upward demand",
}

META = {
 "davinci-002": ("base", None), "gpt-3.5-turbo": ("instruct", None),
 "gpt-4.1": ("instruct", None), "gpt-5.4-nano": ("reasoning", None),
 "gpt-5.4-mini": ("reasoning", None), "gpt-5.6-sol": ("reasoning", None),
 "gemma-3-4b-it": ("instruct", 4), "llama-3.1-8b-instruct": ("instruct", 8),
 "llama-3.1-70b-instruct": ("instruct", 70), "nemotron-nano-9b-v2": ("reasoning", 9),
 "qwen2.5-7b-base": ("base", 7), "qwen2.5-7b-instruct": ("instruct", 7),
 "qwen2.5-14b-instruct": ("instruct", 14), "qwen2.5-32b-instruct": ("instruct", 32),
 "qwen2.5-72b-instruct": ("instruct", 72), "qwen2.5-math-7b-base": ("base", 7),
 "qwen2.5-math-7b-instruct": ("math", 7), "qwen2.5-math-72b-base": ("base", 72),
 "qwen2.5-math-72b-instruct": ("math", 72), "qwen3-4b-instruct": ("instruct", 4),
 "qwen3-4b-thinking": ("thinking", 4), "qwen3-30b-a3b-instruct": ("instruct", 30),
 "qwen3-30b-a3b-thinking": ("thinking", 30), "qwen3-235b-a22b-instruct": ("instruct", 235),
}

DISPLAY = {
 "gpt-5.6-sol": "GPT-5.6-sol", "gpt-5.4-mini": "GPT-5.4-mini", "gpt-5.4-nano": "GPT-5.4-nano",
 "gpt-4.1": "GPT-4.1", "gpt-3.5-turbo": "GPT-3.5-turbo", "davinci-002": "davinci-002",
 "gemma-3-4b-it": "Gemma-3-4B", "llama-3.1-8b-instruct": "Llama-3.1-8B",
 "llama-3.1-70b-instruct": "Llama-3.1-70B", "nemotron-nano-9b-v2": "Nemotron-Nano-9B",
 "qwen2.5-7b-base": "Qwen2.5-7B (base)", "qwen2.5-7b-instruct": "Qwen2.5-7B",
 "qwen2.5-14b-instruct": "Qwen2.5-14B", "qwen2.5-32b-instruct": "Qwen2.5-32B",
 "qwen2.5-72b-instruct": "Qwen2.5-72B", "qwen2.5-math-7b-base": "Qwen2.5-Math-7B (base)",
 "qwen2.5-math-7b-instruct": "Qwen2.5-Math-7B", "qwen2.5-math-72b-base": "Qwen2.5-Math-72B (base)",
 "qwen2.5-math-72b-instruct": "Qwen2.5-Math-72B", "qwen3-4b-instruct": "Qwen3-4B",
 "qwen3-4b-thinking": "Qwen3-4B-Think", "qwen3-30b-a3b-instruct": "Qwen3-30B-A3B",
 "qwen3-30b-a3b-thinking": "Qwen3-30B-A3B-Think", "qwen3-235b-a22b-instruct": "Qwen3-235B-A22B",
}

MODES = [("A", "Wrong number, not the prior"),
         ("B", "Failed to abstain, not the prior"),
         ("C", "Prior-matching answer"),
         ("D", "False abstention")]


def enc(p):
    for e in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            p.open(encoding=e, newline="").read()
            return e
        except UnicodeDecodeError:
            continue
    return "utf-8-sig"


def rd(p):
    with p.open(encoding=enc(p), newline="") as h:
        return list(csv.DictReader(h))


def T(v):
    return str(v).strip().lower() in ("true", "1", "yes")


def pearson(xs, ys):
    k = len(xs); mx = sum(xs) / k; my = sum(ys) / k
    d = math.sqrt(sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys))
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / d if d else float("nan")


def ols(xs, ys):
    k = len(xs); mx = sum(xs) / k; my = sum(ys) / k
    d = sum((x - mx) ** 2 for x in xs)
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / d if d else 0.0
    return b, my - b * mx


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (100 * (c - h), 100 * (c + h))


def load():
    Q = None
    for folder in (HERE, HERE.parent, HERE.parent / "REVISED QUESTION SET"):
        for name in ("seven_worlds_questions_700questions_revised.csv",
                     "seven_worlds_questions_700questions.csv"):
            p = folder / name
            if p.is_file():
                rows = rd(p)
                if rows and "prior_distinguishes" in rows[0]:
                    Q = {r["question_id"]: r for r in rows}
                    print(f"  questions: {p.name}")
                    break
        if Q:
            break
    if not Q:
        raise SystemExit("question file not found")
    models = {}
    for p in sorted(HERE.glob("*.csv")):
        if any(k in p.name for k in ("questions", "summary", "ALL_MODELS", "table", "appendix")):
            continue
        rows = rd(p)
        if not rows or "error_category" not in rows[0]:
            continue
        seen = {}
        for r in rows:
            seen[r["question_id"]] = r
        rows = [r for r in seen.values() if r["question_id"] in Q]
        c = [r for r in rows if r["error_category"] in COMPLETE]
        a = [r for r in rows if r["error_category"] in ALL_REAL]
        if c:
            models[c[0]["model_nickname"]] = {"complete": c, "all": a}
    return Q, models


def budget(rows, Q):
    """Four mutually exclusive failure modes, each as a % of all items.

    Prior-matching answers are pulled OUT of the two competence modes, so a
    prior-matching answer on an unanswerable item counts once, under C, not
    under B. Without this the decomposition double-counts: the category
    wrong_numeric_prior_leak only exists on answerable items, so 37% of all
    leakage events would otherwise be filed under B."""
    n = len(rows)
    c = Counter(r["error_category"] for r in rows)
    leak_in_fa = sum(1 for r in rows if r["error_category"] == "failure_to_abstain"
                     and T(r.get("matches_prior_prediction")))
    return {
        "n": n,
        "acc": 100 * sum(1 for r in rows if T(r["is_correct"])) / n,
        "A": 100 * c.get("wrong_numeric", 0) / n,
        "B": 100 * (c.get("failure_to_abstain", 0) - leak_in_fa) / n,
        "C": 100 * sum(1 for r in rows if T(r.get("matches_prior_prediction"))) / n,
        "D": 100 * c.get("false_abstention", 0) / n,
    }


def headline(rows, Q):
    n = len(rows)
    una = [r for r in rows if Q[r["question_id"]]["abstain_type"] != "none"]
    ans = [r for r in rows if Q[r["question_id"]]["abstain_type"] == "none"]
    com = [r for r in rows if T(Q[r["question_id"]]["prior_distinguishes"])
           and not T(r["model_abstained"]) and str(r.get("model_answer_numeric", "")).strip()]
    ok = sum(1 for r in rows if T(r["is_correct"]))
    return {
        "n": n, "correct": ok, "acc": 100 * ok / n,
        "leak": 100 * sum(1 for r in com if T(r.get("matches_prior_prediction"))) / len(com)
                if com else float("nan"),
        "fail_ab": 100 * sum(1 for r in una if r["error_category"] == "failure_to_abstain") / len(una)
                   if una else float("nan"),
        "false_ab": 100 * sum(1 for r in ans if r["error_category"] == "false_abstention") / len(ans)
                    if ans else float("nan"),
    }


def fit_table(models, Q, base):
    B = {m: budget(d[base], Q) for m, d in models.items()}
    names = list(B)
    acc = [B[m]["acc"] for m in names]
    out = []
    for key, label in MODES:
        ys = [B[m][key] for m in names]
        b, a = ols(acc, ys)
        lo, hi = a + b * 10, a + b * 90
        elim = 100 * (lo - hi) / lo if lo > 0 else float("nan")
        out.append({"key": key, "label": label, "slope": b, "r": pearson(acc, ys),
                    "lo": lo, "hi": hi, "elim": elim})
    return B, out


def f(v, p=1):
    return "--" if v is None or (isinstance(v, float) and math.isnan(v)) else f"{v:.{p}f}"


def main():
    print("=" * 74)
    print(" paper_v2 assets")
    print("=" * 74)
    OUT.mkdir(exist_ok=True)
    Q, models = load()
    print(f"  models: {len(models)}")

    Bc, fitc = fit_table(models, Q, "complete")
    Ba, fita = fit_table(models, Q, "all")

    # Table 1: the decomposition
    lines = ["% Table 1 - differential decline of failure modes",
             r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Failure mode & Slope & $r$ & At 10\% & At 90\% & Eliminated \\",
             r"\midrule"]
    for row in sorted(fitc, key=lambda d: d["slope"]):
        bold = r"\textbf{" if row["key"] == "C" else ""
        end = "}" if row["key"] == "C" else ""
        lines.append(f"{bold}{row['label']}{end} & {row['slope']:.3f} & {row['r']:.2f} & "
                     f"{row['lo']:.1f} & {max(row['hi'],0.0):.1f} & "
                     f"{bold}{row['elim']:.0f}\\%{end} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (OUT / "table1_decline.tex").write_text("\n".join(lines), encoding="utf-8")

    # robustness: same on all rows
    lines = ["% Table 1b - same decomposition, all rows incl. truncated",
             r"\begin{tabular}{lrrr}", r"\toprule",
             r"Failure mode & Slope & $r$ & Eliminated \\", r"\midrule"]
    for row in sorted(fita, key=lambda d: d["slope"]):
        lines.append(f"{row['label']} & {row['slope']:.3f} & {row['r']:.2f} & {row['elim']:.0f}\\% \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (OUT / "table1b_robustness.tex").write_text("\n".join(lines), encoding="utf-8")

    # Table 2: worlds, paired
    H = {m: headline(d["complete"], Q) for m, d in models.items()}
    order = sorted(H, key=lambda m: -H[m]["acc"])
    TOP, BOT = order[:5], order[-5:]
    idx = {m: {r["question_id"]: r for r in models[m]["complete"]} for m in models}

    def commits(m, qid):
        r = idx[m].get(qid)
        return (r is not None and T(Q[qid]["prior_distinguishes"])
                and not T(r["model_abstained"])
                and str(r.get("model_answer_numeric", "")).strip())

    rows2, total_items = [], 0
    for w in WORLD_SHORT:
        bot_r, top_r = [], []
        for qid, q in Q.items():
            if q["question_set"] != w or not T(q["prior_distinguishes"]):
                continue
            tc = [m for m in TOP if commits(m, qid)]
            bc = [m for m in BOT if commits(m, qid)]
            if len(tc) < 2 or len(bc) < 2:
                continue
            top_r.append(100 * sum(T(idx[m][qid].get("matches_prior_prediction")) for m in tc) / len(tc))
            bot_r.append(100 * sum(T(idx[m][qid].get("matches_prior_prediction")) for m in bc) / len(bc))
        if not top_r:
            continue
        b, t = sum(bot_r) / len(bot_r), sum(top_r) / len(top_r)
        total_items += len(top_r)
        rows2.append((t - b, WORLD_SHORT[w], b, t, len(top_r)))
    rows2.sort(reverse=True)
    lines = ["% Table 2 - per-world leakage, item-level paired test",
             r"\begin{tabular}{lrrrr}", r"\toprule",
             r"World & Weakest 5 & Strongest 5 & $\Delta$ & Items \\", r"\midrule"]
    for d, w, b, t, n in rows2:
        mark = r"\textbf{" if d > 2 else ""
        end = "}" if d > 2 else ""
        lines.append(f"{w} & {b:.1f} & {mark}{t:.1f}{end} & {mark}{d:+.1f}{end} & {n} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (OUT / "table2_worlds.tex").write_text("\n".join(lines), encoding="utf-8")
    print(f"  table2: {total_items} item-comparisons")

    # Appendix table: all models
    lines = ["% Appendix - all 24 models, complete answers only",
             r"\begin{tabular}{llrrrrrr}", r"\toprule",
             r"Model & Type & Params & $n$ & Acc. & 95\% CI & Leak & Fail-abst. \\",
             r"\midrule"]
    for m in order:
        h = H[m]
        lo, hi = wilson(h["correct"], h["n"])
        params = META[m][1]
        lines.append(f"{DISPLAY[m]} & {META[m][0]} & {params if params else '--'} & {h['n']} & "
                     f"{h['acc']:.1f} & [{lo:.1f}, {hi:.1f}] & {f(h['leak'])} & {f(h['fail_ab'])} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (OUT / "tableA1_models.tex").write_text("\n".join(lines), encoding="utf-8")

    # Figures
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 7.5,
        "axes.labelsize": 8, "axes.titlesize": 8,
        "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 6.8,
        "axes.spines.top": False, "axes.spines.right": False,
        "axes.linewidth": 0.7, "figure.dpi": 200,
        "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    })

    # Figure 1: the decline itself
    names = list(Bc)
    acc = [Bc[m]["acc"] for m in names]
    style = {"A": ("o", "0.55", "-"), "B": ("s", "0.55", "-"),
             "C": ("D", "0.05", "-"), "D": ("^", "0.7", "--")}
    fig, ax = plt.subplots(figsize=(3.4, 2.6))
    xs = [0, 100]
    for key, label in MODES:
        mk, col, ls = style[key]
        ys = [Bc[m][key] for m in names]
        b, a = ols(acc, ys)
        lw = 1.6 if key == "C" else 0.9
        ax.scatter(acc, ys, marker=mk, s=13, facecolors="white" if key != "C" else col,
                   edgecolors=col, linewidths=0.7, zorder=3 if key == "C" else 2)
        ax.plot(xs, [a + b * x for x in xs], ls=ls, lw=lw, color=col, zorder=2,
                label=f"{label}  ({b:+.2f})")
    ax.set_xlabel("model accuracy (%)")
    ax.set_ylabel("failures per 100 questions")
    ax.set_xlim(0, 100)
    ax.set_ylim(-2, 62)
    ax.legend(frameon=False, loc="upper right", handlelength=1.6,
              handletextpad=0.4, labelspacing=0.25, borderaxespad=0.2)
    for e in ("pdf", "png"):
        fig.savefig(OUT / f"fig1_decline.{e}")
    plt.close(fig)

    # Figure 2: fall_time ladder
    qids = [q for q, v in Q.items() if v["question_family"] == "fall_time_weight_only"]
    rows = []
    for m, d in models.items():
        s = {r["question_id"]: r for r in d["complete"]}
        a = 100 * sum(1 for r in d["complete"] if T(r["is_correct"])) / len(d["complete"])
        com = [s[q] for q in qids if q in s and not T(s[q]["model_abstained"])
               and str(s[q].get("model_answer_numeric", "")).strip()]
        if not com:
            rows.append((a, m, None, 0, 0))
        else:
            lk = sum(1 for r in com if T(r.get("matches_prior_prediction")))
            rows.append((a, m, 100 * lk / len(com), lk, len(com)))
    rows.sort()
    print("\n  fall_time_weight_only  (10 items, abstention is correct)")
    print(f"  {'model':<28}{'acc':>6}{'committed':>11}{'leaked':>8}{'%':>8}")
    for a, m, leak, lk, n in reversed(rows):
        pc = "--" if leak is None else f"{leak:.0f}"
        print(f"  {DISPLAY[m]:<28}{a:6.0f}{n:11d}{lk:8d}{pc:>8}")
    fig, ax = plt.subplots(figsize=(3.6, 3.4))
    for y, (a, m, leak, lk, n) in enumerate(rows):
        if leak is None:
            ax.plot([1.0], [y], marker="D", ms=3.0, mfc="white", mec="0.15", mew=0.8)
            continue
        ax.barh(y, max(leak, 0), height=0.64,
                color="0.28" if leak >= 50 else "0.80",
                edgecolor="0.15", linewidth=0.5)
        if leak == 0:
            ax.plot([0], [y], marker="|", ms=6, color="0.15", mew=1.1)
        # every bar carries its fraction, so equal-length bars are not
        # mistaken for equal evidence: 8/8 and 1/1 are both 100%.
        ax.annotate(f"{lk}/{n}", (max(leak, 0) + 2.0, y), fontsize=5.0,
                    va="center", color="0.45")
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels([f"{DISPLAY[m]} ({a:.0f})" for a, m, _, _, _ in rows], fontsize=5.7)
    ax.set_xlabel("answers matching the textbook prior (%)")
    ax.set_xlim(0, 116)
    ax.set_ylim(-0.7, len(rows) - 0.3)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.axvline(0, lw=0.6, color="0.15")
    ax.tick_params(axis="y", length=0)
    from matplotlib.patches import Patch
    from matplotlib.lines import Line2D
    ax.legend(handles=[
        Patch(facecolor="0.28", edgecolor="0.15", lw=0.5, label="$\\geq$50% match"),
        Patch(facecolor="0.80", edgecolor="0.15", lw=0.5, label="$<$50% match"),
        Line2D([0], [0], marker="D", ls="none", mfc="white", mec="0.15", mew=0.8,
               ms=3.0, label="abstained on all 10"),
        Line2D([0], [0], ls="none", label="labels are leaked/committed")],
        frameon=False, loc="lower right", fontsize=5.6,
        handletextpad=0.5, borderpad=0.2, labelspacing=0.28)
    for e in ("pdf", "png"):
        fig.savefig(OUT / f"fig2_falltime.{e}")
    plt.close(fig)

    # Numbers for the prose
    H = {m: headline(d["complete"], Q) for m, d in models.items()}
    lk = [H[m]["leak"] for m in names]
    fa = [H[m]["fail_ab"] for m in names]
    ac = [H[m]["acc"] for m in names]
    rxy, rxz, ryz = pearson(lk, fa), pearson(lk, ac), pearson(fa, ac)
    part = (rxy - rxz * ryz) / math.sqrt(max((1 - rxz ** 2) * (1 - ryz ** 2), 1e-12))
    notes = [
        "NUMBERS QUOTED IN THE TEXT",
        f"  models                                  {len(names)}",
        f"  accuracy range                          {min(ac):.1f} to {max(ac):.1f}",
        "",
        "  Differential decline (complete answers only):",
    ]
    for row in sorted(fitc, key=lambda d: d["slope"]):
        notes.append(f"    {row['label']:<36} slope {row['slope']:+.3f}  r {row['r']:+.2f}  "
                     f"{row['lo']:.1f} -> {max(row['hi'],0):.1f}  eliminated {row['elim']:.0f}%")
    notes += ["", "  Same on ALL rows (robustness):"]
    for row in sorted(fita, key=lambda d: d["slope"]):
        notes.append(f"    {row['label']:<36} slope {row['slope']:+.3f}  r {row['r']:+.2f}  "
                     f"eliminated {row['elim']:.0f}%")
    notes += ["",
              f"  r(leak, fail-to-abstain)               {rxy:+.3f}",
              f"  r(leak, fail-to-abstain | accuracy)    {part:+.3f}",
              f"  r(leak, accuracy)                      {rxz:+.3f}",
              f"  r(fail-to-abstain, accuracy)           {ryz:+.3f}",
              "",
              f"  Table 2 item-comparisons               {total_items}",
              "",
              "  CAVEAT TO STATE: 'leakage declines slower than any other mode' is FALSE.",
              "  False abstention declines more slowly (19% vs 55%) and is uncorrelated",
              "  with accuracy (r = -0.08). The correct claim is that the two",
              "  COMPETENCE-driven modes are eliminated while leakage is only halved."]
    (OUT / "numbers.txt").write_text("\n".join(notes) + "\n", encoding="utf-8")
    print("\n".join(notes))
    print("=" * 74)
    print(f" written to {OUT}")


if __name__ == "__main__":
    main()
