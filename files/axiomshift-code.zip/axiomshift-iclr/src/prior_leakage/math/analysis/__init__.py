"""Publication figures, tables, and manuscript staging."""
