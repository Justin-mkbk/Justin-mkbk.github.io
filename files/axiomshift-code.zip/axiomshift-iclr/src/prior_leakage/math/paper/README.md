# Workshop manuscript sources

`mathai/main.tex` and `aiscik/main.tex` contain the workshop submissions, each with its own appendix. Both use the figures, pipeline diagram, and bibliographies in `shared/`.

After installing the package from the repository root:

```bash
axiomshift stage-paper mathai --output outputs/mathai
axiomshift stage-paper aiscik --output outputs/aiscik
```

Staging supplies the shared NeurIPS style, figure PDFs, pipeline diagram, and bibliography. It fills missing MATH-AI citation entries from the supplied AISciK bibliography. Then run `latexmk -pdf main.tex` inside the staged folder if your LaTeX installation is available.

The three figure names are `failure_modes_by_accuracy`, `prior_leakage_by_question_type`, and `error_shares_by_accuracy`. `axiomshift paper-assets` recreates the workshop calculations and figures from the 26 saved runs.

PDF compilation requires a local LaTeX installation.
