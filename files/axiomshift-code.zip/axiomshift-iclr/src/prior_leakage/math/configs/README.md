# Model and prompt configuration

`models.json` defines reusable model presets. The CLI resolves `--model NAME` against this file, then applies explicit command-line overrides. `axiomshift models` lists the presets. A preset is a recorded evaluation configuration, not a guarantee that a hosted model identifier is still available.

For a local model, no file edit is needed:

```bash
axiomshift run --model MY_LOADED_MODEL --backend api --base-url http://localhost:1234/v1 --api-style chat --prompt local --parser local --limit 5 --output outputs/smoke
```

For reusable settings, create a JSON file such as `outputs/my-models.json`:

```json
{
  "my-local-model": {
    "backend": "api",
    "model_id": "YOUR_LOADED_MODEL_ID",
    "base_url": "http://localhost:1234/v1",
    "api_style": "chat",
    "prompt": "local",
    "parser": "local",
    "temperature": 0,
    "max_output_tokens": 800
  }
}
```

Run `axiomshift run --config outputs/my-models.json --model my-local-model --limit 5 --output outputs/config-smoke`. Add `--dry-run` to inspect resolved settings without inference. For base models use `is_base_model: true` and `api_style: completion`. HF presets use `backend: hf` and a local `model_path`; install the `[hf]` extra first.

`prompts.json` supplies system and base-model prompt templates selected by the preset's `prompt` key. `parser` selects answer extraction behavior for matching historical or new runs. The CLI's `--prompts PATH` can select a modified prompt file. Read [the protocol](../docs/protocol.md) before changing prompt/parser combinations for score comparisons.

The GUI creates its own local API settings from the form, using the `local` prompt and parser; it does not use a chosen models.json preset. Authentication uses an environment variable named by `api_key_env` (GUI: `LMSTUDIO_API_KEY`), never a token stored in JSON. Record changed settings in a new run folder.
