"""Small loopback-only browser interface; all jobs use the existing CLI."""
from __future__ import annotations

import ipaddress
import json
import os
import re
import secrets
import subprocess
import sys
import threading
import urllib.parse
import urllib.request
import webbrowser
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from ..dataset.io import DEFAULT_DATA, ROOT, read_csv
from ..evaluation.analysis import INCOMPLETE, RUNTIME


def local_url(value):
    parts = urllib.parse.urlsplit(str(value))
    try:
        loopback = parts.hostname == 'localhost' or ipaddress.ip_address(parts.hostname).is_loopback
    except ValueError:
        loopback = False
    if not loopback or parts.scheme not in ('http', 'https') or parts.username or parts.password or parts.query or parts.fragment:
        raise ValueError('The GUI connects only to a local HTTP(S) model server, e.g. http://localhost:1234/v1')
    return str(value).rstrip('/')


def discover_models(base_url):
    headers = {}
    if os.environ.get('LMSTUDIO_API_KEY'):
        headers['Authorization'] = 'Bearer ' + os.environ['LMSTUDIO_API_KEY']
    request = urllib.request.Request(local_url(base_url) + '/models', headers=headers)
    with urllib.request.urlopen(request, timeout=10) as response:
        data = json.load(response)
    return [item['id'] for item in data['data'] if isinstance(item.get('id'), str)]


class Jobs:
    def __init__(self, root=None):
        self.root = Path(root or Path.cwd()).resolve()
        self.lock = threading.Lock()
        self.job = None
        self.process = None

    def dataset(self, relative):
        if relative == 'data/seven_worlds.csv':
            return DEFAULT_DATA
        path = (self.root / relative).resolve()
        if path != self.root/'data/seven_worlds.csv' and not path.is_relative_to(self.root/'outputs/datasets'):
            raise ValueError('Choose the published dataset or a dataset generated in outputs/datasets')
        if not path.is_file() or path.suffix != '.csv':
            raise ValueError('Dataset CSV does not exist')
        return path

    def start(self, values):
        with self.lock:
            if self.job and self.job['status'] == 'running':
                raise ValueError('A job is already running; wait or pause the evaluation')
            action = values.get('action')
            name = values.get('name') or datetime.now().strftime('%Y%m%d-%H%M%S-%f')
            if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}', name):
                raise ValueError('Folder name must contain only letters, numbers, hyphens, or underscores')
            output = self.root/'outputs'/('datasets' if action == 'generate' else 'gui-runs')/name
            if not output.resolve().is_relative_to(self.root/'outputs'):
                raise ValueError('Output must stay in this project')
            args = [sys.executable, '-u', '-m', 'prior_leakage.math.axiomshift']
            dataset = None
            limit = None
            if action == 'generate':
                args += ['generate', '--output', str(output)]
                if str(values.get('seed', '')).strip():
                    args += ['--seed', str(int(values['seed']))]
            elif action == 'reference':
                args += ['analyse', '--output', str(output)]
            elif action == 'run':
                dataset = self.dataset(values.get('data', 'data/seven_worlds.csv'))
                model = str(values.get('model', '')).strip()
                if not model or len(model) > 300:
                    raise ValueError('Discover and choose a model first')
                limit = int(values.get('limit', 5))
                tokens = int(values.get('tokens', 800))
                if limit not in (5, 700) or not 1 <= tokens <= 131072:
                    raise ValueError('Choose 5 or 700 questions and a positive output-token budget (up to 131072)')
                style = values.get('style', 'chat')
                if style not in ('chat', 'completion'):
                    raise ValueError('Choose chat/instruct or base/completion')
                args += ['run', '--model', model, '--model-id', model, '--backend', 'api',
                         '--api-style', style, '--parser', 'local', '--prompt', 'local',
                         '--temperature', '0', '--max-output-tokens', str(tokens),
                         '--base-url', local_url(values.get('base_url', 'http://localhost:1234/v1')),
                         '--data', str(dataset), '--limit', str(limit), '--output', str(output)]
                if os.environ.get('LMSTUDIO_API_KEY'):
                    args += ['--api-key-env', 'LMSTUDIO_API_KEY']
                if style == 'completion':
                    args.append('--base-model')
                if values.get('resume'):
                    if not (output/'run.json').is_file():
                        raise ValueError('No saved run with this folder name to resume')
                    args.append('--resume')
            else:
                raise ValueError('Unknown action')
            if output.exists() and any(output.iterdir()) and not (action == 'run' and values.get('resume')):
                raise ValueError('Folder already exists; choose a new name, or resume an existing evaluation')
            # Keep logs outside generation outputs, which must be empty at launch.
            logs = self.root/'outputs/gui-logs'
            logs.mkdir(parents=True, exist_ok=True)
            log = logs/(name+'-'+secrets.token_hex(4)+'.log')
            if action == 'run' and values.get('resume'):
                (output/'.pause-requested').unlink(missing_ok=True)
            with log.open('w', encoding='utf-8') as handle:
                process = subprocess.Popen(args, cwd=self.root, stdout=handle, stderr=subprocess.STDOUT,
                                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            self.process = process
            self.job = {'action':action, 'name':name, 'output':str(output.relative_to(self.root)),
                        'log':str(log.relative_to(self.root)), 'status':'running', 'requested':limit}
            threading.Thread(target=self.finish, args=(process, dataset, output, log), daemon=True).start()
            return dict(self.job)

    def finish(self, process, dataset, output, log):
        code = process.wait()
        # Include missing and incomplete counts when reporting a partial run.
        if dataset and (output/'answers.csv').is_file():
            with log.open('a', encoding='utf-8') as handle:
                result = subprocess.run([sys.executable, '-m', 'prior_leakage.math.axiomshift', 'analyse', '--data', str(dataset),
                    '--results', str(output/'answers.csv'), '--output', str(output/'analysis')],
                    cwd=self.root, stdout=handle, stderr=subprocess.STDOUT,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
                code = code or result.returncode
        with self.lock:
            if self.process is process:
                self.job['status'] = 'failed' if code else ('paused' if (output/'.pause-requested').exists() else 'finished')
                self.job['exit_code'] = code

    def pause(self):
        with self.lock:
            if not self.job or self.job['action'] != 'run' or self.job['status'] != 'running':
                raise ValueError('There is no active evaluation to pause')
            output = self.root/self.job['output']
            output.mkdir(parents=True, exist_ok=True)
            (output/'.pause-requested').touch()
        return {'message':'Pause requested; the current model request will finish and be saved first.'}

    def snapshot(self):
        with self.lock:
            job = dict(self.job) if self.job else None
        if job:
            log = self.root/job['log']
            job['tail'] = log.read_text(encoding='utf-8', errors='replace')[-16000:] if log.exists() else ''
            job['files'] = [str(p.relative_to(self.root)).replace('\\','/') for p in sorted((self.root/job['output']).rglob('*'))
                            if p.is_file() and p.suffix in ('.csv', '.json', '.md')]
            answers = self.root/job['output']/'answers.csv'
            if answers.exists():
                try:
                    rows = read_csv(answers)
                    job['attempted'] = len(rows)
                    job['incomplete_or_error'] = sum(r.get('error_category') in INCOMPLETE | RUNTIME for r in rows)
                except (OSError, ValueError):
                    pass  # A writer may be replacing the CSV; the next poll will read it.
        datasets = ['data/seven_worlds.csv'] + [str(p.relative_to(self.root)).replace('\\','/')
                    for p in sorted((self.root/'outputs/datasets').glob('*/seven_worlds.csv')) if (p.parent/'verification.json').exists()]
        return {'job':job, 'datasets':datasets}


def make_server(port=8765, jobs=None):
    jobs = jobs or Jobs()
    token = secrets.token_urlsafe(32)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def reply(self, value, status=200, content_type='application/json'):
            content = json.dumps(value).encode() if content_type == 'application/json' else value
            self.send_response(status)
            self.send_header('Content-Type', content_type+'; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers()
            self.wfile.write(content)

        def trusted(self, mutate=False):
            allowed = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
            if self.headers.get('Host') not in allowed:
                raise ValueError('Invalid host')
            origin = self.headers.get('Origin')
            if origin and origin not in {'http://'+host for host in allowed}:
                raise ValueError('Invalid origin')
            if mutate and not secrets.compare_digest(self.headers.get('X-AxiomShift-Token', ''), token):
                raise ValueError('Invalid session token; reload the local page')

        def do_GET(self):
            try:
                self.trusted()
                parts = urllib.parse.urlsplit(self.path)
                if parts.path == '/':
                    html = (Path(__file__).parent/'gui.html').read_text(encoding='utf-8').replace('__SESSION_TOKEN__', token)
                    self.reply(html.encode(), content_type='text/html')
                elif parts.path == '/api/state':
                    self.trusted(mutate=True)
                    self.reply(jobs.snapshot())
                elif parts.path == '/api/models':
                    self.trusted(mutate=True)
                    query = urllib.parse.parse_qs(parts.query)
                    self.reply({'models':discover_models(query.get('url', ['http://localhost:1234/v1'])[0])})
                elif parts.path == '/file':
                    query = urllib.parse.parse_qs(parts.query)
                    path = (jobs.root/query.get('path', [''])[0]).resolve()
                    if not path.is_relative_to(jobs.root/'outputs') or not path.is_file() or path.suffix not in ('.csv','.json','.md'):
                        raise ValueError('No readable output artifact at this path')
                    self.reply(path.read_bytes(), content_type='text/plain')
                else:
                    self.reply({'error':'Not found'}, 404)
            except (ValueError, OSError, KeyError, TypeError) as error:
                self.reply({'error':str(error)}, 400)

        def do_POST(self):
            try:
                size = int(self.headers.get('Content-Length', 0))
                if not 0 < size <= 8192:
                    raise ValueError('Invalid request size')
                # Consume a bounded body before rejecting its headers. Closing
                # with unread bytes can reset the connection on Windows instead
                # of delivering the error response. No action precedes trust checks.
                body = self.rfile.read(size)
                self.trusted(mutate=True)
                values = json.loads(body)
                if not isinstance(values, dict):
                    raise ValueError('Expected an object')
                if self.path == '/api/start':
                    self.reply(jobs.start(values))
                elif self.path == '/api/pause':
                    self.reply(jobs.pause())
                else:
                    self.reply({'error':'Not found'}, 404)
            except (ValueError, OSError, KeyError, TypeError) as error:
                self.reply({'error':str(error)}, 400)

    server = ThreadingHTTPServer(('127.0.0.1', port), Handler)
    server.jobs = jobs
    return server


def serve(port=8765, open_browser=True):
    server = make_server(port)
    url = f'http://127.0.0.1:{server.server_port}'
    print(f'AxiomShift GUI: {url}\nKeep this terminal open. Ctrl+C closes the GUI; pause any evaluation first.', flush=True)
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
