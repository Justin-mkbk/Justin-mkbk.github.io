"""Local browser interface; launch with ``axiomshift gui``."""
from .server import Jobs, local_url, make_server, serve
