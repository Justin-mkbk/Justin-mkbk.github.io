"""AxiomShift: seven worlds, 700 questions, one evaluation pipeline."""

__version__ = "0.4.1"
