"""Serve a local model with vLLM, evaluate the benchmark, then stop the server.

Example on a GPU node with vLLM installed::

    python -m prior_leakage.math.axiomshift.models.vllm \
        --model kimi-k2-thinking --model-path /scratch/user/models/Kimi-K2-Thinking \
        --tensor-parallel-size 8 --limit 5 --output outputs/kimi-smoke

Model weights must already exist. The server listens only on loopback.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

from ..dataset.io import DEFAULT_DATA, ROOT, load_questions, select_questions
from ..evaluation.analysis import analyse
from .runner import run


def server_command(args, port):
    command = [str(Path(sys.executable).with_name('vllm')), 'serve', str(args.model_path),
               '--host', '127.0.0.1', '--port', str(port), '--served-model-name', args.model,
               '--tensor-parallel-size', str(args.tensor_parallel_size),
               '--max-model-len', str(args.max_model_len),
               '--gpu-memory-utilization', str(args.gpu_memory_utilization)]
    if args.language_model_only:
        command.append('--language-model-only')
    if args.reasoning_parser:
        command += ['--reasoning-parser', args.reasoning_parser]
    if args.trust_remote_code:
        command.append('--trust-remote-code')
    return command


def wait_for_server(process, base_url, model, timeout):
    deadline = time.monotonic() + timeout
    last_error = 'No model returned'
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError('vLLM exited during startup; inspect its server log')
        try:
            with urllib.request.urlopen(base_url+'/models', timeout=5) as response:
                models = json.load(response).get('data', [])
            if any(item.get('id') == model for item in models):
                return
        except (OSError, ValueError, urllib.error.URLError) as error:
            last_error = str(error)
        time.sleep(min(2, max(0, deadline-time.monotonic())))
    raise RuntimeError(f'vLLM startup timed out: {last_error}')


def stop_server(process):
    """Terminate the server and its GPU workers, including after an interrupted run."""
    try:
        if os.name == 'posix':
            os.killpg(process.pid, signal.SIGTERM)
        elif process.poll() is None:
            process.terminate()
        process.wait(timeout=15)
    except ProcessLookupError:
        pass
    except subprocess.TimeoutExpired:
        if os.name == 'posix':
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
        process.wait(timeout=15)


def evaluate(args):
    if not (args.model_path/'config.json').is_file():
        raise ValueError('model-path must contain a local model snapshot with config.json')
    if (args.tensor_parallel_size < 1 or args.max_output_tokens < 1 or args.limit < 1
            or args.max_model_len <= args.max_output_tokens
            or not 0 < args.gpu_memory_utilization < 1 or args.startup_timeout <= 0):
        raise ValueError('Invalid GPU, context, token, question, or startup setting')
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()) and not args.resume:
        raise ValueError('Output exists; use a new directory or --resume')
    if args.resume and not (output/'run.json').is_file():
        raise ValueError('No run.json found to resume')
    questions = select_questions(load_questions(args.data), limit=args.limit)
    # Keep the endpoint stable across Slurm jobs so resume uses the same settings.
    port = args.port or 20000 + int(hashlib.sha256(args.model.encode()).hexdigest()[:8], 16) % 20000
    if not 1024 <= port <= 65535:
        raise ValueError('Port must be between 1024 and 65535')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))
    command = server_command(args, port)
    if not Path(command[0]).is_file():
        raise ValueError('Install vLLM in the Python environment running this command')
    base_url = f'http://127.0.0.1:{port}/v1'
    spec = dict(backend='api', api_style='chat', model_id=args.model,
                model_path=str(args.model_path.resolve()), base_url=base_url,
                max_output_tokens=args.max_output_tokens, temperature=0.0,
                top_p=1.0, seed=42, prompt='local', parser='local', server_command=command)
    prompts = json.loads((ROOT/'configs/prompts.json').read_text(encoding='utf-8'))
    output.mkdir(parents=True, exist_ok=True)
    logs = output/'server-logs'
    logs.mkdir(exist_ok=True)
    stamp = time.strftime('%Y%m%d-%H%M%S') + '-' + str(os.getpid())
    versions = {}
    for package in ('vllm', 'torch', 'transformers', 'prior-leakage'):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    (logs/f'{stamp}.json').write_text(json.dumps(dict(command=command, versions=versions,
        job_id=os.environ.get('SLURM_JOB_ID'), dataset=str(args.data.resolve())), indent=2)+'\n', encoding='utf-8')
    env = dict(os.environ, HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
               TOKENIZERS_PARALLELISM='false', PYTHONUNBUFFERED='1')
    for key in ('MASTER_ADDR', 'MASTER_PORT', 'RANK', 'LOCAL_RANK', 'WORLD_SIZE'):
        env.pop(key, None)
    with (logs/f'{stamp}.log').open('w', encoding='utf-8') as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                   env=env, start_new_session=os.name == 'posix')
        try:
            wait_for_server(process, base_url, args.model, args.startup_timeout)
            run(args.model, spec, questions, args.data, output, prompts,
                resume=args.resume, timeout=3300, retries=3)
            analyse([output/'answers.csv'], args.data, output/'analysis')
        finally:
            stop_server(process)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', required=True)
    parser.add_argument('--model-path', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--data', type=Path, default=DEFAULT_DATA)
    parser.add_argument('--tensor-parallel-size', type=int, default=8)
    parser.add_argument('--max-model-len', type=int, default=24576)
    parser.add_argument('--gpu-memory-utilization', type=float, default=.90)
    parser.add_argument('--max-output-tokens', type=int, default=4096)
    parser.add_argument('--limit', type=int, default=5)
    parser.add_argument('--startup-timeout', type=float, default=3600)
    parser.add_argument('--port', type=int)
    parser.add_argument('--reasoning-parser')
    parser.add_argument('--language-model-only', action='store_true')
    parser.add_argument('--trust-remote-code', action='store_true')
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args(argv)
    previous_handler = signal.getsignal(signal.SIGTERM)
    def interrupted(signum, frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    try:
        evaluate(args)
    except KeyboardInterrupt:
        parser.exit(130, 'Evaluation interrupted\n')
    except (ValueError, RuntimeError, OSError) as error:
        parser.exit(1, f'Error: {error}\n')
    finally:
        signal.signal(signal.SIGTERM, previous_handler)


if __name__ == '__main__':
    main()
