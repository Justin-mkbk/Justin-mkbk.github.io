"""Inference adapters return text and metadata; scoring lives in scoring.py."""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request


def request_body(spec, question, prompts):
    style = spec["api_style"]
    system = prompts[spec.get("prompt", "local")]
    body = {"model": spec["model_id"]}
    temperature = spec.get("temperature", 0.0)
    if style == "completion":
        body.update(prompt=prompts["base"].format(question=question),
                    max_tokens=spec["max_output_tokens"],
                    stop=["\n\n", "\nQuestion", "\nFINAL_ANSWER"])
    elif style == "chat":
        body.update(messages=[{"role": "system", "content": system},
                              {"role": "user", "content": question}],
                    max_tokens=spec["max_output_tokens"])
    else:
        body.update(instructions=system, input=question, store=False,
                    max_output_tokens=spec["max_output_tokens"])
        if style == "responses_reasoning":
            body["reasoning"] = {"effort": spec.get("reasoning_effort", "medium")}
            temperature = None
    if temperature is not None:
        body["temperature"] = temperature
    if style in ("chat", "completion"):
        for option in ("seed", "top_p"):
            if option in spec:
                body[option] = spec[option]
    return body


def response_record(data, style):
    usage = data.get("usage") or {}
    if style.startswith("responses"):
        text = "".join(part.get("text", "") for item in data.get("output", [])
                       if item.get("type") == "message" for part in item.get("content", [])
                       if part.get("type") == "output_text")
        finish = (data.get("incomplete_details") or {}).get("reason") or data.get("status")
        return {"raw_response_text": text, "finish_reason": finish,
                "prompt_tokens": usage.get("input_tokens"), "completion_tokens": usage.get("output_tokens"),
                "reasoning_tokens": (usage.get("output_tokens_details") or {}).get("reasoning_tokens")}
    choice = data["choices"][0]
    message = choice.get("message") or {}
    return {"raw_response_text": choice.get("text", "") if style == "completion" else (choice.get("message") or {}).get("content") or "",
            "raw_reasoning_text": message.get("reasoning_content") or message.get("reasoning") or "",
            "finish_reason": choice.get("finish_reason"), "prompt_tokens": usage.get("prompt_tokens"),
            "completion_tokens": usage.get("completion_tokens"), "reasoning_tokens": None}


class APIBackend:
    def __init__(self, spec, prompts, timeout=900, retries=3):
        self.spec, self.prompts = spec, prompts
        self.timeout, self.retries = timeout, retries
        parsed = urllib.parse.urlsplit(spec["base_url"])
        if parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username or parsed.password or parsed.query:
            raise ValueError("base_url must be an HTTP(S) endpoint without credentials or query parameters")
        self.key = os.environ.get(spec.get("api_key_env", "OPENAI_API_KEY"), "")
        if parsed.hostname != "api.openai.com" and "api_key_env" not in spec:
            self.key = ""  # Never send an OpenAI credential to a custom/local endpoint.
        if parsed.hostname == "api.openai.com" and not self.key:
            raise ValueError("Set OPENAI_API_KEY before running an OpenAI model")

    def generate(self, question):
        style = self.spec["api_style"]
        route = {"chat": "chat/completions", "completion": "completions"}.get(style, "responses")
        headers = {"Content-Type": "application/json"}
        if self.key:
            headers["Authorization"] = f"Bearer {self.key}"
        request = urllib.request.Request(self.spec["base_url"].rstrip("/") + "/" + route,
            json.dumps(request_body(self.spec, question, self.prompts)).encode(), headers, method="POST")
        for attempt in range(1, self.retries + 1):
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    result = response_record(json.load(response), style)
                result["attempt_count"] = attempt
                return result
            except urllib.error.HTTPError as error:
                if error.code not in (408, 429, 500, 502, 503, 504) or attempt == self.retries:
                    raise RuntimeError(f"HTTP {error.code}: check endpoint, model access, credentials, and server logs") from error
            except (urllib.error.URLError, TimeoutError):
                if attempt == self.retries:
                    raise
            time.sleep(min(2 ** attempt, 30))


class HuggingFaceBackend:
    def __init__(self, spec, prompts, **_):
        try:
            import torch
            from transformers import AutoModelForCausalLM, AutoTokenizer, set_seed
        except ImportError as error:
            raise RuntimeError('Install the HF extra: python -m pip install -e ".[hf]"') from error
        self.torch, self.spec, self.prompts = torch, spec, prompts
        set_seed(spec.get("seed", 42))
        model_id = spec.get("model_path") or spec["model_id"]
        options = {"trust_remote_code": spec.get("trust_remote_code", False)}
        if spec.get("revision"):
            options["revision"] = spec["revision"]
        self.tokenizer = AutoTokenizer.from_pretrained(model_id, **options)
        dtype = spec.get("dtype", "auto")
        if dtype != "auto":
            dtype = getattr(torch, dtype)
        if spec.get("gpu_memory") or spec.get("cpu_memory"):
            options["max_memory"] = {i: spec.get("gpu_memory", "132GiB") for i in range(torch.cuda.device_count())}
            options["max_memory"]["cpu"] = spec.get("cpu_memory", "400GiB")
        self.model = AutoModelForCausalLM.from_pretrained(model_id, device_map=spec.get("device_map", "auto"),
                                                         dtype=dtype, **options)
        self.model.eval()

    def generate(self, question):
        tokenizer, spec = self.tokenizer, self.spec
        system = self.prompts[spec.get("prompt", "local")]
        if spec.get("is_base_model") or not getattr(tokenizer, "chat_template", None):
            # Historical HF base prompt differs from the API completion cue.
            prompt = f"{system}\n\n{question}\n\nFINAL_ANSWER:"
        else:
            prompt = tokenizer.apply_chat_template(
                [{"role": "system", "content": system}, {"role": "user", "content": question}],
                tokenize=False, add_generation_prompt=True)
        encoded = tokenizer(prompt, return_tensors="pt", add_special_tokens=False)
        length = encoded["input_ids"].shape[1]
        if length > spec.get("max_input_tokens", 16384):
            raise ValueError("Prompt exceeds max_input_tokens; refusing to truncate benchmark axioms")
        encoded = {k: v.to(self.model.device) for k, v in encoded.items()}
        config = {"max_new_tokens": spec["max_output_tokens"], "do_sample": False,
                  "pad_token_id": tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id}
        if spec.get("temperature", 0) > 0:
            config.update(do_sample=True, temperature=spec["temperature"], top_p=spec.get("top_p", 1.0))
        with self.torch.inference_mode():
            output = self.model.generate(**encoded, **config)[0][length:]
        eos = self.model.generation_config.eos_token_id
        eos = set(eos if isinstance(eos, list) else [eos])
        truncated = len(output) >= spec["max_output_tokens"] and int(output[-1]) not in eos
        return {"raw_response_text": tokenizer.decode(output, skip_special_tokens=True),
                "finish_reason": "length" if truncated else "stop", "prompt_tokens": length,
                "completion_tokens": len(output), "reasoning_tokens": None, "attempt_count": 1}
