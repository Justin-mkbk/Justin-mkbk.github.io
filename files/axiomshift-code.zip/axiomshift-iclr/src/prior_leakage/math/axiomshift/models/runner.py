"""Evaluate selected questions with one resumable loop for all model backends.

Example: ``axiomshift run --model MY_MODEL --backend api
--base-url http://localhost:1234/v1 --limit 5 --output outputs/smoke``.
Only question text reaches the model. Responses are parsed and scored locally;
run.json records settings and answers.jsonl/answers.csv record attempts.
Repeat with identical settings and --resume to skip completed answers.
"""
from __future__ import annotations

import importlib.metadata
import json
import hashlib
import math
import os
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

from .. import __version__
from ..evaluation.analysis import COMPLETE, deduplicate
from .backends import APIBackend, HuggingFaceBackend
from ..dataset.io import ROOT, number, sha256, write_csv
from ..evaluation.scoring import grade_response, parse_model_output


def score(question, response, spec):
    truncated = response.get("finish_reason") in ("length", "max_output_tokens")
    parsed = parse_model_output(response["raw_response_text"], truncated,
                                spec.get("parser", "local"), spec.get("is_base_model", False) and spec["backend"] != "hf")
    text, numeric, abstained, reasoning, method = parsed
    if numeric is not None and not math.isfinite(numeric):
        text, numeric, abstained, method = "", None, False, "failed"
    expected = question["expected_answer"]
    if expected != "ABSTAIN":
        expected = number(expected)
    error, prior, correct, category = grade_response(expected, number(question["prior_predicted_answer"]),
                                                     abstained, numeric, method, truncated)
    return {"model_answer_text": text, "model_answer_numeric": numeric, "model_abstained": abstained,
            "model_reasoning": reasoning, "parse_method": method, "absolute_error": error,
            "matches_prior_prediction": prior, "is_correct": correct, "error_category": category}


def run(name, spec, questions, dataset, output, prompts, *, resume=False, dry_run=False,
        timeout=900, retries=3, delay=0, backend=None):
    output = Path(output)
    source_hash = hashlib.sha256(b"".join(p.read_bytes() for p in sorted(Path(__file__).parents[1].rglob("*.py")))).hexdigest()
    settings = {"version": __version__, "source_sha256": source_hash, "model_nickname": name, "spec": spec,
                "dataset_sha256": sha256(dataset), "question_ids": [q["question_id"] for q in questions],
                "prompts": prompts}
    if dry_run:
        print(json.dumps({"questions": len(questions), "settings": settings}, indent=2))
        return
    output.mkdir(parents=True, exist_ok=True)
    manifest_path, journal = output / "run.json", output / "answers.jsonl"
    lock_path = output / ".running"
    # Exclusive creation prevents concurrent writers corrupting the resume journal.
    with lock_path.open("x", encoding="utf-8") as f:
        f.write(str(os.getpid()))
    try:
        prior_rows = []
        if manifest_path.exists():
            if not resume:
                raise ValueError("Output already contains a run; choose a new directory or pass --resume")
            old = json.loads(manifest_path.read_text(encoding="utf-8"))
            if old["settings"] != settings:
                raise ValueError("Resume refused: dataset, question selection, code version, model settings, or prompts changed")
            if journal.exists():
                # A partial last record is an error, never silently skipped.
                prior_rows = [json.loads(line) for line in journal.read_text(encoding="utf-8").splitlines() if line.strip()]
        elif journal.exists() or (output / "answers.csv").exists():
            raise ValueError("Output has results but no run manifest; choose an empty directory")
        else:
            versions = {}
            for package in ("torch", "transformers", "accelerate"):
                try:
                    versions[package] = importlib.metadata.version(package)
                except importlib.metadata.PackageNotFoundError:
                    pass
            manifest_path.write_text(json.dumps({"settings": settings, "python": platform.python_version(),
                "platform": platform.platform(), "packages": versions,
                "created_utc": datetime.now(timezone.utc).isoformat()}, indent=2) + "\n", encoding="utf-8")
        done = {r["question_id"] for r in prior_rows if r["error_category"] in COMPLETE}
        pending = [q for q in questions if q["question_id"] not in done]
        if pending and backend is None:
            cls = APIBackend if spec["backend"] == "api" else HuggingFaceBackend
            backend = cls(spec, prompts, timeout=timeout, retries=retries)
        rows = list(prior_rows)
        failed = False
        with journal.open("a", encoding="utf-8") as handle:
            for i, q in enumerate(pending, 1):
                if (output / '.pause-requested').exists():
                    print('Paused before the next question. Remove .pause-requested and resume with the same settings.', flush=True)
                    break
                start = time.monotonic()
                response = {"raw_response_text": "", "raw_reasoning_text": "", "finish_reason": None, "prompt_tokens": None,
                            "completion_tokens": None, "reasoning_tokens": None, "attempt_count": 0}
                error_type = error_message = None
                try:
                    response.update(backend.generate(q["question_text"]))
                    graded = score(q, response, spec)
                except Exception as error:
                    failed = True
                    error_type, error_message = type(error).__name__, str(error)
                    graded = {"model_answer_text": "", "model_answer_numeric": None, "model_abstained": False,
                        "model_reasoning": "", "parse_method": "failed", "absolute_error": None,
                        "matches_prior_prediction": None, "is_correct": None, "error_category": "runtime_error"}
                row = {"run_timestamp_utc": datetime.now(timezone.utc).isoformat(), "model_nickname": name,
                       "model_id": spec["model_id"], **{k: v for k, v in q.items() if k != "question_text"},
                       **response, **graded, "latency_seconds": time.monotonic() - start,
                       "error_type": error_type, "error_message": error_message}
                handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
                handle.flush()
                os.fsync(handle.fileno())
                rows.append(row)
                write_csv(output / "answers.csv", deduplicate(rows))
                print(f"[{i}/{len(pending)}] {q['question_id']}: {row['error_category']}", flush=True)
                if failed:
                    raise RuntimeError(f"Run stopped after backend error: {error_type}: {error_message}. Fix the cause and resume.")
                if delay:
                    time.sleep(delay)
        if rows:
            write_csv(output / "answers.csv", deduplicate(rows))
    finally:
        lock_path.unlink()
