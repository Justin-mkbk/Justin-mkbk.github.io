"""Historical tolerant parser and shared numeric grading (1%, absolute floor 0.02)."""
from __future__ import annotations
import re
from typing import Optional, Union
GroundTruth = Union[float, str]
RELATIVE_TOLERANCE = PRIOR_MATCH_RELATIVE_TOLERANCE = 0.01
ABSOLUTE_TOLERANCE_FLOOR = PRIOR_MATCH_ABSOLUTE_FLOOR = 0.02
NUMBER_PATTERN = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"

FINAL_ANSWER_PATTERN = re.compile(
    rf"FINAL_ANSWER\s*[:\-]?\s*\**\s*(?P<value>ABSTAIN|{NUMBER_PATTERN})",
    re.IGNORECASE)
REASONING_PATTERN = re.compile(r"REASONING\s*[:\-]?\s*(?P<value>.*)",
                               re.IGNORECASE | re.DOTALL)
BOXED_PATTERN = re.compile(r"\\boxed\s*\{\s*(?P<value>[^}]*?)\s*\}")
ANSWER_IS_PATTERN = re.compile(
    rf"(?:the\s+)?(?:final\s+)?answer\s+is\s*:?\s*\**\s*"
    rf"(?P<value>ABSTAIN|{NUMBER_PATTERN})", re.IGNORECASE)
BARE_LINE_PATTERN = re.compile(
    rf"^\s*\**\s*(?P<value>ABSTAIN|{NUMBER_PATTERN})\s*\**\s*\.?\s*$",
    re.IGNORECASE)

THINK_BLOCK_PATTERN = re.compile(r"<think>.*?</think>", re.IGNORECASE | re.DOTALL)
OPEN_THINK_PATTERN = re.compile(r"<think>.*", re.IGNORECASE | re.DOTALL)


def strip_thinking(raw_text: str) -> str:
    """Remove a closed private-reasoning block, and also an unclosed one,
    which means the model ran out of room mid-thought."""
    return OPEN_THINK_PATTERN.sub(" ", THINK_BLOCK_PATTERN.sub(" ", raw_text))


def _as_answer(value: str, reasoning: str, method: str) -> tuple:
    cleaned = value.strip().rstrip(".").replace(",", "")
    if cleaned.upper() == "ABSTAIN":
        return "ABSTAIN", None, True, reasoning, method
    try:
        return cleaned, float(cleaned), False, reasoning, method
    except ValueError:
        return "", None, False, reasoning, "failed"


def parse_model_output(raw_text: str, truncated: bool, profile="local", is_base_model=False) -> tuple:
    """Returns (answer_text, numeric, abstained, reasoning, parse_method)."""
    visible = strip_thinking(raw_text or "").strip()

    # 1. the field we actually asked for
    match = FINAL_ANSWER_PATTERN.search(visible)
    if match:
        reasoning_match = REASONING_PATTERN.search(visible)
        reasoning = reasoning_match.group("value").strip()[:1500] if reasoning_match else ""
        return _as_answer(match.group("value"), reasoning, "strict")

    if not visible:
        return "", None, False, "", "failed"

    # A reply cut off before the answer line has no conclusion in it.
    # Anything still on the page belongs to the middle of the working.
    if truncated:
        return "", None, False, visible[-400:], "failed"

    if is_base_model:
        leading = re.match(rf"^\s*\**\s*(?P<value>ABSTAIN|{NUMBER_PATTERN})", visible, re.IGNORECASE)
        if leading:
            return _as_answer(leading.group("value"), visible[:300], "base_continuation")

    # OpenAI's original parser used only the label and the final two fallbacks.
    # Keep that experiment protocol selectable rather than silently reparsing it.
    if profile == "openai":
        if re.search(r"\bABSTAIN\b", visible, re.IGNORECASE):
            return "ABSTAIN", None, True, visible[:400], "fallback_abstain"
        numbers = re.findall(NUMBER_PATTERN, visible)
        if numbers:
            return numbers[-1], float(numbers[-1]), False, visible[:400], "fallback_last_number"
        return "", None, False, visible[:400], "failed"

    # 2. the last boxed expression - Qwen's habit
    boxed = BOXED_PATTERN.findall(visible)
    if boxed:
        result = _as_answer(boxed[-1], visible[:400], "boxed")
        if result[4] != "failed":
            return result

    # 3. a natural-language statement of the answer
    phrase = list(ANSWER_IS_PATTERN.finditer(visible))
    if phrase:
        result = _as_answer(phrase[-1].group("value"), visible[:400], "answer_is_phrase")
        if result[4] != "failed":
            return result

    # 4. a conservative bare final line
    for line in reversed([l for l in visible.splitlines() if l.strip()]):
        bare = BARE_LINE_PATTERN.match(line)
        if bare:
            result = _as_answer(bare.group("value"), visible[:400], "bare_final_line")
            if result[4] != "failed":
                return result
        break   # only the genuine last line, not a search backwards

    # 5. last resort
    if re.search(r"\bABSTAIN\b", visible, re.IGNORECASE):
        return "ABSTAIN", None, True, visible[:400], "fallback_abstain"

    numbers = re.findall(NUMBER_PATTERN, visible)
    if numbers:
        try:
            return numbers[-1], float(numbers[-1]), False, visible[:400], "fallback_last_number"
        except ValueError:
            pass

    return "", None, False, visible[:400], "failed"



# Grading


def within_tolerance(candidate: float, target: float,
                     relative: float, absolute_floor: float) -> bool:
    return abs(candidate - target) <= max(absolute_floor, relative * abs(target))


def grade_response(expected_answer: GroundTruth,
                   prior_predicted_answer: Optional[float],
                   model_abstained: bool,
                   model_answer_numeric: Optional[float],
                   parse_method: str,
                   truncated: bool) -> tuple:
    if parse_method == "failed":
        if truncated:
            return None, None, False, "ran_out_of_room"
        return None, None, False, "unreadable_reply"

    if expected_answer == "ABSTAIN":
        if model_abstained:
            return None, None, True, "correct_abstention"
        matches_prior = None
        if model_answer_numeric is not None and prior_predicted_answer is not None:
            matches_prior = within_tolerance(
                model_answer_numeric, prior_predicted_answer,
                PRIOR_MATCH_RELATIVE_TOLERANCE, PRIOR_MATCH_ABSOLUTE_FLOOR)
        return None, matches_prior, False, "failure_to_abstain"

    if model_abstained:
        return None, None, False, "false_abstention"
    if model_answer_numeric is None:
        return None, None, False, "missing_numeric_answer"

    target = float(expected_answer)
    absolute_error = abs(model_answer_numeric - target)

    matches_prior = None
    if prior_predicted_answer is not None:
        matches_prior = within_tolerance(
            model_answer_numeric, prior_predicted_answer,
            PRIOR_MATCH_RELATIVE_TOLERANCE, PRIOR_MATCH_ABSOLUTE_FLOOR)

    if within_tolerance(model_answer_numeric, target,
                        RELATIVE_TOLERANCE, ABSOLUTE_TOLERANCE_FLOOR):
        return absolute_error, matches_prior, True, "correct_numeric"
    if matches_prior:
        return absolute_error, matches_prior, False, "wrong_numeric_prior_leak"
    return absolute_error, matches_prior, False, "wrong_numeric"
