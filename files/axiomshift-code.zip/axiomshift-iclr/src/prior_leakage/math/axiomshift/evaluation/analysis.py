"""Score model responses against gold/prior answers and aggregate benchmark metrics.

Input: one or more response CSVs and the matching question CSV. Output:
models.csv, by_world.csv, by_family.csv, README.md, and audit.json, with accuracy,
prior leakage, abstention failures, and incomplete/missing counts.
Example: ``axiomshift analyse --results outputs/my-run/answers.csv
--output outputs/my-run/analysis``. Omitting --results analyses the 26 saved runs.
"""
from __future__ import annotations

import json
import math
from collections import Counter, defaultdict
from pathlib import Path

from ..dataset.io import load_questions, number, read_csv, sha256, truthy, write_csv
from .scoring import grade_response

COMPLETE = {"correct_numeric", "correct_abstention", "wrong_numeric", "wrong_numeric_prior_leak",
            "failure_to_abstain", "false_abstention"}
INCOMPLETE = {"ran_out_of_room", "unreadable_reply", "missing_numeric_answer"}
RUNTIME = {"runtime_error", "request_failed"}


def deduplicate(rows):
    """Prefer the last complete answer, then the last attempt. Key includes world."""
    groups = defaultdict(list)
    for row in rows:
        groups[(row.get("question_set", ""), row["question_id"])].append(row)
    return [(next((r for r in reversed(rs) if r.get("error_category") in COMPLETE), rs[-1]))
            for rs in groups.values()]


def percent(n, d):
    return 100 * n / d if d else None


def wilson(n, d):
    if not d:
        return None, None
    z = 1.96
    p = n / d
    denominator = 1 + z * z / d
    mid = (p + z * z / (2 * d)) / denominator
    half = z * math.sqrt(p * (1 - p) / d + z * z / (4 * d * d)) / denominator
    return 100 * (mid - half), 100 * (mid + half)


def summarize(rows, questions, basis="complete"):
    completed = [r for r in rows if r["error_category"] in COMPLETE]
    selected = completed if basis == "complete" else [r for r in rows if r["error_category"] in COMPLETE | INCOMPLETE]
    n = len(selected)
    correct = sum(truthy(r["is_correct"]) for r in selected)
    answerable = [r for r in selected if questions[r["question_id"]]["abstain_type"] == "none"]
    unanswerable = [r for r in selected if questions[r["question_id"]]["abstain_type"] != "none"]
    distinguishing = [r for r in selected if truthy(questions[r["question_id"]]["prior_distinguishes"])]
    committed = [r for r in distinguishing if not truthy(r.get("model_abstained"))
                 and number(r.get("model_answer_numeric")) is not None]
    leaked = [r for r in committed if truthy(r.get("matches_prior_prediction")) and not truthy(r["is_correct"])]
    errors = [r for r in completed if not truthy(r["is_correct"])]
    modes = Counter()
    for row in errors:
        q = questions[row["question_id"]]
        if truthy(q["prior_distinguishes"]) and truthy(row.get("matches_prior_prediction")):
            modes["C_prior_leakage"] += 1
        elif truthy(row.get("model_abstained")):
            modes["D_false_abstention"] += 1
        elif q["abstain_type"] == "none":
            modes["A_wrong_number"] += 1
        else:
            modes["B_failure_to_abstain"] += 1
    low, high = wilson(correct, n)
    result = {"basis": basis, "n_attempted": len(rows), "n_complete": len(completed), "n_denominator": n,
        "n_correct": correct, "accuracy_pct": percent(correct, n), "accuracy_ci_low": low, "accuracy_ci_high": high,
        "n_excluded": len(rows) - n, "n_runtime_error": sum(r["error_category"] in RUNTIME for r in rows),
        "n_truncated": sum(r["error_category"] == "ran_out_of_room" for r in rows),
        "n_unreadable": sum(r["error_category"] in {"unreadable_reply", "missing_numeric_answer"} for r in rows),
        "n_answerable": len(answerable), "n_unanswerable": len(unanswerable),
        "n_prior_distinguishing": len(distinguishing), "n_committed_prior": len(committed), "n_leaked": len(leaked),
        "leak_pct_seen_prior": percent(len(leaked), len(distinguishing)),
        "leak_pct_committed_prior": percent(len(leaked), len(committed)),
        "failure_to_abstain_pct": percent(sum(r["error_category"] == "failure_to_abstain" for r in unanswerable), len(unanswerable)),
        "false_abstention_pct": percent(sum(r["error_category"] == "false_abstention" for r in answerable), len(answerable))}
    for key in ("A_wrong_number", "B_failure_to_abstain", "C_prior_leakage", "D_false_abstention"):
        result[key] = modes[key]
        result[key + "_pct_complete"] = percent(modes[key], len(completed))
        result[key + "_pct_errors"] = percent(modes[key], len(errors))
    return result


def audit_rows(rows, questions):
    mismatches = []
    for row in rows:
        qid = row.get("question_id")
        if qid not in questions:
            raise ValueError(f"Results contain unknown question_id: {qid}")
        q = questions[qid]
        for field in ("question_set", "abstain_type", "question_family"):
            if row.get(field) and row[field] != q[field]:
                raise ValueError(f"{qid}: result {field} disagrees with dataset")
        for field in ("expected_answer", "prior_predicted_answer"):
            stored, expected = row.get(field, ""), q[field]
            if stored == expected:
                continue
            if str(stored).upper() == "ABSTAIN" or expected == "ABSTAIN" or number(stored) != number(expected):
                raise ValueError(f"{qid}: result {field} disagrees with dataset")
        category = row.get("error_category")
        if category not in COMPLETE | INCOMPLETE | RUNTIME:
            raise ValueError(f"{qid}: unknown outcome {category!r}")
        if category in COMPLETE:
            answer = q["expected_answer"] if q["expected_answer"] == "ABSTAIN" else number(q["expected_answer"])
            graded = grade_response(answer, number(q["prior_predicted_answer"]), truthy(row.get("model_abstained")),
                                    number(row.get("model_answer_numeric")), row.get("parse_method", "stored"), False)
            if (truthy(row.get("is_correct")), category) != (graded[2], graded[3]):
                mismatches.append({"question_id": qid, "stored_category": category, "regraded_category": graded[3]})
    return mismatches


def analyse(paths, dataset, output, basis="complete"):
    questions = {q["question_id"]: q for q in load_questions(dataset)}
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    summary, by_world, by_family, audit = [], [], [], []
    seen_models = set()
    for path in paths:
        raw = read_csv(path)
        if not raw or not {"question_id", "error_category", "is_correct"} <= raw[0].keys():
            raise ValueError(f"Not a results CSV: {path}")
        models = {r.get("model_nickname", "") for r in raw} - {""}
        if len(models) > 1:
            raise ValueError(f"Multiple models in {path}; split into one file per model")
        model = next(iter(models), Path(path).stem)
        if model in seen_models:
            raise ValueError(f"Multiple result files for {model}; merge them explicitly first")
        seen_models.add(model)
        rows = deduplicate(raw)
        discrepancies = audit_rows(rows, questions)
        stats = summarize(rows, questions, basis)
        summary.append({"model": model, "n_expected": len(questions), "n_missing": len(questions) - len(rows), **stats})
        for field, target in [("question_set", by_world), ("question_family", by_family)]:
            for group in sorted({q[field] for q in questions.values()}):
                subset = [r for r in rows if questions[r["question_id"]][field] == group]
                target.append({"model": model, field: group, **summarize(subset, questions, basis)})
        audit.append({"file": Path(path).name, "sha256": sha256(path), "model": model,
                      "duplicate_attempts": len(raw) - len(rows), "grading_discrepancies": discrepancies})
    summary.sort(key=lambda r: (r["accuracy_pct"] is not None, r["accuracy_pct"] or 0), reverse=True)
    write_csv(output / "models.csv", summary)
    write_csv(output / "by_world.csv", by_world)
    write_csv(output / "by_family.csv", by_family)
    (output / "audit.json").write_text(json.dumps({"dataset_sha256": sha256(dataset), "basis": basis, "files": audit}, indent=2) + "\n", encoding="utf-8")
    lines = ["# AxiomShift results", "", f"Basis: **{basis}**. Rates use each model's observed denominator.", "",
             "| Model | Complete | Accuracy (%) | Leak / committed prior (%) | Leak / seen prior (%) | Failure to abstain (%) |", "|---|---:|---:|---:|---:|---:|"]
    def fmt(value):
        return "—" if value is None else f"{value:.1f}"
    for r in summary:
        lines.append(f"| {r['model']} | {r['n_complete']} | {fmt(r['accuracy_pct'])} | {fmt(r['leak_pct_committed_prior'])} | {fmt(r['leak_pct_seen_prior'])} | {fmt(r['failure_to_abstain_pct'])} |")
    (output / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return summary
