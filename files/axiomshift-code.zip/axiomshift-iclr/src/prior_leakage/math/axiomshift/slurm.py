"""Prepare an explicit-resource Slurm job for the shared model evaluator.

Example on the cluster, from the checkout root (preparation only)::

    axiomshift-slurm --work-dir /scratch/YOUR_USER/prior-leakage \
        --python /scratch/YOUR_USER/conda_envs/qwen35_eval/bin/python \
        --model-path /scratch/YOUR_USER/huggingface_qwen25_32b/Qwen2.5-32B-Instruct \
        --limit 5 --output outputs/slurm-smoke

Inspect evaluate.slurm and job.json, then run sbatch on the generated script.
Use --limit 700 for a full run. Preparation does not submit; only --submit
invokes sbatch. See scripts/math/slurm/README.md for setup and environment export.
"""
from __future__ import annotations
import argparse
import getpass
import json
import re
import shlex
import subprocess
from pathlib import Path, PurePosixPath

PROFILE = {'partition':'h200', 'node':None, 'gres':'gpu:h200:1', 'cpus':16,
           'memory':'80G', 'time':'04:00:00', 'gpu_memory':'132GiB', 'cpu_memory':'64GiB',
           'max_output_tokens':4096}


def prepare(args):
    """Write a reviewable job script and settings; do not execute inference."""
    for key in ('partition','node','gres','memory','time','gpu_memory','cpu_memory'):
        if key == 'node' and args.node is None:
            continue
        if not re.fullmatch(r'[A-Za-z0-9_:.,+-]+',str(getattr(args,key))):
            raise ValueError(f'Invalid Slurm setting: {key}')
    if args.cpus < 1 or args.max_output_tokens < 1 or args.limit < 1:
        raise ValueError('CPU, question, and output-token counts must be positive')
    for key in ('model_path','python','work_dir'):
        value=getattr(args,key)
        if not PurePosixPath(value).is_absolute() or '\n' in value or '\r' in value:
            raise ValueError(f'{key} must be an absolute path on the Linux compute node')
    output=Path(args.output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError('Choose a new job directory; old scripts and results are not overwritten')
    output.mkdir(parents=True,exist_ok=True)
    # Use the explicitly provided compute-node work directory, not this machine's path.
    run_dir=str(PurePosixPath(args.work_dir)/'outputs'/args.name)
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',args.name):
        raise ValueError('Run name must use letters, numbers, hyphens, or underscores')
    command=[args.python,'-u','-m','prior_leakage.math.axiomshift','run','--model',args.model,
             '--backend','hf','--model-path',args.model_path,'--dtype','bfloat16',
             '--gpu-memory',args.gpu_memory,'--cpu-memory',args.cpu_memory,
             '--max-input-tokens','16384','--max-output-tokens',str(args.max_output_tokens),
             '--temperature','0','--limit',str(args.limit),'--output',run_dir]
    if args.resume:command.append('--resume')
    if args.revision:command+=['--revision',args.revision]
    preflight="import torch; assert torch.cuda.is_available(), 'CUDA unavailable'; print(torch.cuda.get_device_name(0))"
    lines=['#!/bin/bash',f'#SBATCH --partition={args.partition}',
           *([f'#SBATCH --nodelist={args.node}'] if args.node else []),
           '#SBATCH --nodes=1','#SBATCH --ntasks=1',f'#SBATCH --cpus-per-task={args.cpus}',
           f'#SBATCH --gres={args.gres}',f'#SBATCH --mem={args.memory}',f'#SBATCH --time={args.time}',
           f'#SBATCH --job-name=math-{args.name}', '#SBATCH --output=slurm-%x-%j.out',
           '#SBATCH --error=slurm-%x-%j.err','set -euo pipefail',
           'export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 TOKENIZERS_PARALLELISM=false PYTHONUNBUFFERED=1',
           f'export OMP_NUM_THREADS={args.cpus} MKL_NUM_THREADS={args.cpus}',
           'unset MASTER_ADDR MASTER_PORT RANK LOCAL_RANK WORLD_SIZE',
           'cd '+shlex.quote(args.work_dir),
           'test -x '+shlex.quote(args.python), 'test -f '+shlex.quote(str(PurePosixPath(args.model_path)/'config.json')),
           'hostname', 'nvidia-smi',
           shlex.join([args.python,'-m','prior_leakage.math.axiomshift','validate','--canonical']),
           shlex.join(['srun','--ntasks=1',args.python,'-c',preflight]),
           shlex.join(['srun','--ntasks=1',*command]),
           shlex.join([args.python,'-m','prior_leakage.math.axiomshift','analyse','--results',
                       str(PurePosixPath(run_dir)/'answers.csv'),'--output',str(PurePosixPath(run_dir)/'analysis')])]
    script=output/'evaluate.slurm'
    script.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
    settings={k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()}
    settings.update(command=command,validation='prepared; cluster execution not verified',
                    memory_note='64GiB CPU offload ceiling within the 80G host allocation.')
    (output/'job.json').write_text(json.dumps(settings,indent=2)+'\n',encoding='utf-8')
    return script


def main(argv=None):
    user=getpass.getuser()
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model',default='qwen2.5-32b-instruct')
    parser.add_argument('--model-path',default=f'/scratch/{user}/huggingface_qwen25_32b/Qwen2.5-32B-Instruct')
    parser.add_argument('--python',default=f'/scratch/{user}/conda_envs/qwen35_eval/bin/python')
    parser.add_argument('--work-dir',default=f'/scratch/{user}/prior-leakage')
    parser.add_argument('--name',default='qwen32b-smoke')
    parser.add_argument('--output',type=Path,default=Path('outputs/slurm-smoke-job'))
    parser.add_argument('--limit',type=int,default=5)
    parser.add_argument('--revision')
    parser.add_argument('--resume',action='store_true')
    parser.add_argument('--submit',action='store_true',help='Explicitly submit the prepared script with sbatch')
    for key,value in PROFILE.items():
        parser.add_argument('--'+key.replace('_','-'),default=value,type=int if isinstance(value,int) else str)
    args=parser.parse_args(argv)
    try:
        script=prepare(args)
        print(f'Prepared {script}; inspect it and job.json before submission.')
        print('Submit on the cluster: '+shlex.join(['sbatch',str(script)]))
        if args.submit:
            subprocess.run(['sbatch',str(script)],check=True,cwd=script.parent)
    except (ValueError,OSError,subprocess.CalledProcessError) as error:
        parser.exit(1,f'Error: {error}\n')


if __name__=='__main__':main()
