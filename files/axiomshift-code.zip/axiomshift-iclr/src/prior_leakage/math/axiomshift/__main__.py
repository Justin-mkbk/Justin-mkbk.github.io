"""Dispatch dataset generation, model evaluation, result analysis, and the local GUI.

Install from the repository root, then run ``axiomshift --help`` or
``python -m prior_leakage.math.axiomshift --help`` from any working directory.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import Counter
from pathlib import Path

from .evaluation.analysis import analyse
from .dataset.io import DEFAULT_DATA, FIELDS, ROOT, load_questions, select_questions, sha256, write_csv


def selection(parser):
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--world", action="append", default=[], help="World name; repeat to combine worlds")
    parser.add_argument("--family", action="append", default=[])
    parser.add_argument("--limit", type=int)
    parser.add_argument("--seed", type=int, help="Optional deterministic shuffle before limiting")


def main(argv=None):
    parser = argparse.ArgumentParser(description="AxiomShift: reproduce or extend the seven-world benchmark")
    sub = parser.add_subparsers(dest="command", required=True)
    generation = sub.add_parser("generate", help="Generate the canonical 700 questions or a balanced seeded variant")
    generation.add_argument("--output", type=Path, default=Path("outputs/regenerated"))
    generation.add_argument("--allow-differences", action="store_true", help="For intentional generator edits; still writes a difference report")
    generation.add_argument("--seed", type=int, help="Generate a new 700-question variant; omit to reconstruct the published CSV exactly")
    gui = sub.add_parser("gui", help="Open the local browser interface for LM Studio and offline reproduction")
    gui.add_argument("--port", type=int, default=8765)
    gui.add_argument("--no-browser", action="store_true")
    figures=sub.add_parser("paper-assets",help="Reproduce original paper figures and statistical tables")
    figures.add_argument("--output",type=Path,default=Path("outputs/paper-assets"))
    submission=sub.add_parser("stage-paper",help="Assemble the separate MATH-AI or AISciK submission for LaTeX")
    submission.add_argument("submission",choices=['mathai','aiscik'])
    submission.add_argument("--output",type=Path,required=True)
    validate = sub.add_parser("validate", help="Validate dataset schema and optionally release checksums")
    validate.add_argument("--data", type=Path, default=DEFAULT_DATA)
    validate.add_argument("--canonical", action="store_true")
    models = sub.add_parser("models", help="List model presets")
    models.add_argument("--config", type=Path, default=ROOT / "configs/models.json")
    export = sub.add_parser("export", help="Create an editable subset or reshuffle of the curated questions")
    selection(export)
    export.add_argument("--output", type=Path, required=True)
    run_parser = sub.add_parser("run", help="Run any configured model through the same evaluation pipeline")
    selection(run_parser)
    run_parser.add_argument("--model", required=True, help="Preset name, or any model ID with --backend")
    run_parser.add_argument("--config", type=Path, default=ROOT / "configs/models.json")
    run_parser.add_argument("--prompts", type=Path, default=ROOT / "configs/prompts.json")
    run_parser.add_argument("--backend", choices=["api", "hf"])
    run_parser.add_argument("--model-id")
    run_parser.add_argument("--model-path")
    run_parser.add_argument("--revision", help="HF model revision/commit")
    run_parser.add_argument("--dtype", choices=["auto", "float32", "float16", "bfloat16"])
    run_parser.add_argument("--device-map", choices=["auto", "balanced", "balanced_low_0", "sequential", "cpu"])
    run_parser.add_argument("--gpu-memory", help="Per-GPU memory ceiling, e.g. 40GiB")
    run_parser.add_argument("--cpu-memory", help="CPU offload memory ceiling, e.g. 64GiB")
    run_parser.add_argument("--max-input-tokens", type=int)
    run_parser.add_argument("--base-url")
    run_parser.add_argument("--api-key-env", help="Environment variable for a custom API endpoint's credential")
    run_parser.add_argument("--api-style", choices=["chat", "completion", "responses_plain", "responses_reasoning"])
    run_parser.add_argument("--max-output-tokens", type=int)
    run_parser.add_argument("--temperature", type=float)
    run_parser.add_argument("--reasoning-effort")
    run_parser.add_argument("--base-model", action="store_true")
    run_parser.add_argument("--parser", choices=["openai", "local"])
    run_parser.add_argument("--prompt", choices=["openai", "local"])
    run_parser.add_argument("--trust-remote-code", action="store_true")
    run_parser.add_argument("--output", type=Path, required=True)
    run_parser.add_argument("--resume", action="store_true")
    run_parser.add_argument("--dry-run", action="store_true", help="Print resolved settings without requests or model loading")
    run_parser.add_argument("--timeout", type=float, default=900)
    run_parser.add_argument("--retries", type=int, default=3)
    run_parser.add_argument("--delay", type=float, default=0.0)
    analysis = sub.add_parser("analyse", help="Reproduce tables offline from saved result CSVs")
    analysis.add_argument("--data", type=Path, default=DEFAULT_DATA)
    analysis.add_argument("--results", type=Path, default=ROOT / "results/reference", help="CSV file or directory of per-model CSVs")
    analysis.add_argument("--output", type=Path, default=Path("outputs/analysis"))
    analysis.add_argument("--basis", choices=["complete", "attempted"], default="complete")
    args = parser.parse_args(argv)
    try:
        if args.command == "generate":
            from .dataset.generation import generate
            generate(args.output, verify=not args.allow_differences, seed=args.seed)
        elif args.command == "gui":
            from .gui import serve
            serve(args.port, open_browser=not args.no_browser)
        elif args.command == "paper-assets":
            from ..analysis.figures import paper_assets
            paper_assets(args.output)
        elif args.command == "stage-paper":
            from ..analysis.figures import stage_submission
            stage_submission(args.submission,args.output)
        elif args.command == "validate":
            questions = load_questions(args.data, canonical=args.canonical)
            print(json.dumps({"rows": len(questions), "worlds": dict(Counter(q["question_set"] for q in questions)),
                              "sha256": sha256(args.data)}, indent=2))
        elif args.command == "models":
            for name, spec in json.loads(args.config.read_text(encoding="utf-8")).items():
                print(f"{name:35} {spec['backend']:4} {spec['model_id']}")
        elif args.command == "export":
            if args.output.exists():
                raise ValueError("Output exists; choose a new path for the variant")
            rows = select_questions(load_questions(args.data), args.world, args.family, args.limit, args.seed)
            write_csv(args.output, rows, FIELDS)
            print(f"Exported {len(rows)} questions to {args.output}")
        elif args.command == "analyse":
            paths = sorted(args.results.glob("*.csv")) if args.results.is_dir() else [args.results]
            if not paths:
                raise ValueError("No result CSVs found")
            rows = analyse(paths, args.data, args.output, args.basis)
            print(f"Analysed {len(rows)} models; report: {args.output / 'README.md'}")
        else:
            from .models.runner import run
            models = json.loads(args.config.read_text(encoding="utf-8"))
            if args.model not in models and not args.backend:
                raise ValueError("Unknown preset; use models to list presets, or pass --backend for a new model")
            spec = dict(models.get(args.model, {"model_id": args.model, "backend": args.backend,
                "api_style": "chat", "base_url": "http://localhost:1234/v1", "max_output_tokens": 800,
                "temperature": 0.0, "parser": "local", "prompt": "local"}))
            for field in ("backend", "model_id", "model_path", "revision", "base_url", "api_key_env", "api_style",
                          "max_output_tokens", "temperature", "reasoning_effort", "parser", "prompt",
                          "dtype", "device_map", "gpu_memory", "cpu_memory", "max_input_tokens"):
                if getattr(args, field) is not None:
                    spec[field] = getattr(args, field)
            if args.base_model:
                spec["is_base_model"] = True
                if spec["backend"] == "api":
                    spec["api_style"] = "completion"
            if args.trust_remote_code:
                spec["trust_remote_code"] = True
            if spec["max_output_tokens"] <= 0 or args.retries <= 0 or args.timeout <= 0 or args.delay < 0:
                raise ValueError("Token limit, retries, and timeout must be positive; delay must be nonnegative")
            prompts = json.loads(args.prompts.read_text(encoding="utf-8"))
            questions = select_questions(load_questions(args.data), args.world, args.family, args.limit, args.seed)
            run(args.model, spec, questions, args.data, args.output, prompts, resume=args.resume,
                dry_run=args.dry_run, timeout=args.timeout, retries=args.retries, delay=args.delay)
    except (ValueError, RuntimeError, OSError, KeyError) as error:
        parser.exit(1, f"Error: {error}\n")


if __name__ == "__main__":
    main()
