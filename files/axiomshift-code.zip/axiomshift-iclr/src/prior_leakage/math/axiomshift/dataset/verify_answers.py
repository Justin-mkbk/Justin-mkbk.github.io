"""Independently verify polygon/market gold answers from rendered prompts.

Called by dataset generation before assembly. This second implementation reads
question_text, not parameter_summary or generator calculators. Raises ValueError
if any derived answer disagrees with the stored value.
"""
from __future__ import annotations

import math
import re


problems: list = []


def fail(question_id: str, message: str) -> None:
    problems.append(f"{question_id}: {message}")



# PARSING THE PROMPT


NUM = r"(-?\d+\.\d{2})"

def market_coefficients(text: str) -> tuple:
    demand = re.search(rf"Qd = {NUM} \+ {NUM} x P", text)
    supply = re.search(rf"Qs = {NUM} \+ {NUM} x P", text)
    if not demand or not supply:
        return None
    return (float(demand.group(1)), float(demand.group(2)),
            float(supply.group(1)), float(supply.group(2)))


def polygon_lengths(text: str) -> dict:
    out = {}
    for key, label in [("ab", "AB"), ("bc", "BC"), ("cd", "CD"), ("da", "DA")]:
        m = re.search(rf"\b{label} = {NUM}", text)
        if m:
            out[key] = float(m.group(1))
    for key, label in [("ac", "AC"), ("bd", "BD")]:
        m = re.search(rf"the diagonal {label} = {NUM}", text)
        if m:
            out[key] = float(m.group(1))
    return out



# GEOMETRY, WRITTEN OUT AGAIN FROM THE DEFINITIONS


def heron(a, b, c):
    if a + b <= c or a + c <= b or b + c <= a:
        return None
    s = (a + b + c) / 2.0
    v = s * (s - a) * (s - b) * (s - c)
    return math.sqrt(v) if v > 0 else None


def _clamp(x):
    return max(-1.0, min(1.0, x))


def sphere_triangle(a, b, c, R):
    if max(a, b, c) >= math.pi * R:
        return None
    def ang(o, f, s):
        den = math.sin(f / R) * math.sin(s / R)
        if abs(den) < 1e-12:
            return None
        return math.acos(_clamp((math.cos(o / R) - math.cos(f / R) * math.cos(s / R)) / den))
    A = [ang(a, b, c), ang(b, a, c), ang(c, a, b)]
    if any(x is None for x in A):
        return None
    e = sum(A) - math.pi
    return e * R * R if e > 1e-9 else None


def hyper_triangle(a, b, c, R):
    def ang(o, f, s):
        den = math.sinh(f / R) * math.sinh(s / R)
        if abs(den) < 1e-12:
            return None
        return math.acos(_clamp((math.cosh(f / R) * math.cosh(s / R)
                                 - math.cosh(o / R)) / den))
    A = [ang(a, b, c), ang(b, a, c), ang(c, a, b)]
    if any(x is None for x in A):
        return None
    d = math.pi - sum(A)
    return d * R * R if d > 1e-9 else None


def triangle_at(a, b, c, K):
    if abs(K) < 1e-9:
        return heron(a, b, c)
    R = 1.0 / math.sqrt(abs(K))
    return sphere_triangle(a, b, c, R) if K > 0 else hyper_triangle(a, b, c, R)


def quad_at(L, K):
    """Split along AC. At a fixed curvature each triangle is fixed by SSS."""
    t1 = triangle_at(L["ab"], L["bc"], L["ac"], K)
    t2 = triangle_at(L["ac"], L["cd"], L["da"], K)
    return None if (t1 is None or t2 is None) else t1 + t2


def stated_curvature(text: str):
    """K if the sheet gives one, otherwise None."""
    m = re.search(r"K = (-?\d+\.\d+)", text)
    if m:
        return float(m.group(1))
    m = re.search(r"curvature K of (-?\d+\.\d+)", text)
    return float(m.group(1)) if m else None


def close(x, y, rel=0.01, floor=0.02):
    return abs(x - y) <= max(floor, rel * abs(y))



# CHECKS PER FAMILY


def check_clearing_price(row):
    a, b, c, d = market_coefficients(row["question_text"])
    if b == d:
        return fail(row["question_id"], "slopes are equal, no clearing price")
    mine = round((c - a) / (b - d), 2)
    if not close(mine, float(row["expected_answer"])):
        fail(row["question_id"], f"I get {mine}, file says {row['expected_answer']}")
    prior = float(row["prior_predicted_answer"])
    mine_prior = round((c - a) / (-b - d), 2)
    if not close(mine_prior, prior):
        fail(row["question_id"], f"prior: I get {mine_prior}, file says {prior}")
    if prior < 0.30:
        fail(row["question_id"], f"prior clearing price {prior} is too small to be written down")


def check_clearing_quantity(row):
    a, b, c, d = market_coefficients(row["question_text"])
    price = (c - a) / (b - d)
    mine = round(a + b * price, 2)
    if not close(mine, float(row["expected_answer"])):
        fail(row["question_id"], f"I get {mine}, file says {row['expected_answer']}")


def check_price_rise(row):
    a, b, c, d = market_coefficients(row["question_text"])
    prices = re.search(r"from (-?\d+\.\d{2}) pounds a kilogram to (-?\d+\.\d{2}) pounds",
                       row["question_text"])
    p1, p2 = float(prices.group(1)), float(prices.group(2))
    mine = round(b * (p2 - p1), 2)
    if not close(mine, float(row["expected_answer"])):
        fail(row["question_id"], f"I get {mine}, file says {row['expected_answer']}")


def check_revenue(row):
    a, b, c, d = market_coefficients(row["question_text"])
    m = re.search(r"set the price at (\d+\.\d{2}) pounds a kilogram", row["question_text"])
    price = float(m.group(1))

    wanted = a + b * price
    brought = c + d * price

    # Sales cannot exceed the quantity supplied.
    if brought < wanted:
        fail(row["question_id"],
             f"IMPOSSIBLE SALE: shoppers want {wanted:.4f} kg but only "
             f"{brought:.4f} kg was brought")
        return
    if brought - wanted < 0.25:
        fail(row["question_id"], f"surplus only {brought - wanted:.4f} kg, too tight")

    clearing = (c - a) / (b - d)
    if abs(price - clearing) < 0.35:
        fail(row["question_id"],
             f"price {price} sits {abs(price - clearing):.3f} from clearing {clearing:.3f}")

    mine = round(price * wanted, 2)
    if not close(mine, float(row["expected_answer"])):
        fail(row["question_id"], f"I get {mine}, file says {row['expected_answer']}")

    # The prior has to be a sum of money a leaking model would be
    # willing to write, not a rounding artefact worth a few pence.
    prior_quantity = a - b * price
    if prior_quantity < 3.00:
        fail(row["question_id"],
             f"the flipped demand curve leaves only {prior_quantity:.2f} kg, "
             f"so the leaked takings of {float(row['prior_predicted_answer']):.2f} "
             f"would not be written down")
    if not close(round(price * prior_quantity, 2), float(row["prior_predicted_answer"])):
        fail(row["question_id"], "prior takings do not match the flipped demand curve")


def check_market_abstains(row):
    a, b, c, d = market_coefficients(row["question_text"]) or (None,) * 4
    family = row["question_family"]
    if family == "market_every_price_clears":
        if not (a == c and b == d):
            fail(row["question_id"], "formulas are not identical, so not every price clears")
    elif family == "market_inconsistent" and a is not None:
        quoted = re.search(r"cleared at (\d+\.\d{2}) pounds", row["question_text"])
        if b == d:
            if a == c:
                fail(row["question_id"], "identical formulas: this is non-unique, not inconsistent")
            prior = float(row["prior_predicted_answer"])
            if prior < 0.30:
                fail(row["question_id"], f"prior price {prior} is not a figure anyone would write")
        elif quoted:
            true_price = (c - a) / (b - d)
            if abs(float(quoted.group(1)) - true_price) < 1.20:
                fail(row["question_id"], "quoted price is too close to the true one to be a conflict")
        else:
            fail(row["question_id"], "nothing here makes it inconsistent")
    elif family == "market_missing_coefficient":
        if "smudged" not in row["question_text"]:
            fail(row["question_id"], "nothing is actually missing")


def check_polygon_answerable(row):
    L = polygon_lengths(row["question_text"])
    if len(L) != 6:
        return fail(row["question_id"], f"expected 6 lengths, found {sorted(L)}")
    world = row["question_family"].replace("polygon_", "")
    if world == "euclidean":
        K = 0.0
    else:
        m = re.search(r"radius of curvature R = (\d+\.\d+)", row["question_text"])
        if not m:
            m = re.search(r"radius of curvature.*?(\d+\.\d+)", row["question_text"])
        if not m:
            return fail(row["question_id"], "cannot find the radius in the text")
        R = float(m.group(1))
        K = (1.0 if world == "spherical" else -1.0) / (R * R)

    # Route one: split along AC. Route two: split along BD.
    r1 = quad_at(L, K)
    t3 = triangle_at(L["ab"], L["da"], L["bd"], K)
    t4 = triangle_at(L["bc"], L["cd"], L["bd"], K)
    r2 = None if (t3 is None or t4 is None) else t3 + t4
    if r1 is None or r2 is None:
        return fail(row["question_id"], "the plot does not close at the stated curvature")
    if abs(r1 - r2) > 0.02:
        return fail(row["question_id"], f"routes disagree: {r1:.4f} vs {r2:.4f}")
    mine = round(0.5 * (r1 + r2), 2)
    if not close(mine, float(row["expected_answer"]), rel=0.02, floor=0.03):
        fail(row["question_id"], f"I get {mine}, file says {row['expected_answer']}")


def check_polygon_curvature_withheld(row):
    text = row["question_text"]
    L = polygon_lengths(text)

    if "bd" in L:
        return fail(row["question_id"], "the second diagonal is still on the sheet")
    if set(L) != {"ab", "bc", "cd", "da", "ac"}:
        return fail(row["question_id"], f"expected 4 sides and 1 diagonal, found {sorted(L)}")
    if stated_curvature(text) is not None:
        return fail(row["question_id"], "a curvature is stated after all")

    # Five distances, five shape degrees of freedom and one unknown
    # curvature. So sweep the curvature: every value at which both
    # triangles close is a possible world, and each gives its own area.
    found = []
    K = -4.0
    while K <= 4.0001:
        area = quad_at(L, K)
        if area is not None:
            found.append((K, area))
        K += 0.05
    if len(found) < 40:
        return fail(row["question_id"],
                    f"only {len(found)} curvatures admit a plot; may be near-determined")
    areas = [a for _, a in found]
    spread = max(areas) - min(areas)
    if spread < 0.15:
        return fail(row["question_id"], f"area barely moves with curvature (spread {spread:.4f})")

    flat = quad_at(L, 0.0)
    if flat is None:
        return fail(row["question_id"], "flat ground does not close, so there is no prior to leak")
    if not close(round(flat, 2), float(row["prior_predicted_answer"])):
        fail(row["question_id"],
             f"prior: flat area is {flat:.4f}, file says {row['prior_predicted_answer']}")
    return None


def check_polygon_sides_only(row):
    L = polygon_lengths(row["question_text"])
    if set(L) != {"ab", "bc", "cd", "da"}:
        fail(row["question_id"], f"expected 4 sides only, found {sorted(L)}")


def check_polygon_routes_disagree(row):
    L = polygon_lengths(row["question_text"])
    if len(L) != 6:
        fail(row["question_id"], f"expected 6 lengths, found {sorted(L)}")



# MAIN


CHECKS = {
    "clearing_price": check_clearing_price,
    "clearing_quantity": check_clearing_quantity,
    "price_rise_effect": check_price_rise,
    "revenue_at_price": check_revenue,
    "market_inconsistent": check_market_abstains,
    "market_every_price_clears": check_market_abstains,
    "market_missing_coefficient": check_market_abstains,
    "polygon_euclidean": check_polygon_answerable,
    "polygon_spherical": check_polygon_answerable,
    "polygon_hyperbolic": check_polygon_answerable,
    "polygon_curvature_withheld": check_polygon_curvature_withheld,
    "polygon_sides_only": check_polygon_sides_only,
    "polygon_routes_disagree": check_polygon_routes_disagree,
}


def verify_answers(rows):
    problems.clear()
    counts: dict = {}
    for row in rows:
        family = row["question_family"]
        counts[family] = counts.get(family, 0) + 1
        check = CHECKS.get(family)
        if check is None:
            fail(row["question_id"], f"no check written for family {family}")
            continue
        try:
            check(row)
        except Exception as error:
            fail(row["question_id"], f"check blew up: {error!r}")

    # Every question must offer the abstain option and none may be blank.
    for row in rows:
        if "ABSTAIN" not in row["question_text"]:
            fail(row["question_id"], "does not offer ABSTAIN")
        if row["expected_answer"].strip() == "":
            fail(row["question_id"], "no ground truth stored")

    # No prior may coincide with its own true answer.
    for row in rows:
        prior = row["prior_predicted_answer"].strip()
        if prior and row["expected_answer"].upper() != "ABSTAIN":
            if close(float(prior), float(row["expected_answer"])):
                fail(row["question_id"], "prior equals the true answer")

    if problems:
        raise ValueError("Prompt/answer verification failed: " + "; ".join(problems[:40]))
