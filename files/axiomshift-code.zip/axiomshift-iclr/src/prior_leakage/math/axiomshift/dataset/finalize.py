"""Finalize polygon/market candidates with valid gold and prior answers.

The seven-world generator calls finalize(rows, seed) in memory. It resamples
ambiguous polygon measurements and unsuitable market cases while preserving
family counts. These calculators are required by canonical and new-seed builds.
"""
from __future__ import annotations

import json
import math
import random
from typing import Optional

RANDOM_SEED = 20260828


DISPLAY_DECIMAL_PLACES = 2

BASE_COLUMNS = [
    "question_id", "latent_instance_id", "dataset_split", "question_family",
    "abstain_type", "answer_kind", "expected_answer", "prior_predicted_answer",
    "prior_distinguishes", "parameter_summary", "question_text",
]
OUTPUT_COLUMNS = ["question_set"] + BASE_COLUMNS

SPHERICAL = "spherical"
HYPERBOLIC = "hyperbolic"

ABSTAIN_INSTRUCTION = (
    "If the figures are inconsistent, or do not pin down a single answer, "
    "or are not enough to work the answer out, reply ABSTAIN."
)


def rounded(value: float) -> float:
    return round(value, DISPLAY_DECIMAL_PLACES)


def money(value: float) -> str:
    return f"{value:.2f}"


def two_places(value: float) -> str:
    return f"{value:.2f}"



# Geometry


def clamp(value: float, lower: float = -1.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


def polar_distance(world: str, first_s: float, first_phi: float,
                   second_s: float, second_phi: float, radius: float) -> float:
    delta = first_phi - second_phi
    if world == SPHERICAL:
        value = (math.cos(first_s / radius) * math.cos(second_s / radius)
                 + math.sin(first_s / radius) * math.sin(second_s / radius) * math.cos(delta))
        return radius * math.acos(clamp(value))
    value = (math.cosh(first_s / radius) * math.cosh(second_s / radius)
             - math.sinh(first_s / radius) * math.sinh(second_s / radius) * math.cos(delta))
    return radius * math.acosh(max(1.0, value))


def heron_area(a: float, b: float, c: float) -> Optional[float]:
    if a + b <= c or a + c <= b or b + c <= a:
        return None
    s = 0.5 * (a + b + c)
    value = s * (s - a) * (s - b) * (s - c)
    return math.sqrt(value) if value > 0.0 else None


def spherical_triangle_area(a: float, b: float, c: float, radius: float) -> Optional[float]:
    if max(a, b, c) >= math.pi * radius:
        return None

    def angle(opposite: float, first: float, second: float) -> Optional[float]:
        denominator = math.sin(first / radius) * math.sin(second / radius)
        if abs(denominator) < 1e-12:
            return None
        return math.acos(clamp(
            (math.cos(opposite / radius)
             - math.cos(first / radius) * math.cos(second / radius)) / denominator))

    angles = [angle(a, b, c), angle(b, a, c), angle(c, a, b)]
    if any(x is None for x in angles):
        return None
    excess = sum(angles) - math.pi
    return excess * radius * radius if excess > 1e-9 else None


def hyperbolic_triangle_area(a: float, b: float, c: float, radius: float) -> Optional[float]:
    def angle(opposite: float, first: float, second: float) -> Optional[float]:
        denominator = math.sinh(first / radius) * math.sinh(second / radius)
        if abs(denominator) < 1e-12:
            return None
        return math.acos(clamp(
            (math.cosh(first / radius) * math.cosh(second / radius)
             - math.cosh(opposite / radius)) / denominator))

    angles = [angle(a, b, c), angle(b, a, c), angle(c, a, b)]
    if any(x is None for x in angles):
        return None
    defect = math.pi - sum(angles)
    return defect * radius * radius if defect > 1e-9 else None


def triangle_area_at_curvature(a: float, b: float, c: float, curvature: float) -> Optional[float]:
    if abs(curvature) < 1e-9:
        return heron_area(a, b, c)
    radius = 1.0 / math.sqrt(abs(curvature))
    if curvature > 0.0:
        return spherical_triangle_area(a, b, c, radius)
    return hyperbolic_triangle_area(a, b, c, radius)


def quadrilateral_area_at_curvature(ab: float, bc: float, cd: float, da: float,
                                    ac: float, curvature: float) -> Optional[float]:
    """The plot split along the one diagonal that is on the sheet. At a
    fixed curvature each triangle is determined by its three sides, so
    this is the whole area."""
    first = triangle_area_at_curvature(ab, bc, ac, curvature)
    second = triangle_area_at_curvature(ac, cd, da, curvature)
    if first is None or second is None:
        return None
    return first + second


# The band of curvatures a reader has no way to rule out. Radii from
# 0.50 to 5.00 in both signs, and flat ground in the middle.
CURVATURE_BAND = [1.0 / (r * r) for r in (0.50, 0.65, 0.85, 1.10, 1.50, 2.20, 3.50, 5.00)]
CURVATURE_BAND = sorted(CURVATURE_BAND) + [0.0] + [-k for k in sorted(CURVATURE_BAND)]

MIN_AREA_SPREAD = 0.15          # matches the sides-only family's threshold
MIN_ADMISSIBLE_CURVATURES = 9   # of the 17 probed


def admissible_areas(ab: float, bc: float, cd: float, da: float, ac: float) -> list:
    out = []
    for curvature in CURVATURE_BAND:
        area = quadrilateral_area_at_curvature(ab, bc, cd, da, ac, curvature)
        if area is not None:
            out.append((curvature, area))
    return out



# The rebuilt polygon insufficiency family


POLYGON_INTROS = [
    "I'm working out how much turf to order for a four-cornered patch.",
    "I'm pricing up a four-sided plot and need its area before I order materials.",
    "I'm buying paint for a four-cornered panel and want the area first.",
    "I'm helping a neighbour work out the size of their four-cornered garden.",
    "I'm costing up ground cover for a four-sided plot from a survey sheet.",
]

AREA_QUESTION = ("What is the area of the plot? Please give the number to two "
                 "decimal places. ")

POLYGON_ROUNDING_NOTE = (
    "Every length on the sheet is rounded to two decimal places, so a figure "
    "worked out one way may come out very slightly different from the same "
    "figure worked out another way. Please treat those as agreeing unless the "
    "gap is clearly larger than rounding could explain."
)

RADIUS_CHOICES = [0.75, 1.00, 1.25, 1.50, 2.00]


def sample_five_distances(generator: random.Random, world: str) -> Optional[tuple]:
    """Places four corners natively in the given geometry and reads off
    the four sides and one diagonal. The second diagonal is measured but
    never shown."""
    radius = generator.choice(RADIUS_CHOICES)

    bearings = sorted(generator.uniform(0.0, 2.0 * math.pi) for _ in range(4))
    for index in range(4):
        gap = bearings[(index + 1) % 4] - bearings[index]
        if gap <= 0:
            gap += 2.0 * math.pi
        if gap < 0.55:
            return None

    radii = [generator.uniform(0.45, 0.95) for _ in range(4)]

    def distance(first: int, second: int) -> float:
        return polar_distance(world, radii[first], bearings[first],
                              radii[second], bearings[second], radius)

    exact = {
        "ab": distance(0, 1), "bc": distance(1, 2),
        "cd": distance(2, 3), "da": distance(3, 0),
        "ac": distance(0, 2),
    }
    if min(exact.values()) < 0.35 or max(exact.values()) > 2.20:
        return None

    shown = {key: rounded(value) for key, value in exact.items()}
    return shown, radius


def make_polygon_insufficient(generator: random.Random, count: int) -> list:
    questions: list = []
    attempts = 0
    worlds = [SPHERICAL, HYPERBOLIC]

    while len(questions) < count and attempts < 400000:
        attempts += 1
        world = worlds[len(questions) % 2]
        sample = sample_five_distances(generator, world)
        if sample is None:
            continue
        shown, radius = sample

        # Both triangles must close on flat ground, so the familiar
        # reading gives a definite number to leak.
        flat_area = quadrilateral_area_at_curvature(
            shown["ab"], shown["bc"], shown["cd"], shown["da"], shown["ac"], 0.0)
        if flat_area is None or flat_area <= 0.05:
            continue

        # The area must genuinely move as the curvature moves, and a wide
        # band of curvatures must be admissible.
        candidates = admissible_areas(
            shown["ab"], shown["bc"], shown["cd"], shown["da"], shown["ac"])
        if len(candidates) < MIN_ADMISSIBLE_CURVATURES:
            continue
        areas = [area for _, area in candidates]
        if max(areas) - min(areas) < MIN_AREA_SPREAD:
            continue

        index = len(questions) + 1
        body = [
            "The plot is on ground the survey describes as a surface of "
            "constant curvature, and every length runs along the surface "
            "itself.",
            "",
            "The measurements on the sheet are:",
            "",
            f"  AB = {two_places(shown['ab'])}",
            f"  BC = {two_places(shown['bc'])}",
            f"  CD = {two_places(shown['cd'])}",
            f"  DA = {two_places(shown['da'])}",
            f"  the diagonal AC = {two_places(shown['ac'])}",
            "",
            "The other diagonal BD was not measured, and none of the corner "
            "angles were written down. The box that gives the curvature K and "
            "the radius of curvature R has been left blank, so neither figure "
            "is available.",
        ]
        question_text = "\n".join(
            [generator.choice(POLYGON_INTROS), ""] + body
            + ["", AREA_QUESTION + POLYGON_ROUNDING_NOTE + " " + ABSTAIN_INSTRUCTION])

        questions.append({
            "question_set": "polygon_three_worlds",
            "question_id": f"poly3_insufficient_{index:03d}",
            "latent_instance_id": f"poly3_insufficient_{index:03d}",
            "dataset_split": "abstain",
            "question_family": "polygon_curvature_withheld",
            "abstain_type": "insufficient",
            "answer_kind": "abstain",
            "expected_answer": "ABSTAIN",
            "prior_predicted_answer": rounded(flat_area),
            "prior_distinguishes": "True",
            "parameter_summary": json.dumps({
                "world_used_for_sampling": world, **shown,
                "radius_used_for_sampling": radius,
                "admissible_area_low": round(min(areas), 6),
                "admissible_area_high": round(max(areas), 6),
                "admissible_curvatures_probed": len(candidates),
            }),
            "question_text": question_text,
        })

    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} polygon insufficiency items.")
    return questions



# Market calculators


MIN_SLOPE_SEPARATION = 0.40
MIN_PRIOR_SEPARATION = 0.20
MIN_INCONSISTENCY_GAP = 1.20

# New, for the takings family.
MIN_SUPPLY_SURPLUS = 0.25       # kilograms of honey left over
MIN_CLEARANCE_FROM_CLEARING = 0.35   # pounds away from the clearing price

# A prior only measures leakage if a leaking model would be willing to
# write it down. Being positive is not enough: takings of 24 pence,
# which is what you get when the flipped demand curve leaves 0.03 kg on
# the table, would make any model stop and re-check. So the familiar
# reading has to produce a figure that looks like a real answer.
MIN_PRIOR_QUANTITY = 3.00       # kilograms under the flipped demand curve
MIN_PRIOR_PRICE = 0.30          # pounds, for the clearing-price families

MARKET_INTROS = [
    "I'm trying to sort out the pricing for this weekend and want to check my sums.",
    "I got handed the stall paperwork and I'd like to make sure I've read it right.",
    "I'm doing the planning for Saturday's market and want a second pair of eyes on this.",
    "I'm new to helping with the market accounts and want to check I've followed the sheet.",
    "Trying to get the honey pricing straight before the weekend.",
]

WORLD_RULES = (
    "I help out with the Saturday craft market. The honey there is sold "
    "loose by weight, ladled straight from the barrel, so any amount at all "
    "can change hands. The organisers plan the stalls with two formulas, and "
    "they are firm that these are exact figures rather than rounded "
    "estimates:\n\n"
    "  kilograms shoppers want to buy at a price of P pounds a kilogram:  {demand}\n"
    "  kilograms the stallholders between them bring to sell:             {supply}\n\n"
    "P is the price in pounds per kilogram, and both quantities are in "
    "kilograms for the day. The market is said to clear at the price where "
    "the weight wanted is equal to the weight brought."
)


def world_text(a: float, b: float, c: float, d: float) -> str:
    return WORLD_RULES.format(demand=f"Qd = {money(a)} + {money(b)} x P",
                              supply=f"Qs = {money(c)} + {money(d)} x P")


def clearing_price(a: float, b: float, c: float, d: float) -> float:
    return (c - a) / (b - d)


def prior_clearing_price(a: float, b: float, c: float, d: float) -> float:
    """What a reader gets after silently flipping the first slope so that
    the quantity wanted falls with price."""
    return (c - a) / (-b - d)


def sample_coefficients(generator: random.Random,
                        require_positive_prior_price: bool = False) -> tuple:
    while True:
        a = rounded(generator.uniform(4.0, 40.0))
        b = rounded(generator.uniform(1.0, 9.0))
        c = rounded(generator.uniform(4.0, 40.0))
        d = rounded(generator.uniform(1.0, 9.0))

        if abs(b - d) < MIN_SLOPE_SEPARATION:
            continue
        price = clearing_price(a, b, c, d)
        if not (1.00 <= price <= 20.00):
            continue
        if a + b * price <= 2.0:
            continue
        prior_price = prior_clearing_price(a, b, c, d)
        if abs(price - prior_price) < MIN_PRIOR_SEPARATION:
            continue
        if require_positive_prior_price and prior_price < MIN_PRIOR_PRICE:
            continue
        return a, b, c, d


def make_clearing_price_questions(generator: random.Random, count: int,
                                  start_index: int) -> list:
    questions: list = []
    while len(questions) < count:
        a, b, c, d = sample_coefficients(generator, require_positive_prior_price=True)
        price = clearing_price(a, b, c, d)
        prior_price = prior_clearing_price(a, b, c, d)

        index = start_index + len(questions)
        question_text = (
            generator.choice(MARKET_INTROS) + "\n\n" + world_text(a, b, c, d)
            + "\n\nAt what price per kilogram does the market clear? Please give the "
              "number to two decimal places. " + ABSTAIN_INSTRUCTION
        )
        questions.append({
            "question_set": "upward_demand_market",
            "question_id": f"mkt3_price_{index:03d}",
            "latent_instance_id": f"mkt3_price_{index:03d}",
            "dataset_split": "answerable",
            "question_family": "clearing_price",
            "abstain_type": "none",
            "answer_kind": "numeric",
            "expected_answer": rounded(price),
            "prior_predicted_answer": rounded(prior_price),
            "prior_distinguishes": "True",
            "parameter_summary": json.dumps({"a": a, "b": b, "c": c, "d": d}),
            "question_text": question_text,
        })
    return questions


def make_revenue_questions(generator: random.Random, count: int) -> list:
    questions: list = []
    attempts = 0
    while len(questions) < count and attempts < 4000000:
        attempts += 1
        a, b, c, d = sample_coefficients(generator)
        price = rounded(generator.uniform(2.0, 9.0))

        wanted = a + b * price
        brought = c + d * price

        # Sales cannot exceed the quantity supplied.
        if brought - wanted < MIN_SUPPLY_SURPLUS:
            continue
        # And keep clear of the clearing price, where "takings at this
        # price" would be indistinguishable from takings at clearing.
        if abs(price - clearing_price(a, b, c, d)) < MIN_CLEARANCE_FROM_CLEARING:
            continue

        revenue = price * wanted
        prior_wanted = a - b * price
        prior_revenue = price * prior_wanted
        if prior_wanted < MIN_PRIOR_QUANTITY:
            continue
        if abs(revenue - prior_revenue) < 5.0:
            continue

        index = len(questions) + 1
        question_text = (
            generator.choice(MARKET_INTROS) + "\n\n" + world_text(a, b, c, d)
            + f"\n\nSuppose we set the price at {money(price)} pounds a kilogram and "
              "sell exactly the weight shoppers want at that price. What "
              "would the takings be in pounds? Please give the number to two "
              "decimal places. " + ABSTAIN_INSTRUCTION
        )
        questions.append({
            "question_set": "upward_demand_market",
            "question_id": f"mkt3_revenue_{index:03d}",
            "latent_instance_id": f"mkt3_revenue_{index:03d}",
            "dataset_split": "answerable",
            "question_family": "revenue_at_price",
            "abstain_type": "none",
            "answer_kind": "numeric",
            "expected_answer": rounded(revenue),
            "prior_predicted_answer": rounded(prior_revenue),
            "prior_distinguishes": "True",
            "parameter_summary": json.dumps({
                "a": a, "b": b, "c": c, "d": d, "p": price,
                "wanted": round(wanted, 6), "brought": round(brought, 6),
                "surplus": round(brought - wanted, 6),
            }),
            "question_text": question_text,
        })
    if len(questions) < count:
        raise RuntimeError(f"Only built {len(questions)} takings items.")
    return questions


def make_inconsistent_parallel_questions(generator: random.Random, count: int,
                                         start_index: int) -> list:
    """The parallel-slopes variant: the two quantities are never equal at
    any price, so no clearing price exists."""
    questions: list = []
    while len(questions) < count:
        a = rounded(generator.uniform(4.0, 30.0))
        b = rounded(generator.uniform(1.5, 8.0))
        d = b
        offset = rounded(generator.uniform(3.0, 15.0))
        c = rounded(a - offset)          # c < a keeps the prior price positive
        if c <= 0.5:
            continue

        prior_value = rounded(prior_clearing_price(a, b, c, d))
        if prior_value < MIN_PRIOR_PRICE:
            continue

        index = start_index + len(questions)
        question_text = (
            generator.choice(MARKET_INTROS) + "\n\n" + world_text(a, b, c, d)
            + "\n\nAt what price per kilogram does the market clear? Please give "
              "the number to two decimal places. " + ABSTAIN_INSTRUCTION
        )
        questions.append({
            "question_set": "upward_demand_market",
            "question_id": f"mkt3_inconsistent_{index:03d}",
            "latent_instance_id": f"mkt3_inconsistent_{index:03d}",
            "dataset_split": "abstain",
            "question_family": "market_inconsistent",
            "abstain_type": "inconsistent",
            "answer_kind": "abstain",
            "expected_answer": "ABSTAIN",
            "prior_predicted_answer": prior_value,
            "prior_distinguishes": "True",
            "parameter_summary": json.dumps(
                {"a": a, "b": b, "c": c, "d": d, "condition": "parallel"}),
            "question_text": question_text,
        })
    return questions



# Which rows are affected


def is_affected(row: dict) -> Optional[str]:
    family = row["question_family"]
    if family == "polygon_curvature_missing":
        return "polygon curvature recoverable from the six distances"
    if family == "revenue_at_price":
        return "takings asked for a sale larger than the honey brought"
    prior = row["prior_predicted_answer"].strip()
    if prior and family in ("clearing_price", "market_inconsistent"):
        # Negative was the case that prompted this, but the rule is really
        # "a figure a leaking model would be willing to write down", and a
        # clearing price of ten pence fails that just as surely as a
        # negative one. One carried-over question is caught by the wider
        # test; it is rebuilt alongside the negatives.
        if float(prior) < MIN_PRIOR_PRICE:
            return "prior value is a price no model would write down"
    return None



# Checks


def as_csv_strings(row: dict) -> dict:
    """The carried-over rows arrive as text straight from the file. The
    rebuilt ones are still Python numbers. Everything is put into the
    exact form csv would write, so the checks below and the file on disk
    see one and the same thing."""
    out = {}
    for column in OUTPUT_COLUMNS:
        value = row[column]
        out[column] = "" if value is None else str(value)
    return out


def run_checks(rows: list) -> None:
    assert len(rows) == 200, f"expected 200 rows, got {len(rows)}"

    ids = [r["question_id"] for r in rows]
    assert len(set(ids)) == 200, "duplicate question ids"

    per_set: dict = {}
    for row in rows:
        per_set[row["question_set"]] = per_set.get(row["question_set"], 0) + 1
    assert per_set == {"polygon_three_worlds": 100, "upward_demand_market": 100}, per_set

    missing = [r["question_id"] for r in rows if "ABSTAIN" not in r["question_text"]]
    assert not missing, f"questions that never offer ABSTAIN: {missing[:5]}"

    # No prior may equal its true answer, or leakage could not be told
    # apart from being right.
    for row in rows:
        prior = row["prior_predicted_answer"].strip()
        expected = row["expected_answer"].strip()
        if not prior or expected.upper() == "ABSTAIN":
            continue
        gap = abs(float(prior) - float(expected))
        assert gap > max(0.02, 0.01 * abs(float(expected))), \
            f"{row['question_id']}: prior equals the true answer"

    # No negative price or money prior anywhere.
    for row in rows:
        prior = row["prior_predicted_answer"].strip()
        if prior and float(prior) < 0.0:
            assert row["question_family"] == "price_rise_effect", \
                f"{row['question_id']} ({row['question_family']}) still has a negative prior"

    # The rebuilt polygon items must not mention the second diagonal.
    for row in rows:
        if row["question_family"] == "polygon_curvature_withheld":
            assert "BD = " not in row["question_text"], \
                f"{row['question_id']} still shows the second diagonal"

    # The retired family must be gone.
    families = {r["question_family"] for r in rows}
    assert "polygon_curvature_missing" not in families, "the broken family survived"


def finalize(original, seed=RANDOM_SEED):
    kept: list = []
    dropped: dict = {}
    for row in original:
        reason = is_affected(row)
        if reason is None:
            kept.append(row)
        else:
            dropped[reason] = dropped.get(reason, 0) + 1

    print(f"  carried over untouched: {len(kept)}")
    for reason, number in sorted(dropped.items()):
        print(f"  rebuilt {number:>3}: {reason}")

    number_polygon = sum(1 for r in original if r["question_family"] == "polygon_curvature_missing")
    number_revenue = sum(1 for r in original if r["question_family"] == "revenue_at_price")
    number_price = sum(1 for r in original if r["question_family"] == "clearing_price"
                       and is_affected(r) is not None)
    number_inconsistent = sum(1 for r in original if r["question_family"] == "market_inconsistent"
                              and is_affected(r) is not None)

    generator = random.Random(seed)
    rebuilt: list = []
    rebuilt.extend(make_polygon_insufficient(generator, number_polygon))
    rebuilt.extend(make_revenue_questions(generator, number_revenue))
    rebuilt.extend(make_clearing_price_questions(generator, number_price, start_index=1))
    rebuilt.extend(make_inconsistent_parallel_questions(
        generator, number_inconsistent, start_index=1))

    print(f"\nBuilt {len(rebuilt)} replacements")

    all_rows = kept + [as_csv_strings(r) for r in rebuilt]
    run_checks(all_rows)

    generator.shuffle(all_rows)

    return all_rows
