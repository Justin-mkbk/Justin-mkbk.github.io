"""Generate one final 700-question CSV from seven world samplers and calculators.

``axiomshift generate --output outputs/published`` reconstructs the exact
published questions. Add ``--seed 42`` for a balanced parameter variant.
Candidate CSVs exist only in a temporary workspace; the output contains the
final dataset, its verification record, diagnostic logs, and variant ID map.
"""
from __future__ import annotations

import contextlib
import csv
import hashlib
import io
import json
import platform
import random
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

from .io import ROOT, DEFAULT_DATA, FIELDS, load_questions, read_csv, sha256, write_csv
from .finalize import finalize
from .verify_answers import verify_answers

BASE_WORLDS = ['two_mass_materials', 'altered_valence_chemistry', 'altered_codon_table',
               'sas_three_worlds', 'partial_order_counts']
OTHER_WORLDS = ['polygon_three_worlds', 'upward_demand_market']


def derived_seed(seed, script, attempt=0):
    """Stable per-component seeds; logical component names preserve existing variants."""
    name = Path(script).name
    key = f'axiomshift-seed-v1:{seed}:{name}' + (f':retry:{attempt}' if attempt else '')
    return int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], 'big')


def run_script(script, directory, logs, seed=None):
    for attempt in range(32):
        actual_seed = None if seed is None else derived_seed(seed, script, attempt)
        command = [sys.executable, str(script)] if seed is None else [
            sys.executable, str(Path(__file__).with_name('_seeded_source.py')), str(script), str(actual_seed)]
        completed = subprocess.run(command, cwd=directory, capture_output=True,
                                   text=True, encoding='utf-8', timeout=180)
        log = logs/(script.stem+'.log')
        log.write_text(completed.stdout+'\n'+completed.stderr, encoding='utf-8')
        if not completed.returncode:
            return {'seed_override': actual_seed, 'sampling_attempts': attempt+1}
        shortage = script.name == 'partial_order_counts_generator_100questions.py' and 'RuntimeError: Only built ' in completed.stderr
        if seed is None or not shortage or attempt == 31:
            raise RuntimeError(f'{script.name} failed; see {log}')
        (logs/f'{script.stem}.rejected-{attempt}.log').write_text(log.read_text(encoding='utf-8'), encoding='utf-8')


def assemble(directory, seed):
    """Finalize candidate answers and assemble rows entirely in memory.

The fixed seed identifiers are part of the published seed-v1 contract, even
though the former merge scripts are now replaced by these in-memory stages.
"""
    candidates = []
    for world in OTHER_WORLDS:
        candidates.extend({'question_set': world, **row}
                          for row in read_csv(directory/f'{world}_v2_questions_100questions.csv'))
    stages = {}
    for name, default, key in [('merge_revised_200.py', 20260826, 'candidate_shuffle'),
                               ('regenerate_corrected_200.py', 20260828, 'finalize_answers'),
                               ('merge_700_revised.py', 20260830, 'final_shuffle')]:
        stages[key] = default if seed is None else derived_seed(seed, name)
    random.Random(stages['candidate_shuffle']).shuffle(candidates)
    finalized = finalize(candidates, stages['finalize_answers'])
    verify_answers(finalized)

    pool = {}
    for world in BASE_WORLDS:
        for row in read_csv(directory/f'{world}_questions_100questions.csv'):
            row['prior_distinguishes'] = row['prior_distinguishes'].upper()
            for field in ('expected_answer', 'prior_predicted_answer'):
                value = row[field]
                if value and value != 'ABSTAIN' and float(value).is_integer():
                    row[field] = str(int(float(value)))
            pool[row['question_id']] = {'question_set': world, **row}
    order = json.loads((ROOT/'data/raw/base_five_world_order.json').read_text())['question_ids']
    if set(pool) != set(order) or len(order) != 500:
        raise ValueError('Base IDs differ from the published assembly recipe; see docs/extending.md for custom schemas')
    generator = random.Random(stages['final_shuffle'])
    generator.shuffle(finalized)
    combined = [pool[qid] for qid in order] + finalized
    generator.shuffle(combined)
    ids = [r['question_id'] for r in combined]
    if len(set(ids)) != 700 or any(qid.startswith(('poly_', 'mkt_')) for qid in ids):
        raise ValueError('Invalid or duplicate final question IDs')
    for row in combined:
        if 'ABSTAIN' not in row['question_text']:
            raise ValueError(f"{row['question_id']}: no abstention option")
        prior, expected = row['prior_predicted_answer'], row['expected_answer']
        if prior and expected != 'ABSTAIN' and abs(float(prior)-float(expected)) <= max(.02, .01*abs(float(expected))):
            raise ValueError(f"{row['question_id']}: prior answer equals gold")
    return combined, stages


def generate(output, verify=True, seed=None):
    output = Path(output).resolve()
    if output.exists() and any(output.iterdir()):
        raise ValueError('Generation output must be an empty directory')
    output.mkdir(parents=True, exist_ok=True)
    logs = output/'logs'
    logs.mkdir()
    executions = {}
    scripts = [ROOT/'generators'/f'{world}_generator_100questions.py' for world in BASE_WORLDS+OTHER_WORLDS]
    with tempfile.TemporaryDirectory(prefix='axiomshift-generation-') as temporary:
        directory = Path(temporary)
        for script in scripts:
            executions[script.name] = run_script(script, directory, logs, seed)
        log = io.StringIO()
        try:
            with contextlib.redirect_stdout(log):
                rows, stages = assemble(directory, seed)
        finally:
            (logs/'assembly.log').write_text(log.getvalue(), encoding='utf-8')

    target = output/'seven_worlds.csv'
    # The canonical serialization includes the UTF-8 BOM and CSV CRLF endings.
    with target.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    rows = load_questions(target)
    expected = load_questions(DEFAULT_DATA)
    balance = lambda items: Counter((q['question_set'], q['question_family'], q['abstain_type']) for q in items)
    if seed is not None:
        if balance(rows) != balance(expected):
            raise ValueError('Variant family/world/abstention balance differs from the published benchmark')
        namespace = f'variant-{seed}-{sha256(target)[:12]}-'
        id_map = {}
        for row in rows:
            old_id = row['question_id']
            row['question_id'] = namespace+old_id
            row['latent_instance_id'] = namespace+row['latent_instance_id']
            id_map[row['question_id']] = old_id
        write_csv(target, rows, FIELDS)
        (output/'source_ids.json').write_text(json.dumps(id_map, indent=2)+'\n', encoding='utf-8')
    differences = []
    if len(rows) != len(expected):
        differences.append({'row_count': [len(rows), len(expected)]})
    for actual, gold in zip(rows, expected):
        for field in FIELDS:
            if actual[field] != gold[field]:
                differences.append({'question_id': gold['question_id'], 'field': field,
                                    'actual': actual[field], 'expected': gold[field]})
    sources = scripts+sorted(Path(__file__).parent.glob('*.py'))+[ROOT/'data/raw/base_five_world_order.json']
    report = {'rows': len(rows), 'sha256': sha256(target), 'canonical_sha256': sha256(DEFAULT_DATA),
              'byte_identical': sha256(target) == sha256(DEFAULT_DATA), 'differences': differences,
              'mode': 'canonical' if seed is None else 'variant', 'seed': seed,
              'seed_derivation': 'axiomshift-seed-v1', 'stage_seeds': stages,
              'python': platform.python_version(), 'same_family_balance': balance(rows) == balance(expected),
              'sources': [{'file': p.relative_to(ROOT).as_posix(), 'sha256': sha256(p),
                           **executions.get(p.name, {})} for p in sources]}
    (output/'verification.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    if seed is None and verify and not report['byte_identical']:
        raise ValueError(f'Generated bytes differ ({len(differences)} differing fields); see {output / "verification.json"}')
    print(f'Generated {len(rows)} questions; byte-identical: {report["byte_identical"]}')
    return report
