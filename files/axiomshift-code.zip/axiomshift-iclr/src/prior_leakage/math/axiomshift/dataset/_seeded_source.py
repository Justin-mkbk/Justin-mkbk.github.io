"""Run one question generator with an explicit seed in a separate process.

The public ``axiomshift generate --seed 42`` command derives a seed per world
and calls this helper. For a single-world experiment, from an empty output
directory run ``python -m prior_leakage.math.axiomshift.dataset._seeded_source
/absolute/path/to/generator.py 42``. The generator writes its CSV there.
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


def main():
    path = Path(sys.argv[1]).resolve()
    spec = importlib.util.spec_from_file_location("_axiomshift_author_source", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module  # Dataclass annotations need the module registered during import.
    spec.loader.exec_module(module)
    if not isinstance(getattr(module, "RANDOM_SEED", None), int):
        raise ValueError(f"{path.name} has no integer RANDOM_SEED")
    module.RANDOM_SEED = int(sys.argv[2])
    module.main()


if __name__ == "__main__":
    main()
