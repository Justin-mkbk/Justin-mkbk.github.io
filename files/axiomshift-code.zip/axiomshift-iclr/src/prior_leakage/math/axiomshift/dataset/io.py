"""Load and validate benchmark questions for generation, inference, and scoring.

This is shared CSV/schema I/O, not a sampler or model backend.
Example: ``from prior_leakage.math import load_questions``; ``load_questions()``
returns the canonical 700 rows, while ``load_questions(path)`` reads a variant.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = ROOT / "data/assembled/seven_worlds.csv"
FIELDS = ("question_set", "question_id", "latent_instance_id", "dataset_split",
          "question_family", "abstain_type", "answer_kind", "expected_answer",
          "prior_predicted_answer", "prior_distinguishes", "parameter_summary", "question_text")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_csv(path):
    path = Path(path)
    for encoding in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            with path.open(encoding=encoding, newline="") as handle:
                return list(csv.DictReader(handle))
        except UnicodeDecodeError:
            continue
    raise ValueError(f"Cannot decode {path}")


def write_csv(path, rows, fields=None):
    path = Path(path)
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def truthy(value):
    return str(value).strip().lower() in ("true", "1", "yes")


def number(value):
    if value is None or str(value).strip() == "":
        return None
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"Non-finite number: {value!r}")
    return result


def load_questions(path=DEFAULT_DATA, *, canonical=False):
    rows = read_csv(path)
    if not rows:
        raise ValueError("Dataset is empty")
    if set(FIELDS) - set(rows[0]):
        raise ValueError(f"Missing dataset columns: {sorted(set(FIELDS) - set(rows[0]))}")
    ids = set()
    for row in rows:
        qid = row["question_id"]
        if not qid or qid in ids:
            raise ValueError(f"Empty or duplicate question_id: {qid!r}")
        ids.add(qid)
        if None in row or any(row.get(k) is None for k in FIELDS):
            raise ValueError(f"Malformed CSV record: {qid}")
        for field in ("question_set", "question_family", "question_text", "latent_instance_id"):
            if not row[field].strip():
                raise ValueError(f"{qid}: empty {field}")
        abstain = row["expected_answer"].upper() == "ABSTAIN"
        if abstain:
            row["expected_answer"] = "ABSTAIN"
        if not abstain and number(row["expected_answer"]) is None:
            raise ValueError(f"{qid}: missing expected_answer")
        number(row["prior_predicted_answer"])
        if row["prior_distinguishes"].lower() not in ("true", "false"):
            raise ValueError(f"{qid}: prior_distinguishes must be true/false")
        if row["abstain_type"] not in ("none", "insufficient", "inconsistent", "non_unique"):
            raise ValueError(f"{qid}: unknown abstain_type")
        if abstain != (row["abstain_type"] != "none"):
            raise ValueError(f"{qid}: answer and abstain_type disagree")
        if row["dataset_split"] != ("abstain" if abstain else "answerable"):
            # Historical files use 'unanswerable' in some variants.
            if not (abstain and row["dataset_split"] == "unanswerable"):
                raise ValueError(f"{qid}: inconsistent dataset_split")
        json.loads(row["parameter_summary"])
    if canonical:
        manifest = json.loads((ROOT / "data/assembled/manifest.json").read_text(encoding="utf-8"))
        if sha256(path) != manifest["sha256"]:
            raise ValueError("Canonical dataset checksum differs; use validate without --canonical for an intentional variant")
        if len(rows) != 700 or set(Counter(r["question_set"] for r in rows).values()) != {100}:
            raise ValueError("Canonical benchmark must contain seven worlds of 100 questions")
        if sum(r["expected_answer"] == "ABSTAIN" for r in rows) != 210:
            raise ValueError("Canonical benchmark must contain 490 answerable and 210 abstention items")
    return rows


def select_questions(rows, worlds=(), families=(), limit=None, seed=None):
    selected = [r for r in rows if (not worlds or r["question_set"] in worlds)
                and (not families or r["question_family"] in families)]
    if seed is not None:
        import random
        random.Random(seed).shuffle(selected)
    if limit is not None:
        if limit <= 0:
            raise ValueError("--limit must be positive")
        selected = selected[:limit]
    if not selected:
        raise ValueError("No questions match the requested selection")
    return selected
