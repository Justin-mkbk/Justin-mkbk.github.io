# Benchmark inputs

Use `assembled/seven_worlds.csv` directly, or let the CLI select it by default. It is the only distributed question CSV: 700 questions, seven worlds. `assembled/manifest.json` defines the canonical byte fingerprint and benchmark counts for `validate --canonical`.

`raw/base_five_world_order.json` is an assembly input containing question IDs in the published base order. It is required for byte-identical reconstruction, but contains no question text or answers. Generation runs the samplers afresh and joins their rows to this ordering.

There are no cached 200/500-question datasets. Use `axiomshift generate --output outputs/published` for exact reconstruction or add `--seed 42` for a balanced variant. See [the pipeline](../docs/pipeline.md) for assembly and gold-answer validation.
