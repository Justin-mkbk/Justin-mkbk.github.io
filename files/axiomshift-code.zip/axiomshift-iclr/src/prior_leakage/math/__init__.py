"""Seven-world mathematics benchmark: dataset access, evaluation, and generation."""
from .axiomshift.dataset.io import load_questions

__all__ = ["load_questions"]
