# Published responses and run summaries

`reference/` contains all 26 saved model-response CSVs. They are inputs to score and figure reproduction, not intermediate question sets. Run `axiomshift analyse --output outputs/reference` to recalculate scores and inspect `outputs/reference/README.md`.

`summary/` contains the nine available Hugging Face run summaries, including model revision and environment information where recorded. They are not complete Conda exports; two omit model revisions, and other runs lack equivalent summaries. Missing summaries do not mean missing response CSVs.

Analysis checks stored grades against the benchmark, records input fingerprints in its output, and explicitly reports missing/incomplete answers. For a new run, preserve `run.json`, `answers.jsonl`, `answers.csv`, and the exact dataset. Add its `--data` path to analysis when using a variant.
