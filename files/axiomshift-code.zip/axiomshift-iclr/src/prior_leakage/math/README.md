# AxiomShift: seven-world mathematics benchmark

AxiomShift tests whether a language model follows the axioms provided in the present context or falls back to familiar rules learned in the past, such as during pretraining. The benchmark contains **700 questions across seven worlds**: 490 answerable questions and 210 requiring abstention. It includes saved responses from 26 models.

## Install

Run these commands from the **repository root**, in a checkout containing this package. They do not depend on a release-branch name and remain valid when the work is merged into main.

```bash
python -m pip install -e .
axiomshift validate --canonical
axiomshift gui
```

On Windows, use `py` instead of `python`, or the Python executable in your virtual environment. The console command can also be written `python -m prior_leakage.math.axiomshift`. Core inference against LM Studio, the browser GUI, generation, and saved-result analysis require no third-party runtime libraries. Build/install tooling uses setuptools.

The package supports `from prior_leakage.math import load_questions`. This supplement contains the mathematics benchmark.

The [local testing guide](docs/local_testing.md) provides exact Windows commands. [The seven-world guide](generators/README.md) explains the tasks without requiring familiarity with earlier experiments.

## Evaluate a model

For the GUI, start LM Studio's local server, then run `axiomshift gui`. Open `http://127.0.0.1:8765`, connect to `http://localhost:1234/v1`, select a loaded text-generation model, and start a five-question smoke test. Once it succeeds, choose 700 questions and a new run folder. The GUI supports pause/resume and links to responses and reports.

Outputs are written beneath **the current working directory's `outputs/`**, never into the installed package. Optional local server authentication uses the `LMSTUDIO_API_KEY` environment variable. The GUI only connects to loopback servers. [LM Studio API documentation](https://lmstudio.ai/docs/developer/openai-compat).

### Choose a custom model

Replace `YOUR_MODEL_ID` with the exact identifier returned by your local server:

```bash
axiomshift run --model YOUR_MODEL_ID --backend api --api-style chat --parser local --prompt local --base-url http://localhost:1234/v1 --limit 5 --output outputs/my-smoke
axiomshift analyse --results outputs/my-smoke/answers.csv --output outputs/my-smoke/analysis
```

For all 700 questions, omit `--limit 5` and use a new output folder. For a base model add `--base-model`. Thinking models may need a larger `--max-output-tokens` budget than the default 800. `axiomshift models` lists reusable historical presets; another model only needs configuration, not a copied evaluator.

For local Hugging Face weights, install `python -m pip install -e ".[hf]"`, then use `--backend hf --model-path /absolute/model/snapshot`. For Slurm, follow [the setup and Slurm guide](../../../scripts/math/slurm/README.md): Qwen2.5-Math-72B uses four H200s; Kimi K2 Thinking and Qwen3.5 397B use eight. Other HF allocations can be configured with `axiomshift-slurm`.

Each evaluation writes `run.json` (configuration and dataset fingerprint), `answers.jsonl` (all attempts), and `answers.csv` (one selected outcome per question). Repeat the same command with `--resume` to skip completed answers and retry incomplete ones. Changed data, model settings, prompts, code, or selection require a new run folder.

## Data generation

To recreate the published dataset exactly:

```bash
axiomshift generate --output outputs/published
```

Expected: **700 rows** and `byte_identical: true` in `outputs/published/verification.json`. All numbers, wording, IDs, answers, order, and CSV bytes match the supplied dataset.

To generate new parameters with the same seven worlds and question-family/abstention balance:

```bash
axiomshift generate --seed 42 --output outputs/datasets/seed42
axiomshift validate --data outputs/datasets/seed42/seven_worlds.csv
```

Repeat the same seed with the same code and Python version to reproduce that variant. Variant IDs include the seed and dataset fingerprint. Some structural questions can recur. Use a new or empty output directory. When evaluating a variant, supply its `--data` path to both `run` and `analyse`.

Seven world generators produce candidates. The dataset pipeline finalizes polygon/market cases, verifies their answers independently from the rendered prompts, and assembles one final CSV. Intermediate candidate CSVs are temporary and are not shipped or retained in the output. [Pipeline and extension points](docs/pipeline.md).

## Analysis

Recalculate the published tables offline from all 26 saved response files:

```bash
axiomshift analyse --output outputs/reference-analysis
```

Open `outputs/reference-analysis/README.md`. The analysis writes:

| Term/file | Meaning |
|---|---|
| Metrics, in `models.csv`, `by_world.csv`, `by_family.csv` | Counts and rates measuring correctness, prior leakage, and abstention failures, overall and by task |
| Denominators | The number of eligible answers behind each rate. Accuracy uses completed answers by default; conditional leakage uses numeric commitments on questions that distinguish the prior. For example, 6 leaks among 20 eligible numeric answers is 30%, not 6 divided by 700 |
| Checksums, in `audit.json` | SHA-256 file fingerprints: a change to a file's bytes changes its fingerprint, revealing a different input |
| Grading checks, in `audit.json` | Recompute stored correctness/error labels from saved answers and dataset gold answers; discrepancies signal a grading/data mismatch |
| Missing/incomplete counts, in `models.csv` | Distinguish questions never answered from runtime, parsing, or output-length failures; a five-question smoke test has 695 missing questions |

All 26 response CSVs are in `results/reference/`; nine available Hugging Face run summaries are in `results/summary/`. Analysis computes input fingerprints and checks stored grading against the gold answers. These summaries do not provide a complete environment lock for every model.

### Workshop-paper figures and tables

```bash
python -m pip install -e ".[plots]"
axiomshift paper-assets --output outputs/paper-assets
axiomshift stage-paper mathai --output outputs/mathai
axiomshift stage-paper aiscik --output outputs/aiscik
```

[Workshop analysis](analysis/README.md) names the role of each script. Figures use descriptive names: `failure_modes_by_accuracy`, `prior_leakage_by_question_type`, and `error_shares_by_accuracy`. Paper staging updates the manuscript references consistently.

Fresh model runs are new experiments. They need not reproduce historical response text or scores: model revisions, quantization, chat templates, and environment settings can differ. [Reproduction limits](docs/reproduction.md).

## Layout and extension points

| Path inside the mathematics package | Function |
|---|---|
| `generators/` | Seven worlds: families, axiom changes, parameter sampling, gold/prior calculators |
| `axiomshift/dataset/` | CSV validation, generation, finalization, independent answer verification, assembly |
| `axiomshift/models/` | Model adapters and the resumable inference loop |
| `axiomshift/evaluation/` | Output parsing, scoring against gold/prior answers, and metric aggregation |
| `axiomshift/gui/` | Browser interface using the same CLI and pipeline |
| `configs/` | Reusable model and prompt settings, with usage examples |
| `data/assembled/` | The one canonical question CSV and its validation fingerprint |
| `data/raw/` | ID ordering needed to reconstruct identical published bytes; no intermediate question CSVs |
| `results/reference/`, `results/summary/` | Saved responses and available run summaries |
| `analysis/`, `paper/` | Publication figures/statistics and two supported manuscript dependency sets |

At the repository root, `tests/math/` checks reproduction and evaluation, and `scripts/math/` supplies cluster setup. Run `python -m unittest discover -s tests/math -v` after modifying code. [Extending the benchmark](docs/extending.md) explains custom models, worlds, and question counts.
