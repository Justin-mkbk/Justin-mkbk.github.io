"""Benchmarks for reliance on pretrained knowledge versus supplied context."""
